"use strict";
(self["webpackChunk_roots_bud_sage_sage"] = self["webpackChunk_roots_bud_sage_sage"] || []).push([["app"],{

/***/ "../node_modules/@roots/bud-support/lib/css-loader/index.cjs??css!../node_modules/postcss-loader/dist/cjs.js??postcss!./styles/app.css":
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("../node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("../node_modules/css-loader/dist/runtime/getUrl.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__);
// Imports



var ___CSS_LOADER_URL_IMPORT_0___ = new URL(/* asset import */ __webpack_require__("./fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-700.woff2"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_1___ = new URL(/* asset import */ __webpack_require__("./fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-700.woff"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_2___ = new URL(/* asset import */ __webpack_require__("./fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-600.woff2"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_3___ = new URL(/* asset import */ __webpack_require__("./fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-600.woff"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_4___ = new URL(/* asset import */ __webpack_require__("./fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-500.woff2"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_5___ = new URL(/* asset import */ __webpack_require__("./fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-500.woff"), __webpack_require__.b);
var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
___CSS_LOADER_EXPORT___.push([module.id, "@import url(https://fonts.googleapis.com/css2?family=Signika&display=swap);"]);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_0___);
var ___CSS_LOADER_URL_REPLACEMENT_1___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_1___);
var ___CSS_LOADER_URL_REPLACEMENT_2___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_2___);
var ___CSS_LOADER_URL_REPLACEMENT_3___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_3___);
var ___CSS_LOADER_URL_REPLACEMENT_4___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_4___);
var ___CSS_LOADER_URL_REPLACEMENT_5___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_5___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@tailwind base;@tailwind components;@tailwind utilities;/* ACF OVERRIDES *//* Footer Menu */#menu-footer-menu {\r\n  display: flex;\r\n  justify-content: space-between;\r\n}@media (min-width: 768px) {\r\n  #menu-footer-menu {\r\n    gap: 3rem;\r\n  }\r\n}#menu-footer-menu li a {\r\n  font-size: 1rem;\r\n}.menu-footer-menu-container #menu-footer-menu .menu-item a{\r\n  --tw-text-opacity: 1 !important;\r\n  color: rgba(0, 0, 0, 1) !important;\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.menu-footer-menu-container #menu-footer-menu .menu-item a{\r\n    color: rgb(0 0 0 / var(--tw-text-opacity)) !important;\r\n  }\n}.footer-nested-item div ul li a {\r\n  font-size: 0.89rem !important;\r\n}@media (min-width: 768px) {\r\n  .footer-nested-item div ul li a {\r\n    font-size: 1rem !important;\r\n  }\r\n  #menu-footer-menu {\r\n    gap: 2.5rem;\r\n  }\r\n}.expand-icon-footer::before {\r\n  content: '+'; \r\n}.retract-icon-footer::before {\r\n  font-size: 2.25rem !important;\r\n}.retract-icon-footer::before {\r\n  content: '-';\r\n}@media (min-width: 768px){\r\n  .expand-icon-footer::before {\r\n      display: none; \r\n  }\r\n  .retract-icon-footer::before {\r\n      display: none; \r\n  }\r\n}.footer-nested-item .acf-nav-menu ul li:hover {\r\n  font-weight: 600;\r\n}/* HEADER STYLES */header {\r\n    position: relative;\r\n}/* Hamburger Button*/#hamburger-button.active .topline { \r\n  transform: rotate(45deg) translate(0px, 5px); \r\n  width: 18px;\r\n}#hamburger-button.active .bottomline { \r\n  transform: rotate(-45deg) translate(0px, -5px);\r\n  width: 18px;\r\n}@media (min-width: 768px) {\r\n    #hamburger-button.active .topline , #hamburger-button.active .bottomline{\r\n      width: 24px !important;\r\n    }\r\n}#hamburger-button.active {\r\n  transition: transform 0.4s ease, width 0.4s ease; \r\n}#hamburger-button .topline, #hamburger-button .bottomline { \r\n  transition: transform 0.4s ease, width 0.4s ease; \r\n}/* Hamburger Menu*//* right side menu */#hamburger-dropdown-menu .sub_menu.right .menu .acf-nav-menu ul li a {\r\n    display: flex;\r\n    justify-content: space-between;\r\n    align-items: center;\r\n    width: 100%;\r\n    padding: 0.25rem 0;\r\n    cursor: pointer;\r\n    font-size: 1rem;\r\n}@media (min-width: 768px) {\r\n    #hamburger-dropdown-menu .sub_menu.right .menu .acf-nav-menu ul li a{\r\n    font-size: 1.334rem;\r\n  }\r\n}#hamburger-dropdown-menu .sub_menu.right .menu .acf-nav-menu ul li ul {\r\n    padding-top: 0;\r\n    --tw-text-opacity: 1;\r\n    color: rgba(118, 118, 118, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n#hamburger-dropdown-menu .sub_menu.right .menu .acf-nav-menu ul li ul {\r\n    color: rgb(118 118 118 / var(--tw-text-opacity));\r\n}\n}@media (min-width: 768px) {\r\n    #hamburger-dropdown-menu .sub_menu.right .menu .acf-nav-menu ul li ul {\r\n        padding: 0.25rem 0;\r\n    }\r\n}#hamburger-dropdown-menu .sub_menu.right .menu .acf-nav-menu ul li ul li a {\r\n    font-size: 0.89rem !important;\r\n}#hamburger-dropdown-menu .sub_menu.right .menu .acf-nav-menu ul li ul li a {\r\n    padding: 0.4rem 0;\r\n}#hamburger-dropdown-menu .sub_menu.right .menu .acf-nav-menu ul li ul li:hover {\r\n    font-weight: 600;\r\n}.expand-icon-header::before {\r\n    content: '+'; \r\n    font-size: 1.5rem;\r\n    padding-bottom: 10px;\r\n    opacity: 0.6; \r\n    cursor: pointer;\r\n    padding-right: 2px;\r\n    --tw-text-opacity: 1;\r\n    color: rgba(0, 114, 188, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.expand-icon-header::before {\r\n    color: rgb(0 114 188 / var(--tw-text-opacity));\r\n}\n}.retract-icon-header::before {\r\n    font-size: 2.25rem !important; \r\n}.retract-icon-header::before {\r\n    content: '-';\r\n    line-height: 0.75;\r\n    opacity: 0.6;\r\n    padding-right: 0.15rem;\r\n    cursor: pointer;\r\n    --tw-text-opacity: 1;\r\n    color: rgba(0, 114, 188, 1); \r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.retract-icon-header::before {\r\n    color: rgb(0 114 188 / var(--tw-text-opacity)); \r\n}\n}.arrow-svg {\r\n    width: 1rem;\r\n    margin-right: 3px;\r\n}/* left side */.left-menu-container .acf-nav-menu ul {\r\n    display: flex;\r\n    flex-direction: column;\r\n    gap: 0.75rem;\r\n    padding-top: 1rem;\r\n    opacity: 0.8;\r\n    font-size: 0.89rem;\r\n    --tw-text-opacity: 1;\r\n    color: rgba(0, 114, 188, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.left-menu-container .acf-nav-menu ul {\r\n    color: rgb(0 114 188 / var(--tw-text-opacity));\r\n}\n}@media (min-width: 768px) {\r\n    .left-menu-container .acf-nav-menu ul {\r\n        display: flex;\r\n        flex-direction: row;\r\n        gap: 1.5rem;\r\n        padding-top: 0.8rem;\r\n    }\r\n}.left-menu-container {\r\n    display: flex;\r\n    align-items: flex-end;\r\n}/* Main Nav */#primary-nav-container nav div ul {\r\n  display: flex;\r\n}#primary-nav-container {\r\n    cursor: pointer;\r\n}#primary-nav-container nav div ul .sub-menu {\r\n    position: absolute;\r\n    left: 0;\r\n    top: 100%;\r\n    padding: 0 0 1rem 10rem;\r\n    display: flex;\r\n    flex-direction: column;\r\n    z-index: 1000;\r\n    width: 100%;\r\n    --tw-bg-opacity: 1;\r\n    background-color: rgba(255, 255, 255, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n#primary-nav-container nav div ul .sub-menu {\r\n    background-color: rgb(255 255 255 / var(--tw-bg-opacity));\r\n}\n}#primary-nav-container nav div ul .sub-menu li {\r\n    padding: 0.5rem 0;\r\n}#primary-nav-container nav div ul li a:hover {\r\n    font-weight: 600;\r\n    position: relative;\r\n}#primary-nav-container nav div ul li a:hover::after {\r\n    content: \"\";\r\n    position: absolute;\r\n    left: 0;\r\n    right: 0;\r\n    bottom: -4px;\r\n    height: 1px;\r\n    background-color: rgba(0, 114, 188, 0.8);\r\n}@media (min-width: 768px) {\r\n    #primary-nav-container nav div > ul > li {\r\n        margin: 0 0.75rem;\r\n    }\r\n}/* Forms */.gform-body label {\r\n    font-weight: 500 !important;\r\n    font-size: 1rem !important;\r\n}.gform-body input, .gform-body textarea {\r\n    border-bottom: 1px solid grey;\r\n}.gfield input:focus, .gfield textarea:focus {\r\n    outline: none !important;\r\n}.gfield textarea {\r\n    resize: none;\r\n    max-height: 100px;\r\n}.gform_footer .button {\r\n    background-color: black;\r\n    color: white;\r\n    width: 100%;\r\n    border-radius: 30px;\r\n    padding: 15px 20px;\r\n    cursor: pointer;\r\n    display: flex;\r\n    justify-content: space-between;\r\n    font-size: 1rem;\r\n}@media (min-width: 768px){\r\n    .gform_footer {\r\n        max-width: 300px; \r\n    }\r\n}.gform_button {\r\n    padding: 10px 0 10px 30px !important; \r\n}.gform_button {\r\n    text-align: left; \r\n}@media (min-width: 768px){\r\n    .gform_button {\r\n        padding: 20px 0 20px 30px !important; \r\n    }\r\n    .gform_button {\r\n        text-align: left; \r\n    }\r\n}.gform_footer .button:hover, .gform_footer .button:focus{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(118, 118, 118, 1);\r\n    border: 2px solid black;\r\n    transition: background-color 0.3s ease;\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.gform_footer .button:hover, .gform_footer .button:focus{\r\n    background-color: rgb(118 118 118 / var(--tw-bg-opacity));\r\n  }\n}/* NEW MAP */.block-map {\r\n    background: #0E1E37;\r\n}.map-region {\r\n    position: relative;\r\n    z-index: 10;\r\n    /* border-color: #beb7ac; */\r\n}.world-map,\r\n.marker-location {\r\n    display: none;\r\n}@media (min-width: 768px) {\r\n\r\n    .world-map,\r\n    .marker-location {\r\n        display: block;\r\n    }\r\n}/* Dont use tailwind hidden as is add important to display, then you would need to add more specificity to your other classes... */.hide-item {\r\n    display: none;\r\n}.show-item {\r\n    display: block;\r\n}.marker-location.active {\r\n    z-index: 30 !important;\r\n}.marker-pin,\r\n.marker-pin-cluster-icon {\r\n    position: relative;\r\n    display: block;\r\n    width: 18px;\r\n    height: 18px;\r\n    border-radius: 100%;\r\n    cursor: pointer;\r\n    border-style: solid;\r\n    border-width: 1px;\r\n    border-color: #B2ABA0;\r\n    box-sizing: border-box;\r\n    overflow: hidden;\r\n    animation-name: colorChange;\r\n    animation-iteration-count: infinite;\r\n    animation-direction: alternate;\r\n}.marker-pin::before,\r\n.marker-pin-cluster-icon::before {\r\n    content: '';\r\n    position: absolute;\r\n    top: 50%;\r\n    left: 50%;\r\n    width: 100%;\r\n    height: 100%;\r\n    background-color: #B2ABA0;\r\n    border-radius: 100%;\r\n    transform: translate(-50%, -50%);\r\n    animation-name: shrinkColorChange;\r\n    animation-iteration-count: infinite;\r\n    animation-direction: alternate;\r\n}.marker-location.active .marker-pin {\r\n    animation-name: none;\r\n    width: 22px;\r\n    height: 22px;\r\n    border-style: solid;\r\n    border-color: #A48942;\r\n    border-width: 1px;\r\n    box-sizing: border-box;\r\n}.marker-location.active .marker-pin::before {\r\n    animation-name: none;\r\n    width: 12px;\r\n    height: 12px;\r\n    background: #A48942;\r\n}.marker-pin-cluster {\r\n    position: relative;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    gap: 10px;\r\n    border: solid 1px white;\r\n    border-radius: 20px;\r\n    padding: 10px 10px 10px 8px;\r\n    cursor: pointer;\r\n    background-color: #ffffff;\r\n    box-sizing: border-box;\r\n    overflow: hidden;\r\n}.marker-pin-cluster-text {\r\n    font-size: 14px;\r\n    color: #000;\r\n    line-height: 1;\r\n}@keyframes shrinkColorChange {\r\n\r\n    0% {\r\n        background-color: #B2ABA0;\r\n        transform: translate(-50%, -50%) scale(1.1);\r\n    }\r\n\r\n    100% {\r\n        background-color: #A48942;\r\n        transform: translate(-50%, -50%) scale(0.25);\r\n    }\r\n}@keyframes colorChange {\r\n\r\n    0% {\r\n        border-color: #B2ABA0;\r\n    }\r\n\r\n    100% {\r\n        border-color: #A48942;\r\n    }\r\n}[data-location=\"america-lst\"] .marker-pin,\r\n[data-location=\"america-lst\"] .marker-pin::before {\r\n    animation-duration: 0.9s;\r\n}[data-location=\"america-ameribolt-2\"] .marker-pin,\r\n[data-location=\"america-ameribolt-2\"] .marker-pin::before {\r\n    animation-duration: 1.1s;\r\n}[data-location=\"america-lfh\"] .marker-pin,\r\n[data-location=\"america-lfh\"] .marker-pin::before {\r\n    animation-duration: 1.3s;\r\n}[data-location=\"america-tlf\"] .marker-pin,\r\n[data-location=\"america-tlf\"] .marker-pin::before {\r\n    animation-duration: 1s;\r\n}[data-location=\"america-ameribolt-3\"] .marker-pin,\r\n[data-location=\"america-ameribolt-3\"] .marker-pin::before {\r\n    animation-duration: 1.2s;\r\n}[data-location=\"america-ameribolt-1\"] .marker-pin,\r\n[data-location=\"america-ameribolt-1\"] .marker-pin::before {\r\n    animation-duration: 1.125s;\r\n}[data-location=\"america-eh\"] .marker-pin,\r\n[data-location=\"america-eh\"] .marker-pin::before {\r\n    animation-duration: 1.1s;\r\n}[data-location=\"birmingham-4\"] .marker-pin,\r\n[data-location=\"birmingham-4\"] .marker-pin::before {\r\n    animation-duration: 0.9s;\r\n}[data-location=\"wolverhampton\"] .marker-pin,\r\n[data-location=\"wolverhampton\"] .marker-pin::before {\r\n    animation-duration: 1.1s;\r\n}[data-location=\"birmingham-1\"] .marker-pin,\r\n[data-location=\"birmingham-1\"] .marker-pin::before {\r\n    animation-duration: 1.3s;\r\n}[data-location=\"birmingham-2\"] .marker-pin,\r\n[data-location=\"birmingham-2\"] .marker-pin::before {\r\n    animation-duration: 1s;\r\n}[data-location=\"birmingham-3\"] .marker-pin,\r\n[data-location=\"birmingham-3\"] .marker-pin::before {\r\n    animation-duration: 1.2s;\r\n}[data-location=\"leeds\"] .marker-pin,\r\n[data-location=\"leeds\"] .marker-pin::before {\r\n    animation-duration: 1s;\r\n}[data-location=\"white-lea\"] .marker-pin,\r\n[data-location=\"white-lea\"] .marker-pin::before {\r\n    animation-duration: 1.2s;\r\n}[data-location=\"romania\"] .marker-pin,\r\n[data-location=\"romania\"] .marker-pin::before {\r\n    animation-duration: 1s;\r\n}[data-location=\"dubai-1\"] .marker-pin,\r\n[data-location=\"dubai-1\"] .marker-pin::before {\r\n    animation-duration: 1.2s;\r\n}[data-location=\"india\"] .marker-pin,\r\n[data-location=\"india\"] .marker-pin::before {\r\n    animation-duration: 1.3s;\r\n}[data-location=\"china\"] .marker-pin,\r\n[data-location=\"china\"] .marker-pin::before {\r\n    animation-duration: 1.1s;\r\n}[data-location=\"singapore\"] .marker-pin,\r\n[data-location=\"singapore\"] .marker-pin::before {\r\n    animation-duration: 1.3s;\r\n}[data-location=\"australia\"] .marker-pin,\r\n[data-location=\"australia\"] .marker-pin::before {\r\n    animation-duration: 0.9s;\r\n}[data-location] .marker-pin-cluster-icon,\r\n[data-location] .marker-pin-cluster-icon::before {\r\n    animation-duration: 1s;\r\n}/* Mobile styles */.continent-marker-container {\r\n    background-color: #15253F;\r\n}.marker-info {\r\n    display: none;\r\n}.marker-logo.open .marker-info {\r\n    display: block;\r\n}@media (min-width: 768px) {\r\n    .marker-info {\r\n        display: block;\r\n    }\r\n\r\n    .expand-icon-map {\r\n        display: none;\r\n    }\r\n}.expand-icon-map-mobile::before {\r\n    content: '+';\r\n    font-size: 1.5rem;\r\n}.open.expand-icon-map-mobile::before {\r\n    content: '-';\r\n}.marker-logo.open .expand-icon-map-mobile::before {\r\n    content: '-';\r\n}.embed-container > iframe {\r\n    width: 100%;\r\n    height: 80vh;\r\n}.pagination .navigation {\r\n    display: flex;\r\n    justify-content: center;\r\n}.pagination .navigation .nav-links .current {\r\n    color: black !important;\r\n    padding: 15px !important;\r\n    font-weight: 500 !important;\r\n}.pagination .navigation .nav-links .current {\r\n    display: inline-flex;\r\n    border: 2px solid #0072BC;\r\n    border-radius: 50%;\r\n    width: 1.5rem;\r\n    height: 1.5rem;\r\n    align-items: center;\r\n    justify-content: center;\r\n}.pagination .navigation .nav-links .page-numbers {\r\n    color: grey;\r\n    padding: 0 5px;\r\n}.pagination .navigation .nav-links .page-numbers:hover {\r\n    font-weight: 600;\r\n}.pagination .navigation .nav-links .prev, .pagination .navigation .nav-links .next { \r\n    color: black;\r\n}.pagination .navigation .nav-links .prev::after {\r\n    content: \"➔\";\r\n    display: inline-block;\r\n    transform: scaleX(-1);\r\n}.pagination .navigation .nav-links .next::after {\r\n    content: \"➔\"; \r\n}.news_archive .grid article a div button {\r\n    color: #0072BC;\r\n}/* Pagination for Carousel Block */.swiper-pagination-bullet{\r\n  --tw-bg-opacity: 1 !important;\r\n  background-color: rgba(255, 255, 255, 1) !important;\r\n    opacity: 1 !important;\r\n    height: 10px !important;\r\n    width: 10px !important;\r\n}.swiper-pagination-bullet{\r\n    padding: 5px;\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.swiper-pagination-bullet{\r\n    background-color: rgb(255 255 255 / var(--tw-bg-opacity)) !important;\r\n  }\n}.swiper-pagination-bullet-active {\r\n    background-color: transparent !important;\r\n}.swiper-pagination-bullet-active {\r\n    display: inline-block;\r\n    border: 1px solid #FFFFFF;\r\n    padding: 10px;\r\n    position: relative;\r\n    top: 5px;\r\n}.swiper-pagination-bullet-active::after {\r\n    display: block;\r\n    content: \"\";\r\n    --tw-bg-opacity: 1;\r\n    background-color: rgba(255, 255, 255, 1);\r\n    width: 4px;\r\n    height: 4px;\r\n    border-radius: 50%;\r\n    position: absolute;\r\n    top: 50%;\r\n    left: 50%;\r\n    transform: translate(-50%, -50%);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.swiper-pagination-bullet-active::after {\r\n    background-color: rgb(255 255 255 / var(--tw-bg-opacity));\r\n}\n}/*  This stylsheet was provided by Lonestar for inner iframe styling, empty classes/attributes have been removed */#gnewtonIframe {\r\n    padding: 0 1.5rem;\r\n}@media (min-width: 768px) {\r\n    #gnewtonIframe {\r\n        padding: 0 4rem;\r\n    }\r\n}@media (min-width: 1025px) {\r\n    #gnewtonIframe {\r\n        padding: 0 10rem;\r\n    }\r\n}/* Remove jobid location etc from the job description page. */#gnewtonJobDescription #gnewtonJobPosition,\r\n#gnewtonJobDescription #gnewtonJobLocation,\r\n#gnewtonJobDescription #gnewtonJobID,\r\n#gnewtonJobDescription #gnewtonJobOpening,\r\n#gnewtonJobDescription hr,\r\ntd#gnewtonJobLocationInfo {\r\n  display: none;\r\n}/* Remove application code box for returning applicants to online form. */#gnewtonApplicationBox * {\r\n  display: none;\r\n}/* Remove incorrect veteran status boxes on bottom of online application form. */#veteran31,\r\n#veteran32,\r\n#veteran33,\r\n#veteran34 {\r\n  margin-left: 40px;\r\n}/* Make sure that images and labels display properly. */label {\r\n  display: inline;\r\n}img {\r\n  display: inline;\r\n}/* Increased spacing for generic resume submission. */#gnewtonGeneric td {\r\n  padding-top: 20px !important;\r\n}/* Match fonts for the main page and submission page. */#gnewtonCareerBody * {\r\n  color: #000;\r\n  font-family: 'Signika';\r\n  font-size: 14px;\r\n  line-height: 23px;\r\n}#gnewtonLandingArea * {\r\n  color: #000;\r\n  font-family: 'Signika';\r\n  font-size: 14px;\r\n  line-height: 23px;\r\n}.gnewtonCareerGroupHeaderClass {\r\n  color: #000 !important;\r\n  font-family: 'Signika' !important;\r\n  font-size: 17px !important;\r\n  line-height: 25px !important;\r\n}.gnewtonCareerGroupHeaderClass {\r\n  font-weight: bold;\r\n}/* Match fonts for the links. */#gnewtonCareerBody a,\r\n#gnewtonLandingArea a,\r\ndiv#backToCareerHome a,\r\n#gnewtonLogo a.newton_policy {\r\n  color: #0072bc;\r\n\r\n  -webkit-text-decoration: underline;\r\n\r\n  text-decoration: underline;\r\n}#gnewtonCareerBody a:hover,\r\n#gnewtonLandingArea a:hover,\r\ndiv#backToCareerHome a:hover {\r\n  color: #0072bc;\r\n  -webkit-text-decoration: none;\r\n  text-decoration: none;\r\n}/* Fix the Clear All Fields link. Set width to 100 or 115px if wrapping occurs. */.button.newtonStoreReset.block {\r\n  color: rgb(52, 152, 219) !important;\r\n}.button.newtonStoreReset.block {\r\n  background-color: rgba(0, 0, 0, 0);\r\n}.button.newtonStoreReset.block:hover {\r\n  color: rgb(136, 189, 229) !important;\r\n}/* Fix Job Search Buttons */select#gnewtonLocation,\r\nselect#gnewtonDepartment {\r\n  width: 100%;\r\n}/* Fix Choose a File link. */label#resumeDropLocalFile {\r\n  color: #3498db;\r\n}/* Fix filename in uploaded resume blue box. */#resumeDropped span.filename {\r\n  color: white;\r\n}/* Hide department and location sort labels */.gnewtonSortByJob {\r\n  display: none !important;\r\n}.gnewtonSortByLocationOrDepartment {\r\n  display: none !important;\r\n}/* Fix remove link in uploaded resume blue box. */#resumeDropped .bar .closeBtn {\r\n  color: #aed6f1 !important;\r\n}#resumeDropped .bar .closeBtn {\r\n  -webkit-text-decoration: none;\r\n  text-decoration: none;\r\n}/* Bold section titles. */dt.gnewtonSectionTitleClass {\r\n  font-weight: bold;\r\n}/* Bold all p inside the application. */#gnewtonResumeFormTable p {\r\n  font-weight: bold;\r\n}/* Un-bold the Applicant's Statement section. */#gnewtonAppState p {\r\n  font-weight: normal;\r\n}/* Reposition the \"Yes\" and \"No\" inside the Min Qual buttons. */td.gnewtonQuestions div {\r\n  line-height: 25px !important;\r\n}/* Fix colors on attachment upload links. */label.emptyFileInput {\r\n  color: #3498db !important;\r\n}label.emptyFileInput:hover {\r\n  color: #88bde5 !important;\r\n}/* Bold uploaded attachment names. */div.filledFileInput span {\r\n  font-weight: bold;\r\n}/* Change Newton button colors to match. */#gnewtonCareerBody div.gnewtonBlueBtn,\r\n#gnewtonCareerBody button.gnewtonBlueBtn,\r\ndiv.gnewtonContinueBtn {\r\n  background-color: #0072bc !important;\r\n  border-radius: 0px !important;\r\n  font-family: 'Signika' !important;\r\n  text-align: center !important;\r\n}#gnewtonCareerBody div.gnewtonBlueBtn:hover,\r\n#gnewtonCareerBody button.gnewtonBlueBtn:hover,\r\ndiv.gnewtonContinueBtn:hover {\r\n  -webkit-text-decoration: underline !important;\r\n  text-decoration: underline !important;\r\n}#gnewtonCareerBody div.gnewtonBlueBtn.disabled,\r\ndiv#saveBtn.disabled,\r\n#gnewtonCareerBody button.gnewtonBlueBtn.disabled,\r\n#gnewtonCareerBody div.gnewtonBlueBtn[disabled],\r\n#gnewtonCareerBody button.gnewtonBlueBtn[disabled] {\r\n  background: #ccd3d8 !important;\r\n}/* Adjust Indeed button colors to match. */#gnewtonCareerBody #gnewtonJobDescriptionBtn > div > .indeed-apply-widget > a {\r\n  background: #3498db !important;\r\n}#gnewtonCareerBody\r\n  #gnewtonJobDescriptionBtn\r\n  > div\r\n  > .indeed-apply-widget\r\n  > a\r\n  > span\r\n  > span {\r\n  color: white !important;\r\n}#gnewtonCareerBody\r\n  #gnewtonJobDescriptionBtn\r\n  > div\r\n  > .indeed-apply-widget.indeed-apply-status-applied#indeed-apply-widget\r\n  > a:hover {\r\n  background: #88bde5 !important;\r\n}/* Adjust vertical alignment on EEO VEVRAA options. */form#gnewton-vevraa-form span.radio-label {\r\n  top: 0px !important;\r\n}form#gnewton-vevraa-form span.radio-label {\r\n  position: relative;\r\n}/* Fix search button text alignment. */div#gnewtonSearchBtn {\r\n  line-height: 18px;\r\n}div#gnewtonCareerBody {\r\n  margin: auto !important;\r\n}input[type='checkbox'] {\r\n  padding: 5px;\r\n}/*STYLING FOR MOBILE EXPERIENCE */@media only screen and (max-width: 500px) {\r\n  table.gnewtonJobFilter tr,\r\n  tbody,\r\n  td {\r\n    display: block;\r\n  }\r\n\r\n  input#gnewtonKeyword {\r\n    margin-bottom: 5px !important;\r\n  }\r\n  .gnewtonCareerGroupRowClass {\r\n    word-wrap: break-word !important;\r\n    white-space: normal !important;\r\n  }\r\n\r\n  .gnewtonJobLink a,\r\n  .gnewtonJobLink a:visited,\r\n  .gnewtonJobNode a,\r\n  .gnewtonJobNode a:visited,\r\n  .gnewtonNode a,\r\n  .gnewtonNode a:visited,\r\n  .gnewtonCareerGroupJobTitleClass a,\r\n  .gnewtonCareerGroupJobTitleClass {\r\n    white-space: normal !important;\r\n  }\r\n\r\n  #gnewtonCareerBody * {\r\n    font-size: 15px !important;\r\n  }\r\n}/* ! tailwindcss v3.3.2 | MIT License | https://tailwindcss.com *//*\n1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)\n2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)\n*/*,\n::before,\n::after {\n  box-sizing: border-box; /* 1 */\n  border-width: 0; /* 2 */\n  border-style: solid; /* 2 */\n  border-color: #e5e7eb; /* 2 */\n}::before,\n::after {\n  --tw-content: '';\n}/*\n1. Use a consistent sensible line-height in all browsers.\n2. Prevent adjustments of font size after orientation changes in iOS.\n3. Use a more readable tab size.\n4. Use the user's configured `sans` font-family by default.\n5. Use the user's configured `sans` font-feature-settings by default.\n6. Use the user's configured `sans` font-variation-settings by default.\n*/html {\n  line-height: 1.5; /* 1 */\n  -webkit-text-size-adjust: 100%; /* 2 */\n  -moz-tab-size: 4; /* 3 */\n  tab-size: 4; /* 3 */\n  font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, \"Noto Sans\", sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\"; /* 4 */\n  font-feature-settings: normal; /* 5 */\n  font-variation-settings: normal; /* 6 */\n}/*\n1. Remove the margin in all browsers.\n2. Inherit line-height from `html` so users can set them as a class directly on the `html` element.\n*/body {\n  margin: 0; /* 1 */\n  line-height: inherit; /* 2 */\n}/*\n1. Add the correct height in Firefox.\n2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)\n3. Ensure horizontal rules are visible by default.\n*/hr {\n  height: 0; /* 1 */\n  color: inherit; /* 2 */\n  border-top-width: 1px; /* 3 */\n}/*\nAdd the correct text decoration in Chrome, Edge, and Safari.\n*/abbr:where([title]) {\n  text-decoration: underline;\n  -webkit-text-decoration: underline dotted;\n          text-decoration: underline dotted;\n}/*\nRemove the default font size and weight for headings.\n*/h1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  font-size: inherit;\n  font-weight: inherit;\n}/*\nReset links to optimize for opt-in styling instead of opt-out.\n*/a {\n  color: inherit;\n  text-decoration: inherit;\n}/*\nAdd the correct font weight in Edge and Safari.\n*/b,\nstrong {\n  font-weight: bolder;\n}/*\n1. Use the user's configured `mono` font family by default.\n2. Correct the odd `em` font sizing in all browsers.\n*/code,\nkbd,\nsamp,\npre {\n  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace; /* 1 */\n  font-size: 1em; /* 2 */\n}/*\nAdd the correct font size in all browsers.\n*/small {\n  font-size: 80%;\n}/*\nPrevent `sub` and `sup` elements from affecting the line height in all browsers.\n*/sub,\nsup {\n  font-size: 75%;\n  line-height: 0;\n  position: relative;\n  vertical-align: baseline;\n}sub {\n  bottom: -0.25em;\n}sup {\n  top: -0.5em;\n}/*\n1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)\n2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)\n3. Remove gaps between table borders by default.\n*/table {\n  text-indent: 0; /* 1 */\n  border-color: inherit; /* 2 */\n  border-collapse: collapse; /* 3 */\n}/*\n1. Change the font styles in all browsers.\n2. Remove the margin in Firefox and Safari.\n3. Remove default padding in all browsers.\n*/button,\ninput,\noptgroup,\nselect,\ntextarea {\n  font-family: inherit; /* 1 */\n  font-size: 100%; /* 1 */\n  font-weight: inherit; /* 1 */\n  line-height: inherit; /* 1 */\n  color: inherit; /* 1 */\n  margin: 0; /* 2 */\n  padding: 0; /* 3 */\n}/*\nRemove the inheritance of text transform in Edge and Firefox.\n*/button,\nselect {\n  text-transform: none;\n}/*\n1. Correct the inability to style clickable types in iOS and Safari.\n2. Remove default button styles.\n*/button,\n[type='button'],\n[type='reset'],\n[type='submit'] {\n  -webkit-appearance: button; /* 1 */\n  background-color: transparent; /* 2 */\n  background-image: none; /* 2 */\n}/*\nUse the modern Firefox focus style for all focusable elements.\n*/:-moz-focusring {\n  outline: auto;\n}/*\nRemove the additional `:invalid` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)\n*/:-moz-ui-invalid {\n  box-shadow: none;\n}/*\nAdd the correct vertical alignment in Chrome and Firefox.\n*/progress {\n  vertical-align: baseline;\n}/*\nCorrect the cursor style of increment and decrement buttons in Safari.\n*/::-webkit-inner-spin-button,\n::-webkit-outer-spin-button {\n  height: auto;\n}/*\n1. Correct the odd appearance in Chrome and Safari.\n2. Correct the outline style in Safari.\n*/[type='search'] {\n  -webkit-appearance: textfield; /* 1 */\n  outline-offset: -2px; /* 2 */\n}/*\nRemove the inner padding in Chrome and Safari on macOS.\n*/::-webkit-search-decoration {\n  -webkit-appearance: none;\n}/*\n1. Correct the inability to style clickable types in iOS and Safari.\n2. Change font properties to `inherit` in Safari.\n*/::-webkit-file-upload-button {\n  -webkit-appearance: button; /* 1 */\n  font: inherit; /* 2 */\n}/*\nAdd the correct display in Chrome and Safari.\n*/summary {\n  display: list-item;\n}/*\nRemoves the default spacing and border for appropriate elements.\n*/blockquote,\ndl,\ndd,\nh1,\nh2,\nh3,\nh4,\nh5,\nh6,\nhr,\nfigure,\np,\npre {\n  margin: 0;\n}fieldset {\n  margin: 0;\n  padding: 0;\n}legend {\n  padding: 0;\n}ol,\nul,\nmenu {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}/*\nPrevent resizing textareas horizontally by default.\n*/textarea {\n  resize: vertical;\n}/*\n1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)\n2. Set the default placeholder color to the user's configured gray 400 color.\n*/input::placeholder,\ntextarea::placeholder {\n  opacity: 1; /* 1 */\n  color: #9ca3af; /* 2 */\n}/*\nSet the default cursor for buttons.\n*/button,\n[role=\"button\"] {\n  cursor: pointer;\n}/*\nMake sure disabled buttons don't get the pointer cursor.\n*/:disabled {\n  cursor: default;\n}/*\n1. Make replaced elements `display: block` by default. (https://github.com/mozdevs/cssremedy/issues/14)\n2. Add `vertical-align: middle` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)\n   This can trigger a poorly considered lint error in some tools but is included by design.\n*/img,\nsvg,\nvideo,\ncanvas,\naudio,\niframe,\nembed,\nobject {\n  display: block; /* 1 */\n  vertical-align: middle; /* 2 */\n}/*\nConstrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)\n*/img,\nvideo {\n  max-width: 100%;\n  height: auto;\n}/* Make elements with the HTML hidden attribute stay hidden by default */[hidden] {\n  display: none;\n}*, ::before, ::after{\r\n  --tw-border-spacing-x: 0;\r\n  --tw-border-spacing-y: 0;\r\n  --tw-translate-x: 0;\r\n  --tw-translate-y: 0;\r\n  --tw-rotate: 0;\r\n  --tw-skew-x: 0;\r\n  --tw-skew-y: 0;\r\n  --tw-scale-x: 1;\r\n  --tw-scale-y: 1;\r\n  --tw-pan-x:  ;\r\n  --tw-pan-y:  ;\r\n  --tw-pinch-zoom:  ;\r\n  --tw-scroll-snap-strictness: proximity;\r\n  --tw-gradient-from-position:  ;\r\n  --tw-gradient-via-position:  ;\r\n  --tw-gradient-to-position:  ;\r\n  --tw-ordinal:  ;\r\n  --tw-slashed-zero:  ;\r\n  --tw-numeric-figure:  ;\r\n  --tw-numeric-spacing:  ;\r\n  --tw-numeric-fraction:  ;\r\n  --tw-ring-inset:  ;\r\n  --tw-ring-offset-width: 0px;\r\n  --tw-ring-offset-color: #fff;\r\n  --tw-ring-color: rgba(59, 130, 246, 0.5);\r\n  --tw-ring-offset-shadow: 0 0 rgba(0,0,0,0);\r\n  --tw-ring-shadow: 0 0 rgba(0,0,0,0);\r\n  --tw-shadow: 0 0 rgba(0,0,0,0);\r\n  --tw-shadow-colored: 0 0 rgba(0,0,0,0);\r\n  --tw-blur:  ;\r\n  --tw-brightness:  ;\r\n  --tw-contrast:  ;\r\n  --tw-grayscale:  ;\r\n  --tw-hue-rotate:  ;\r\n  --tw-invert:  ;\r\n  --tw-saturate:  ;\r\n  --tw-sepia:  ;\r\n  --tw-drop-shadow:  ;\r\n  --tw-backdrop-blur:  ;\r\n  --tw-backdrop-brightness:  ;\r\n  --tw-backdrop-contrast:  ;\r\n  --tw-backdrop-grayscale:  ;\r\n  --tw-backdrop-hue-rotate:  ;\r\n  --tw-backdrop-invert:  ;\r\n  --tw-backdrop-opacity:  ;\r\n  --tw-backdrop-saturate:  ;\r\n  --tw-backdrop-sepia:  ;\r\n}::backdrop{\r\n  --tw-border-spacing-x: 0;\r\n  --tw-border-spacing-y: 0;\r\n  --tw-translate-x: 0;\r\n  --tw-translate-y: 0;\r\n  --tw-rotate: 0;\r\n  --tw-skew-x: 0;\r\n  --tw-skew-y: 0;\r\n  --tw-scale-x: 1;\r\n  --tw-scale-y: 1;\r\n  --tw-pan-x:  ;\r\n  --tw-pan-y:  ;\r\n  --tw-pinch-zoom:  ;\r\n  --tw-scroll-snap-strictness: proximity;\r\n  --tw-gradient-from-position:  ;\r\n  --tw-gradient-via-position:  ;\r\n  --tw-gradient-to-position:  ;\r\n  --tw-ordinal:  ;\r\n  --tw-slashed-zero:  ;\r\n  --tw-numeric-figure:  ;\r\n  --tw-numeric-spacing:  ;\r\n  --tw-numeric-fraction:  ;\r\n  --tw-ring-inset:  ;\r\n  --tw-ring-offset-width: 0px;\r\n  --tw-ring-offset-color: #fff;\r\n  --tw-ring-color: rgba(59, 130, 246, 0.5);\r\n  --tw-ring-offset-shadow: 0 0 rgba(0,0,0,0);\r\n  --tw-ring-shadow: 0 0 rgba(0,0,0,0);\r\n  --tw-shadow: 0 0 rgba(0,0,0,0);\r\n  --tw-shadow-colored: 0 0 rgba(0,0,0,0);\r\n  --tw-blur:  ;\r\n  --tw-brightness:  ;\r\n  --tw-contrast:  ;\r\n  --tw-grayscale:  ;\r\n  --tw-hue-rotate:  ;\r\n  --tw-invert:  ;\r\n  --tw-saturate:  ;\r\n  --tw-sepia:  ;\r\n  --tw-drop-shadow:  ;\r\n  --tw-backdrop-blur:  ;\r\n  --tw-backdrop-brightness:  ;\r\n  --tw-backdrop-contrast:  ;\r\n  --tw-backdrop-grayscale:  ;\r\n  --tw-backdrop-hue-rotate:  ;\r\n  --tw-backdrop-invert:  ;\r\n  --tw-backdrop-opacity:  ;\r\n  --tw-backdrop-saturate:  ;\r\n  --tw-backdrop-sepia:  ;\r\n}.container{\r\n  width: 100%;\r\n}@media (min-width: 640px){.container{\r\n    max-width: 640px;\r\n  }\r\n}@media (min-width: 768px){.container{\r\n    max-width: 768px;\r\n  }\r\n}@media (min-width: 1025px){.container{\r\n    max-width: 1025px;\r\n  }\r\n}@media (min-width: 1400px){.container{\r\n    max-width: 1400px;\r\n  }\r\n}.sr-only{\r\n  position: absolute;\r\n  width: 1px;\r\n  height: 1px;\r\n  padding: 0;\r\n  margin: -1px;\r\n  overflow: hidden;\r\n  clip: rect(0, 0, 0, 0);\r\n  white-space: nowrap;\r\n  border-width: 0;\r\n}.\\!static{\r\n  position: static !important;\r\n}.static{\r\n  position: static;\r\n}.absolute{\r\n  position: absolute;\r\n}.relative{\r\n  position: relative;\r\n}.inset-0{\r\n  top: 0px;\r\n  right: 0px;\r\n  bottom: 0px;\r\n  left: 0px;\r\n}.bottom-0{\r\n  bottom: 0px;\r\n}.left-0{\r\n  left: 0px;\r\n}.left-2{\r\n  left: 0.5rem;\r\n}.top-\\[355px\\]{\r\n  top: 355px;\r\n}.top-\\[380px\\]{\r\n  top: 380px;\r\n}.z-10{\r\n  z-index: 10;\r\n}.col-span-1{\r\n  grid-column: span 1 / span 1;\r\n}.col-span-2{\r\n  grid-column: span 2 / span 2;\r\n}.col-span-3{\r\n  grid-column: span 3 / span 3;\r\n}.my-4{\r\n  margin-top: 1rem;\r\n  margin-bottom: 1rem;\r\n}.my-6{\r\n  margin-top: 1.5rem;\r\n  margin-bottom: 1.5rem;\r\n}.\\!ml-2{\r\n  margin-left: 0.5rem !important;\r\n}.\\!mr-2{\r\n  margin-right: 0.5rem !important;\r\n}.\\!mt-0{\r\n  margin-top: 0px !important;\r\n}.mb-0{\r\n  margin-bottom: 0px;\r\n}.mb-0\\.5{\r\n  margin-bottom: 0.125rem;\r\n}.mb-4{\r\n  margin-bottom: 1rem;\r\n}.mb-6{\r\n  margin-bottom: 1.5rem;\r\n}.ml-2{\r\n  margin-left: 0.5rem;\r\n}.ml-3{\r\n  margin-left: 0.75rem;\r\n}.ml-auto{\r\n  margin-left: auto;\r\n}.mr-0{\r\n  margin-right: 0px;\r\n}.mt-0{\r\n  margin-top: 0px;\r\n}.mt-0\\.5{\r\n  margin-top: 0.125rem;\r\n}.mt-3{\r\n  margin-top: 0.75rem;\r\n}.mt-4{\r\n  margin-top: 1rem;\r\n}.mt-6{\r\n  margin-top: 1.5rem;\r\n}.mt-8{\r\n  margin-top: 2rem;\r\n}.block{\r\n  display: block;\r\n}.inline-block{\r\n  display: inline-block;\r\n}.inline{\r\n  display: inline;\r\n}.flex{\r\n  display: flex;\r\n}.grid{\r\n  display: grid;\r\n}.hidden{\r\n  display: none;\r\n}.h-0{\r\n  height: 0px;\r\n}.h-0\\.5{\r\n  height: 0.125rem;\r\n}.h-14{\r\n  height: 3.5rem;\r\n}.h-4{\r\n  height: 1rem;\r\n}.h-6{\r\n  height: 1.5rem;\r\n}.h-8{\r\n  height: 2rem;\r\n}.h-\\[1px\\]{\r\n  height: 1px;\r\n}.h-\\[216px\\]{\r\n  height: 216px;\r\n}.h-\\[229px\\]{\r\n  height: 229px;\r\n}.h-\\[471px\\]{\r\n  height: 471px;\r\n}.h-\\[685px\\]{\r\n  height: 685px;\r\n}.h-\\[75vh\\]{\r\n  height: 75vh;\r\n}.h-auto{\r\n  height: auto;\r\n}.h-full{\r\n  height: 100%;\r\n}.h-px{\r\n  height: 1px;\r\n}.max-h-10{\r\n  max-height: 2.5rem;\r\n}.max-h-20{\r\n  max-height: 5rem;\r\n}.max-h-6{\r\n  max-height: 1.5rem;\r\n}.max-h-\\[80vh\\]{\r\n  max-height: 80vh;\r\n}.max-h-full{\r\n  max-height: 100%;\r\n}.min-h-\\[50vh\\]{\r\n  min-height: 50vh;\r\n}.w-16{\r\n  width: 4rem;\r\n}.w-3{\r\n  width: 0.75rem;\r\n}.w-3\\.5{\r\n  width: 0.875rem;\r\n}.w-3\\/5{\r\n  width: 60%;\r\n}.w-4{\r\n  width: 1rem;\r\n}.w-4\\/5{\r\n  width: 80%;\r\n}.w-6{\r\n  width: 1.5rem;\r\n}.w-8{\r\n  width: 2rem;\r\n}.w-8\\/12{\r\n  width: 66.666667%;\r\n}.w-\\[435px\\]{\r\n  width: 435px;\r\n}.w-full{\r\n  width: 100%;\r\n}.max-w-\\[300px\\]{\r\n  max-width: 300px;\r\n}.flex-grow{\r\n  flex-grow: 1;\r\n}.\\!rotate-180{\r\n  --tw-rotate: 180deg !important;\r\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(180deg) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y)) !important;\r\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y)) !important;\r\n}.transform{\r\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\r\n}.cursor-grab{\r\n  cursor: grab;\r\n}.cursor-pointer{\r\n  cursor: pointer;\r\n}.resize{\r\n  resize: both;\r\n}.grid-cols-1{\r\n  grid-template-columns: repeat(1, minmax(0, 1fr));\r\n}.grid-cols-\\[minmax\\(100px\\2c _2fr\\)_3fr\\]{\r\n  grid-template-columns: minmax(100px, 2fr) 3fr;\r\n}.flex-col{\r\n  flex-direction: column;\r\n}.flex-col-reverse{\r\n  flex-direction: column-reverse;\r\n}.flex-wrap{\r\n  flex-wrap: wrap;\r\n}.items-start{\r\n  align-items: flex-start;\r\n}.items-center{\r\n  align-items: center;\r\n}.justify-end{\r\n  justify-content: flex-end;\r\n}.justify-center{\r\n  justify-content: center;\r\n}.justify-between{\r\n  justify-content: space-between;\r\n}.justify-around{\r\n  justify-content: space-around;\r\n}.gap-10{\r\n  gap: 2.5rem;\r\n}.gap-14{\r\n  gap: 3.5rem;\r\n}.gap-4{\r\n  gap: 1rem;\r\n}.gap-5{\r\n  gap: 1.25rem;\r\n}.gap-8{\r\n  gap: 2rem;\r\n}.gap-\\[10px\\]{\r\n  gap: 10px;\r\n}.gap-\\[30px\\]{\r\n  gap: 30px;\r\n}.gap-y-10{\r\n  row-gap: 2.5rem;\r\n}.space-y-3 > :not([hidden]) ~ :not([hidden]){\r\n  --tw-space-y-reverse: 0;\r\n  margin-top: calc(0.75rem * (1 - 0));\r\n  margin-top: calc(0.75rem * (1 - var(--tw-space-y-reverse)));\r\n  margin-top: calc(0.75rem * calc(1 - 0));\r\n  margin-top: calc(0.75rem * calc(1 - var(--tw-space-y-reverse)));\r\n  margin-bottom: calc(0.75rem * 0);\r\n  margin-bottom: calc(0.75rem * var(--tw-space-y-reverse));\r\n}.self-center{\r\n  align-self: center;\r\n}.overflow-hidden{\r\n  overflow: hidden;\r\n}.break-words{\r\n  word-wrap: break-word;\r\n}.rounded-full{\r\n  border-radius: 9999px;\r\n}.rounded-l-full{\r\n  border-top-left-radius: 9999px;\r\n  border-bottom-left-radius: 9999px;\r\n}.rounded-r-full{\r\n  border-top-right-radius: 9999px;\r\n  border-bottom-right-radius: 9999px;\r\n}.border-2{\r\n  border-width: 2px;\r\n}.border-b-2{\r\n  border-bottom-width: 2px;\r\n}.border-t{\r\n  border-top-width: 1px;\r\n}.border-t-2{\r\n  border-top-width: 2px;\r\n}.border-black{\r\n  --tw-border-opacity: 1;\r\n  border-color: rgba(0, 0, 0, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.border-black{\r\n    border-color: rgb(0 0 0 / var(--tw-border-opacity));\r\n  }\n}.border-grey{\r\n  --tw-border-opacity: 1;\r\n  border-color: rgba(118, 118, 118, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.border-grey{\r\n    border-color: rgb(118 118 118 / var(--tw-border-opacity));\r\n  }\n}.border-t-grey{\r\n  --tw-border-opacity: 1;\r\n  border-top-color: rgba(118, 118, 118, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.border-t-grey{\r\n    border-top-color: rgb(118 118 118 / var(--tw-border-opacity));\r\n  }\n}.border-opacity-50{\r\n  --tw-border-opacity: 0.5;\r\n}.bg-black{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(0, 0, 0, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.bg-black{\r\n    background-color: rgb(0 0 0 / var(--tw-bg-opacity));\r\n  }\n}.bg-blue{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(0, 114, 188, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.bg-blue{\r\n    background-color: rgb(0 114 188 / var(--tw-bg-opacity));\r\n  }\n}.bg-green-400{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(74, 222, 128, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.bg-green-400{\r\n    background-color: rgb(74 222 128 / var(--tw-bg-opacity));\r\n  }\n}.bg-grey{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(118, 118, 118, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.bg-grey{\r\n    background-color: rgb(118 118 118 / var(--tw-bg-opacity));\r\n  }\n}.bg-indigo-400{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(129, 140, 248, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.bg-indigo-400{\r\n    background-color: rgb(129 140 248 / var(--tw-bg-opacity));\r\n  }\n}.bg-red-400{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(248, 113, 113, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.bg-red-400{\r\n    background-color: rgb(248 113 113 / var(--tw-bg-opacity));\r\n  }\n}.bg-white{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(255, 255, 255, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.bg-white{\r\n    background-color: rgb(255 255 255 / var(--tw-bg-opacity));\r\n  }\n}.bg-yellow-400{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(250, 204, 21, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.bg-yellow-400{\r\n    background-color: rgb(250 204 21 / var(--tw-bg-opacity));\r\n  }\n}.bg-gradient-to-t{\r\n  background-image: linear-gradient(to top, var(--tw-gradient-stops));\r\n}.from-\\[rgba\\(0\\2c 0\\2c 0\\2c 0\\.3\\)\\]{\r\n  --tw-gradient-from: rgba(0,0,0,0.3) var(--tw-gradient-from-position);\r\n  --tw-gradient-to: rgba(0, 0, 0, 0) var(--tw-gradient-to-position);\r\n  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);\r\n}.to-transparent{\r\n  --tw-gradient-to: transparent var(--tw-gradient-to-position);\r\n}.bg-cover{\r\n  background-size: cover;\r\n}.bg-center{\r\n  background-position: center;\r\n}.object-contain{\r\n  object-fit: contain;\r\n}.object-cover{\r\n  object-fit: cover;\r\n}.p-0{\r\n  padding: 0px;\r\n}.p-5{\r\n  padding: 1.25rem;\r\n}.p-\\[0\\.25rem\\]{\r\n  padding: 0.25rem;\r\n}.px-2{\r\n  padding-left: 0.5rem;\r\n  padding-right: 0.5rem;\r\n}.px-4{\r\n  padding-left: 1rem;\r\n  padding-right: 1rem;\r\n}.px-5{\r\n  padding-left: 1.25rem;\r\n  padding-right: 1.25rem;\r\n}.px-6{\r\n  padding-left: 1.5rem;\r\n  padding-right: 1.5rem;\r\n}.px-8{\r\n  padding-left: 2rem;\r\n  padding-right: 2rem;\r\n}.py-1{\r\n  padding-top: 0.25rem;\r\n  padding-bottom: 0.25rem;\r\n}.py-2{\r\n  padding-top: 0.5rem;\r\n  padding-bottom: 0.5rem;\r\n}.py-3{\r\n  padding-top: 0.75rem;\r\n  padding-bottom: 0.75rem;\r\n}.py-4{\r\n  padding-top: 1rem;\r\n  padding-bottom: 1rem;\r\n}.py-5{\r\n  padding-top: 1.25rem;\r\n  padding-bottom: 1.25rem;\r\n}.py-6{\r\n  padding-top: 1.5rem;\r\n  padding-bottom: 1.5rem;\r\n}.py-8{\r\n  padding-top: 2rem;\r\n  padding-bottom: 2rem;\r\n}.pb-1{\r\n  padding-bottom: 0.25rem;\r\n}.pb-10{\r\n  padding-bottom: 2.5rem;\r\n}.pb-14{\r\n  padding-bottom: 3.5rem;\r\n}.pb-2{\r\n  padding-bottom: 0.5rem;\r\n}.pb-20{\r\n  padding-bottom: 5rem;\r\n}.pb-3{\r\n  padding-bottom: 0.75rem;\r\n}.pb-4{\r\n  padding-bottom: 1rem;\r\n}.pb-6{\r\n  padding-bottom: 1.5rem;\r\n}.pb-7{\r\n  padding-bottom: 1.75rem;\r\n}.pb-8{\r\n  padding-bottom: 2rem;\r\n}.pl-4{\r\n  padding-left: 1rem;\r\n}.pl-5{\r\n  padding-left: 1.25rem;\r\n}.pr-10{\r\n  padding-right: 2.5rem;\r\n}.pr-2{\r\n  padding-right: 0.5rem;\r\n}.pr-6{\r\n  padding-right: 1.5rem;\r\n}.pt-1{\r\n  padding-top: 0.25rem;\r\n}.pt-2{\r\n  padding-top: 0.5rem;\r\n}.pt-3{\r\n  padding-top: 0.75rem;\r\n}.pt-4{\r\n  padding-top: 1rem;\r\n}.pt-5{\r\n  padding-top: 1.25rem;\r\n}.pt-7{\r\n  padding-top: 1.75rem;\r\n}.pt-8{\r\n  padding-top: 2rem;\r\n}.\\!text-right{\r\n  text-align: right !important;\r\n}.\\!text-base{\r\n  font-size: 1rem !important;\r\n}.\\!text-lg{\r\n  font-size: 1.334rem !important;\r\n}.\\!text-sm{\r\n  font-size: 0.89rem !important;\r\n}.\\!text-xl{\r\n  font-size: 1.6rem !important;\r\n}.text-2xl{\r\n  font-size: 1.75rem;\r\n}.text-base{\r\n  font-size: 1rem;\r\n}.text-sm{\r\n  font-size: 0.89rem;\r\n}.text-xl{\r\n  font-size: 1.6rem;\r\n}.text-xxl{\r\n  font-size: 2.24rem;\r\n}.\\!font-bold{\r\n  font-weight: 700 !important;\r\n}.\\!font-medium{\r\n  font-weight: 500 !important;\r\n}.font-bold{\r\n  font-weight: 700;\r\n}.font-medium{\r\n  font-weight: 500;\r\n}.font-semibold{\r\n  font-weight: 600;\r\n}.uppercase{\r\n  text-transform: uppercase;\r\n}.leading-4{\r\n  line-height: 1rem;\r\n}.leading-normal{\r\n  line-height: 1.3;\r\n}.leading-relaxed{\r\n  line-height: 1.4;\r\n}.leading-snug{\r\n  line-height: 1.2;\r\n}.\\!text-black{\r\n  --tw-text-opacity: 1 !important;\r\n  color: rgba(0, 0, 0, 1) !important;\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.\\!text-black{\r\n    color: rgb(0 0 0 / var(--tw-text-opacity)) !important;\r\n  }\n}.\\!text-black\\/80{\r\n  color: rgba(0, 0, 0, 0.8) !important;\r\n}.text-black{\r\n  --tw-text-opacity: 1;\r\n  color: rgba(0, 0, 0, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.text-black{\r\n    color: rgb(0 0 0 / var(--tw-text-opacity));\r\n  }\n}.text-blue{\r\n  --tw-text-opacity: 1;\r\n  color: rgba(0, 114, 188, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.text-blue{\r\n    color: rgb(0 114 188 / var(--tw-text-opacity));\r\n  }\n}.text-green-50{\r\n  --tw-text-opacity: 1;\r\n  color: rgba(240, 253, 244, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.text-green-50{\r\n    color: rgb(240 253 244 / var(--tw-text-opacity));\r\n  }\n}.text-grey{\r\n  --tw-text-opacity: 1;\r\n  color: rgba(118, 118, 118, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.text-grey{\r\n    color: rgb(118 118 118 / var(--tw-text-opacity));\r\n  }\n}.text-indigo-50{\r\n  --tw-text-opacity: 1;\r\n  color: rgba(238, 242, 255, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.text-indigo-50{\r\n    color: rgb(238 242 255 / var(--tw-text-opacity));\r\n  }\n}.text-red-50{\r\n  --tw-text-opacity: 1;\r\n  color: rgba(254, 242, 242, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.text-red-50{\r\n    color: rgb(254 242 242 / var(--tw-text-opacity));\r\n  }\n}.text-white{\r\n  --tw-text-opacity: 1;\r\n  color: rgba(255, 255, 255, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.text-white{\r\n    color: rgb(255 255 255 / var(--tw-text-opacity));\r\n  }\n}.text-yellow-50{\r\n  --tw-text-opacity: 1;\r\n  color: rgba(254, 252, 232, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.text-yellow-50{\r\n    color: rgb(254 252 232 / var(--tw-text-opacity));\r\n  }\n}.underline{\r\n  text-decoration-line: underline;\r\n}.opacity-30{\r\n  opacity: 0.3;\r\n}.opacity-60{\r\n  opacity: 0.6;\r\n}.shadow-lg{\r\n  --tw-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);\r\n  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);\r\n  box-shadow: 0 0 rgba(0,0,0,0), 0 0 rgba(0,0,0,0), 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);\r\n  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);\r\n}.outline{\r\n  outline-style: solid;\r\n}.outline-1{\r\n  outline-width: 1px;\r\n}.transition-all{\r\n  transition-property: all;\r\n  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);\r\n  transition-duration: 150ms;\r\n}.transition-transform{\r\n  transition-property: transform;\r\n  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);\r\n  transition-duration: 150ms;\r\n}.duration-300{\r\n  transition-duration: 300ms;\r\n}/* GLOBAL STYLES */html {\r\n    font-size: 18px;\r\n}/* Fonts */@font-face {\r\n    src: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") format(\"woff2\"), url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ") format(\"woff\");\r\n    font-family: \"ITCAvantGardeGothic\";\r\n    font-weight: 700;\r\n}@font-face {\r\n    src: url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ") format(\"woff2\"), url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ") format(\"woff\");\r\n    font-family: \"ITCAvantGardeGothic\";\r\n    font-weight: 600;\r\n}@font-face {\r\n    src: url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") format(\"woff2\"), url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ") format(\"woff\");\r\n    font-family: \"ITCAvantGardeGothic\";\r\n    font-weight: 500;\r\n}/* Custom Global Styles */body {\r\n  font-family: 'ITCAvantGardeGothic', sans-serif;\r\n}.hidden {\r\n    display: none !important;\r\n}.after\\:\\!text-sm::after{\r\n  font-size: 0.89rem !important;\r\n}.after\\:\\!text-sm::after{\r\n  content: var(--tw-content);\r\n}.after\\:\\!content-\\[\\'\\'\\]::after{\r\n  --tw-content: '' !important;\r\n  content: '' !important;\r\n  content: var(--tw-content) !important;\r\n}.hover\\:-translate-y-2:hover{\r\n  --tw-translate-y: -0.5rem;\r\n  transform: translate(var(--tw-translate-x), -0.5rem) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\r\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\r\n}.hover\\:border-2:hover{\r\n  border-width: 2px;\r\n}.hover\\:border-black:hover{\r\n  --tw-border-opacity: 1;\r\n  border-color: rgba(0, 0, 0, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.hover\\:border-black:hover{\r\n    border-color: rgb(0 0 0 / var(--tw-border-opacity));\r\n  }\n}.hover\\:bg-grey:hover{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(118, 118, 118, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.hover\\:bg-grey:hover{\r\n    background-color: rgb(118 118 118 / var(--tw-bg-opacity));\r\n  }\n}.hover\\:font-semibold:hover{\r\n  font-weight: 600;\r\n}.hover\\:outline-\\[3px\\]:hover{\r\n  outline-width: 3px;\r\n}.focus\\:not-sr-only:focus{\r\n  position: static;\r\n  width: auto;\r\n  height: auto;\r\n  padding: 0;\r\n  margin: 0;\r\n  overflow: visible;\r\n  clip: auto;\r\n  white-space: normal;\r\n}.focus\\:-translate-y-2:focus{\r\n  --tw-translate-y: -0.5rem;\r\n  transform: translate(var(--tw-translate-x), -0.5rem) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\r\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\r\n}.focus\\:font-semibold:focus{\r\n  font-weight: 600;\r\n}.focus\\:outline-\\[3px\\]:focus{\r\n  outline-width: 3px;\r\n}@media (min-width: 768px){.md\\:absolute{\r\n    position: absolute;\r\n  }.md\\:bottom-\\[30px\\]{\r\n    bottom: 30px;\r\n  }.md\\:left-8{\r\n    left: 2rem;\r\n  }.md\\:left-\\[2\\.5rem\\]{\r\n    left: 2.5rem;\r\n  }.md\\:right-\\[30px\\]{\r\n    right: 30px;\r\n  }.md\\:top-\\[2rem\\]{\r\n    top: 2rem;\r\n  }.md\\:top-\\[375px\\]{\r\n    top: 375px;\r\n  }.md\\:top-\\[400px\\]{\r\n    top: 400px;\r\n  }.md\\:my-8{\r\n    margin-top: 2rem;\r\n    margin-bottom: 2rem;\r\n  }.md\\:\\!block{\r\n    display: block !important;\r\n  }.md\\:flex{\r\n    display: flex;\r\n  }.md\\:hidden{\r\n    display: none;\r\n  }.md\\:h-1\\/3{\r\n    height: 33.333333%;\r\n  }.md\\:max-h-16{\r\n    max-height: 4rem;\r\n  }.md\\:w-1\\/2{\r\n    width: 50%;\r\n  }.md\\:w-1\\/3{\r\n    width: 33.333333%;\r\n  }.md\\:w-2\\/3{\r\n    width: 66.666667%;\r\n  }.md\\:w-20{\r\n    width: 5rem;\r\n  }.md\\:w-4\\/5{\r\n    width: 80%;\r\n  }.md\\:w-72{\r\n    width: 18rem;\r\n  }.md\\:w-full{\r\n    width: 100%;\r\n  }.md\\:w-px{\r\n    width: 1px;\r\n  }.md\\:max-w-\\[26rem\\]{\r\n    max-width: 26rem;\r\n  }.md\\:cursor-default{\r\n    cursor: default;\r\n  }.md\\:grid-cols-2{\r\n    grid-template-columns: repeat(2, minmax(0, 1fr));\r\n  }.md\\:grid-cols-3{\r\n    grid-template-columns: repeat(3, minmax(0, 1fr));\r\n  }.md\\:grid-cols-5{\r\n    grid-template-columns: repeat(5, minmax(0, 1fr));\r\n  }.md\\:grid-cols-\\[45\\%_45\\%_10\\%\\]{\r\n    grid-template-columns: 45% 45% 10%;\r\n  }.md\\:flex-row{\r\n    flex-direction: row;\r\n  }.md\\:flex-row-reverse{\r\n    flex-direction: row-reverse;\r\n  }.md\\:flex-nowrap{\r\n    flex-wrap: nowrap;\r\n  }.md\\:items-center{\r\n    align-items: center;\r\n  }.md\\:justify-end{\r\n    justify-content: flex-end;\r\n  }.md\\:justify-between{\r\n    justify-content: space-between;\r\n  }.md\\:gap-6{\r\n    gap: 1.5rem;\r\n  }.md\\:gap-8{\r\n    gap: 2rem;\r\n  }.md\\:gap-x-5{\r\n    -moz-column-gap: 1.25rem;\r\n         column-gap: 1.25rem;\r\n  }.md\\:self-center{\r\n    align-self: center;\r\n  }.md\\:border-b-0{\r\n    border-bottom-width: 0px;\r\n  }.md\\:border-b-2{\r\n    border-bottom-width: 2px;\r\n  }.md\\:border-r-2{\r\n    border-right-width: 2px;\r\n  }.md\\:bg-grey{\r\n    --tw-bg-opacity: 1;\r\n    background-color: rgba(118, 118, 118, 1);\r\n  }\n\n@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.md\\:bg-grey{\r\n      background-color: rgb(118 118 118 / var(--tw-bg-opacity));\r\n    }\n}.md\\:\\!py-2{\r\n    padding-top: 0.5rem !important;\r\n    padding-bottom: 0.5rem !important;\r\n  }.md\\:px-0{\r\n    padding-left: 0px;\r\n    padding-right: 0px;\r\n  }.md\\:px-10{\r\n    padding-left: 2.5rem;\r\n    padding-right: 2.5rem;\r\n  }.md\\:px-11{\r\n    padding-left: 2.75rem;\r\n    padding-right: 2.75rem;\r\n  }.md\\:px-16{\r\n    padding-left: 4rem;\r\n    padding-right: 4rem;\r\n  }.md\\:px-4{\r\n    padding-left: 1rem;\r\n    padding-right: 1rem;\r\n  }.md\\:py-20{\r\n    padding-top: 5rem;\r\n    padding-bottom: 5rem;\r\n  }.md\\:py-5{\r\n    padding-top: 1.25rem;\r\n    padding-bottom: 1.25rem;\r\n  }.md\\:py-8{\r\n    padding-top: 2rem;\r\n    padding-bottom: 2rem;\r\n  }.md\\:pb-0{\r\n    padding-bottom: 0px;\r\n  }.md\\:pb-16{\r\n    padding-bottom: 4rem;\r\n  }.md\\:pb-3{\r\n    padding-bottom: 0.75rem;\r\n  }.md\\:pb-8{\r\n    padding-bottom: 2rem;\r\n  }.md\\:pl-0{\r\n    padding-left: 0px;\r\n  }.md\\:pl-10{\r\n    padding-left: 2.5rem;\r\n  }.md\\:pl-11{\r\n    padding-left: 2.75rem;\r\n  }.md\\:pr-0{\r\n    padding-right: 0px;\r\n  }.md\\:pt-0{\r\n    padding-top: 0px;\r\n  }.md\\:pt-2{\r\n    padding-top: 0.5rem;\r\n  }.md\\:pt-3{\r\n    padding-top: 0.75rem;\r\n  }.md\\:\\!text-base{\r\n    font-size: 1rem !important;\r\n  }.md\\:\\!text-lg{\r\n    font-size: 1.334rem !important;\r\n  }.md\\:\\!text-xxl{\r\n    font-size: 2.24rem !important;\r\n  }.md\\:text-2xxl{\r\n    font-size: 3rem;\r\n  }.md\\:text-base{\r\n    font-size: 1rem;\r\n  }.md\\:text-lg{\r\n    font-size: 1.334rem;\r\n  }.md\\:text-xxl{\r\n    font-size: 2.24rem;\r\n  }.md\\:\\!leading-normal{\r\n    line-height: 1.3 !important;\r\n  }.md\\:leading-loose{\r\n    line-height: 1.5;\r\n  }.md\\:leading-normal{\r\n    line-height: 1.3;\r\n  }.md\\:leading-relaxed{\r\n    line-height: 1.4;\r\n  }.md\\:opacity-40{\r\n    opacity: 0.4;\r\n  }\r\n}@media (min-width: 1025px){.lg\\:w-1\\/2{\r\n    width: 50%;\r\n  }.lg\\:w-2\\/3{\r\n    width: 66.666667%;\r\n  }.lg\\:gap-x-0{\r\n    -moz-column-gap: 0px;\r\n         column-gap: 0px;\r\n  }.lg\\:px-12{\r\n    padding-left: 3rem;\r\n    padding-right: 3rem;\r\n  }.lg\\:px-40{\r\n    padding-left: 10rem;\r\n    padding-right: 10rem;\r\n  }.lg\\:px-8{\r\n    padding-left: 2rem;\r\n    padding-right: 2rem;\r\n  }.lg\\:pl-32{\r\n    padding-left: 8rem;\r\n  }.lg\\:pt-12{\r\n    padding-top: 3rem;\r\n  }.lg\\:text-base{\r\n    font-size: 1rem;\r\n  }\r\n}@media (min-width: 1400px){.xl\\:px-24{\r\n    padding-left: 6rem;\r\n    padding-right: 6rem;\r\n  }.xl\\:px-56{\r\n    padding-left: 14rem;\r\n    padding-right: 14rem;\r\n  }\r\n}", "",{"version":3,"sources":["webpack://./styles/app.css"],"names":[],"mappings":"AAA6E,cAAc,CAAC,oBAAoB,CAAC,mBAAmB,CAAC,kBAAkB,CAAC,gBAAgB,CAAC;EACvK,aAAa;EACb,8BAA8B;AAChC,CAAC;EACC;IACE,SAAS;EACX;AACF,CAAC;EACC,eAAe;AACjB,CAAC;EACC,+BAA+B;EAC/B,kCAAkC;AACpC,CAAC;AACD;IACI,qDAAqD;EACvD;AACF,CAAC;EACC,6BAA6B;AAC/B,CAAC;EACC;IACE,0BAA0B;EAC5B;EACA;IACE,WAAW;EACb;AACF,CAAC;EACC,YAAY;AACd,CAAC;EACC,6BAA6B;AAC/B,CAAC;EACC,YAAY;AACd,CAAC;EACC;MACI,aAAa;EACjB;EACA;MACI,aAAa;EACjB;AACF,CAAC;EACC,gBAAgB;AAClB,CAAC,kBAAkB,CAAC;IAChB,kBAAkB;AACtB,CAAC,oBAAoB,CAAC;EACpB,4CAA4C;EAC5C,WAAW;AACb,CAAC;EACC,8CAA8C;EAC9C,WAAW;AACb,CAAC;IACG;MACE,sBAAsB;IACxB;AACJ,CAAC;EACC,gDAAgD;AAClD,CAAC;EACC,gDAAgD;AAClD,CAAC,kBAAkB,CAAC,oBAAoB,CAAC;IACrC,aAAa;IACb,8BAA8B;IAC9B,mBAAmB;IACnB,WAAW;IACX,kBAAkB;IAClB,eAAe;IACf,eAAe;AACnB,CAAC;IACG;IACA,mBAAmB;EACrB;AACF,CAAC;IACG,cAAc;IACd,oBAAoB;IACpB,6BAA6B;AACjC,CAAC;AACD;IACI,gDAAgD;AACpD;AACA,CAAC;IACG;QACI,kBAAkB;IACtB;AACJ,CAAC;IACG,6BAA6B;AACjC,CAAC;IACG,iBAAiB;AACrB,CAAC;IACG,gBAAgB;AACpB,CAAC;IACG,YAAY;IACZ,iBAAiB;IACjB,oBAAoB;IACpB,YAAY;IACZ,eAAe;IACf,kBAAkB;IAClB,oBAAoB;IACpB,2BAA2B;AAC/B,CAAC;AACD;IACI,8CAA8C;AAClD;AACA,CAAC;IACG,6BAA6B;AACjC,CAAC;IACG,YAAY;IACZ,iBAAiB;IACjB,YAAY;IACZ,sBAAsB;IACtB,eAAe;IACf,oBAAoB;IACpB,2BAA2B;AAC/B,CAAC;AACD;IACI,8CAA8C;AAClD;AACA,CAAC;IACG,WAAW;IACX,iBAAiB;AACrB,CAAC,cAAc,CAAC;IACZ,aAAa;IACb,sBAAsB;IACtB,YAAY;IACZ,iBAAiB;IACjB,YAAY;IACZ,kBAAkB;IAClB,oBAAoB;IACpB,2BAA2B;AAC/B,CAAC;AACD;IACI,8CAA8C;AAClD;AACA,CAAC;IACG;QACI,aAAa;QACb,mBAAmB;QACnB,WAAW;QACX,mBAAmB;IACvB;AACJ,CAAC;IACG,aAAa;IACb,qBAAqB;AACzB,CAAC,aAAa,CAAC;EACb,aAAa;AACf,CAAC;IACG,eAAe;AACnB,CAAC;IACG,kBAAkB;IAClB,OAAO;IACP,SAAS;IACT,uBAAuB;IACvB,aAAa;IACb,sBAAsB;IACtB,aAAa;IACb,WAAW;IACX,kBAAkB;IAClB,wCAAwC;AAC5C,CAAC;AACD;IACI,yDAAyD;AAC7D;AACA,CAAC;IACG,iBAAiB;AACrB,CAAC;IACG,gBAAgB;IAChB,kBAAkB;AACtB,CAAC;IACG,WAAW;IACX,kBAAkB;IAClB,OAAO;IACP,QAAQ;IACR,YAAY;IACZ,WAAW;IACX,wCAAwC;AAC5C,CAAC;IACG;QACI,iBAAiB;IACrB;AACJ,CAAC,UAAU,CAAC;IACR,2BAA2B;IAC3B,0BAA0B;AAC9B,CAAC;IACG,6BAA6B;AACjC,CAAC;IACG,wBAAwB;AAC5B,CAAC;IACG,YAAY;IACZ,iBAAiB;AACrB,CAAC;IACG,uBAAuB;IACvB,YAAY;IACZ,WAAW;IACX,mBAAmB;IACnB,kBAAkB;IAClB,eAAe;IACf,aAAa;IACb,8BAA8B;IAC9B,eAAe;AACnB,CAAC;IACG;QACI,gBAAgB;IACpB;AACJ,CAAC;IACG,oCAAoC;AACxC,CAAC;IACG,gBAAgB;AACpB,CAAC;IACG;QACI,oCAAoC;IACxC;IACA;QACI,gBAAgB;IACpB;AACJ,CAAC;EACC,kBAAkB;EAClB,wCAAwC;IACtC,uBAAuB;IACvB,sCAAsC;AAC1C,CAAC;AACD;IACI,yDAAyD;EAC3D;AACF,CAAC,YAAY,CAAC;IACV,mBAAmB;AACvB,CAAC;IACG,kBAAkB;IAClB,WAAW;IACX,2BAA2B;AAC/B,CAAC;;IAEG,aAAa;AACjB,CAAC;;IAEG;;QAEI,cAAc;IAClB;AACJ,CAAC,kIAAkI,CAAC;IAChI,aAAa;AACjB,CAAC;IACG,cAAc;AAClB,CAAC;IACG,sBAAsB;AAC1B,CAAC;;IAEG,kBAAkB;IAClB,cAAc;IACd,WAAW;IACX,YAAY;IACZ,mBAAmB;IACnB,eAAe;IACf,mBAAmB;IACnB,iBAAiB;IACjB,qBAAqB;IACrB,sBAAsB;IACtB,gBAAgB;IAChB,2BAA2B;IAC3B,mCAAmC;IACnC,8BAA8B;AAClC,CAAC;;IAEG,WAAW;IACX,kBAAkB;IAClB,QAAQ;IACR,SAAS;IACT,WAAW;IACX,YAAY;IACZ,yBAAyB;IACzB,mBAAmB;IACnB,gCAAgC;IAChC,iCAAiC;IACjC,mCAAmC;IACnC,8BAA8B;AAClC,CAAC;IACG,oBAAoB;IACpB,WAAW;IACX,YAAY;IACZ,mBAAmB;IACnB,qBAAqB;IACrB,iBAAiB;IACjB,sBAAsB;AAC1B,CAAC;IACG,oBAAoB;IACpB,WAAW;IACX,YAAY;IACZ,mBAAmB;AACvB,CAAC;IACG,kBAAkB;IAClB,aAAa;IACb,uBAAuB;IACvB,mBAAmB;IACnB,SAAS;IACT,uBAAuB;IACvB,mBAAmB;IACnB,2BAA2B;IAC3B,eAAe;IACf,yBAAyB;IACzB,sBAAsB;IACtB,gBAAgB;AACpB,CAAC;IACG,eAAe;IACf,WAAW;IACX,cAAc;AAClB,CAAC;;IAEG;QACI,yBAAyB;QACzB,2CAA2C;IAC/C;;IAEA;QACI,yBAAyB;QACzB,4CAA4C;IAChD;AACJ,CAAC;;IAEG;QACI,qBAAqB;IACzB;;IAEA;QACI,qBAAqB;IACzB;AACJ,CAAC;;IAEG,wBAAwB;AAC5B,CAAC;;IAEG,wBAAwB;AAC5B,CAAC;;IAEG,wBAAwB;AAC5B,CAAC;;IAEG,sBAAsB;AAC1B,CAAC;;IAEG,wBAAwB;AAC5B,CAAC;;IAEG,0BAA0B;AAC9B,CAAC;;IAEG,wBAAwB;AAC5B,CAAC;;IAEG,wBAAwB;AAC5B,CAAC;;IAEG,wBAAwB;AAC5B,CAAC;;IAEG,wBAAwB;AAC5B,CAAC;;IAEG,sBAAsB;AAC1B,CAAC;;IAEG,wBAAwB;AAC5B,CAAC;;IAEG,sBAAsB;AAC1B,CAAC;;IAEG,wBAAwB;AAC5B,CAAC;;IAEG,sBAAsB;AAC1B,CAAC;;IAEG,wBAAwB;AAC5B,CAAC;;IAEG,wBAAwB;AAC5B,CAAC;;IAEG,wBAAwB;AAC5B,CAAC;;IAEG,wBAAwB;AAC5B,CAAC;;IAEG,wBAAwB;AAC5B,CAAC;;IAEG,sBAAsB;AAC1B,CAAC,kBAAkB,CAAC;IAChB,yBAAyB;AAC7B,CAAC;IACG,aAAa;AACjB,CAAC;IACG,cAAc;AAClB,CAAC;IACG;QACI,cAAc;IAClB;;IAEA;QACI,aAAa;IACjB;AACJ,CAAC;IACG,YAAY;IACZ,iBAAiB;AACrB,CAAC;IACG,YAAY;AAChB,CAAC;IACG,YAAY;AAChB,CAAC;IACG,WAAW;IACX,YAAY;AAChB,CAAC;IACG,aAAa;IACb,uBAAuB;AAC3B,CAAC;IACG,uBAAuB;IACvB,wBAAwB;IACxB,2BAA2B;AAC/B,CAAC;IACG,oBAAoB;IACpB,yBAAyB;IACzB,kBAAkB;IAClB,aAAa;IACb,cAAc;IACd,mBAAmB;IACnB,uBAAuB;AAC3B,CAAC;IACG,WAAW;IACX,cAAc;AAClB,CAAC;IACG,gBAAgB;AACpB,CAAC;IACG,YAAY;AAChB,CAAC;IACG,YAAY;IACZ,qBAAqB;IACrB,qBAAqB;AACzB,CAAC;IACG,YAAY;AAChB,CAAC;IACG,cAAc;AAClB,CAAC,kCAAkC,CAAC;EAClC,6BAA6B;EAC7B,mDAAmD;IACjD,qBAAqB;IACrB,uBAAuB;IACvB,sBAAsB;AAC1B,CAAC;IACG,YAAY;AAChB,CAAC;AACD;IACI,oEAAoE;EACtE;AACF,CAAC;IACG,wCAAwC;AAC5C,CAAC;IACG,qBAAqB;IACrB,yBAAyB;IACzB,aAAa;IACb,kBAAkB;IAClB,QAAQ;AACZ,CAAC;IACG,cAAc;IACd,WAAW;IACX,kBAAkB;IAClB,wCAAwC;IACxC,UAAU;IACV,WAAW;IACX,kBAAkB;IAClB,kBAAkB;IAClB,QAAQ;IACR,SAAS;IACT,gCAAgC;AACpC,CAAC;AACD;IACI,yDAAyD;AAC7D;AACA,CAAC,kHAAkH,CAAC;IAChH,iBAAiB;AACrB,CAAC;IACG;QACI,eAAe;IACnB;AACJ,CAAC;IACG;QACI,gBAAgB;IACpB;AACJ,CAAC,6DAA6D,CAAC;;;;;;EAM7D,aAAa;AACf,CAAC,yEAAyE,CAAC;EACzE,aAAa;AACf,CAAC,gFAAgF,CAAC;;;;EAIhF,iBAAiB;AACnB,CAAC,uDAAuD,CAAC;EACvD,eAAe;AACjB,CAAC;EACC,eAAe;AACjB,CAAC,qDAAqD,CAAC;EACrD,4BAA4B;AAC9B,CAAC,uDAAuD,CAAC;EACvD,WAAW;EACX,sBAAsB;EACtB,eAAe;EACf,iBAAiB;AACnB,CAAC;EACC,WAAW;EACX,sBAAsB;EACtB,eAAe;EACf,iBAAiB;AACnB,CAAC;EACC,sBAAsB;EACtB,iCAAiC;EACjC,0BAA0B;EAC1B,4BAA4B;AAC9B,CAAC;EACC,iBAAiB;AACnB,CAAC,+BAA+B,CAAC;;;;EAI/B,cAAc;;EAEd,kCAAkC;;EAElC,0BAA0B;AAC5B,CAAC;;;EAGC,cAAc;EACd,6BAA6B;EAC7B,qBAAqB;AACvB,CAAC,iFAAiF,CAAC;EACjF,mCAAmC;AACrC,CAAC;EACC,kCAAkC;AACpC,CAAC;EACC,oCAAoC;AACtC,CAAC,2BAA2B,CAAC;;EAE3B,WAAW;AACb,CAAC,4BAA4B,CAAC;EAC5B,cAAc;AAChB,CAAC,8CAA8C,CAAC;EAC9C,YAAY;AACd,CAAC,6CAA6C,CAAC;EAC7C,wBAAwB;AAC1B,CAAC;EACC,wBAAwB;AAC1B,CAAC,iDAAiD,CAAC;EACjD,yBAAyB;AAC3B,CAAC;EACC,6BAA6B;EAC7B,qBAAqB;AACvB,CAAC,yBAAyB,CAAC;EACzB,iBAAiB;AACnB,CAAC,uCAAuC,CAAC;EACvC,iBAAiB;AACnB,CAAC,+CAA+C,CAAC;EAC/C,mBAAmB;AACrB,CAAC,+DAA+D,CAAC;EAC/D,4BAA4B;AAC9B,CAAC,2CAA2C,CAAC;EAC3C,yBAAyB;AAC3B,CAAC;EACC,yBAAyB;AAC3B,CAAC,oCAAoC,CAAC;EACpC,iBAAiB;AACnB,CAAC,0CAA0C,CAAC;;;EAG1C,oCAAoC;EACpC,6BAA6B;EAC7B,iCAAiC;EACjC,6BAA6B;AAC/B,CAAC;;;EAGC,6CAA6C;EAC7C,qCAAqC;AACvC,CAAC;;;;;EAKC,8BAA8B;AAChC,CAAC,0CAA0C,CAAC;EAC1C,8BAA8B;AAChC,CAAC;;;;;;;EAOC,uBAAuB;AACzB,CAAC;;;;;EAKC,8BAA8B;AAChC,CAAC,qDAAqD,CAAC;EACrD,mBAAmB;AACrB,CAAC;EACC,kBAAkB;AACpB,CAAC,sCAAsC,CAAC;EACtC,iBAAiB;AACnB,CAAC;EACC,uBAAuB;AACzB,CAAC;EACC,YAAY;AACd,CAAC,iCAAiC,CAAC;EACjC;;;IAGE,cAAc;EAChB;;EAEA;IACE,6BAA6B;EAC/B;EACA;IACE,gCAAgC;IAChC,8BAA8B;EAChC;;EAEA;;;;;;;;IAQE,8BAA8B;EAChC;;EAEA;IACE,0BAA0B;EAC5B;AACF,CAAC,iEAAiE,CAAC;;;CAGlE,CAAC;;;EAGA,sBAAsB,EAAE,MAAM;EAC9B,eAAe,EAAE,MAAM;EACvB,mBAAmB,EAAE,MAAM;EAC3B,qBAAqB,EAAE,MAAM;AAC/B,CAAC;;EAEC,gBAAgB;AAClB,CAAC;;;;;;;CAOA,CAAC;EACA,gBAAgB,EAAE,MAAM;EACxB,8BAA8B,EAAE,MAAM;EACtC,gBAAgB,EAAE,MAAM;EACxB,WAAW,EAAE,MAAM;EACnB,wRAAwR,EAAE,MAAM;EAChS,6BAA6B,EAAE,MAAM;EACrC,+BAA+B,EAAE,MAAM;AACzC,CAAC;;;CAGA,CAAC;EACA,SAAS,EAAE,MAAM;EACjB,oBAAoB,EAAE,MAAM;AAC9B,CAAC;;;;CAIA,CAAC;EACA,SAAS,EAAE,MAAM;EACjB,cAAc,EAAE,MAAM;EACtB,qBAAqB,EAAE,MAAM;AAC/B,CAAC;;CAEA,CAAC;EACA,0BAA0B;EAC1B,yCAAyC;UACjC,iCAAiC;AAC3C,CAAC;;CAEA,CAAC;;;;;;EAMA,kBAAkB;EAClB,oBAAoB;AACtB,CAAC;;CAEA,CAAC;EACA,cAAc;EACd,wBAAwB;AAC1B,CAAC;;CAEA,CAAC;;EAEA,mBAAmB;AACrB,CAAC;;;CAGA,CAAC;;;;EAIA,+GAA+G,EAAE,MAAM;EACvH,cAAc,EAAE,MAAM;AACxB,CAAC;;CAEA,CAAC;EACA,cAAc;AAChB,CAAC;;CAEA,CAAC;;EAEA,cAAc;EACd,cAAc;EACd,kBAAkB;EAClB,wBAAwB;AAC1B,CAAC;EACC,eAAe;AACjB,CAAC;EACC,WAAW;AACb,CAAC;;;;CAIA,CAAC;EACA,cAAc,EAAE,MAAM;EACtB,qBAAqB,EAAE,MAAM;EAC7B,yBAAyB,EAAE,MAAM;AACnC,CAAC;;;;CAIA,CAAC;;;;;EAKA,oBAAoB,EAAE,MAAM;EAC5B,eAAe,EAAE,MAAM;EACvB,oBAAoB,EAAE,MAAM;EAC5B,oBAAoB,EAAE,MAAM;EAC5B,cAAc,EAAE,MAAM;EACtB,SAAS,EAAE,MAAM;EACjB,UAAU,EAAE,MAAM;AACpB,CAAC;;CAEA,CAAC;;EAEA,oBAAoB;AACtB,CAAC;;;CAGA,CAAC;;;;EAIA,0BAA0B,EAAE,MAAM;EAClC,6BAA6B,EAAE,MAAM;EACrC,sBAAsB,EAAE,MAAM;AAChC,CAAC;;CAEA,CAAC;EACA,aAAa;AACf,CAAC;;CAEA,CAAC;EACA,gBAAgB;AAClB,CAAC;;CAEA,CAAC;EACA,wBAAwB;AAC1B,CAAC;;CAEA,CAAC;;EAEA,YAAY;AACd,CAAC;;;CAGA,CAAC;EACA,6BAA6B,EAAE,MAAM;EACrC,oBAAoB,EAAE,MAAM;AAC9B,CAAC;;CAEA,CAAC;EACA,wBAAwB;AAC1B,CAAC;;;CAGA,CAAC;EACA,0BAA0B,EAAE,MAAM;EAClC,aAAa,EAAE,MAAM;AACvB,CAAC;;CAEA,CAAC;EACA,kBAAkB;AACpB,CAAC;;CAEA,CAAC;;;;;;;;;;;;;EAaA,SAAS;AACX,CAAC;EACC,SAAS;EACT,UAAU;AACZ,CAAC;EACC,UAAU;AACZ,CAAC;;;EAGC,gBAAgB;EAChB,SAAS;EACT,UAAU;AACZ,CAAC;;CAEA,CAAC;EACA,gBAAgB;AAClB,CAAC;;;CAGA,CAAC;;EAEA,UAAU,EAAE,MAAM;EAClB,cAAc,EAAE,MAAM;AACxB,CAAC;;CAEA,CAAC;;EAEA,eAAe;AACjB,CAAC;;CAEA,CAAC;EACA,eAAe;AACjB,CAAC;;;;CAIA,CAAC;;;;;;;;EAQA,cAAc,EAAE,MAAM;EACtB,sBAAsB,EAAE,MAAM;AAChC,CAAC;;CAEA,CAAC;;EAEA,eAAe;EACf,YAAY;AACd,CAAC,wEAAwE,CAAC;EACxE,aAAa;AACf,CAAC;EACC,wBAAwB;EACxB,wBAAwB;EACxB,mBAAmB;EACnB,mBAAmB;EACnB,cAAc;EACd,cAAc;EACd,cAAc;EACd,eAAe;EACf,eAAe;EACf,aAAa;EACb,aAAa;EACb,kBAAkB;EAClB,sCAAsC;EACtC,8BAA8B;EAC9B,6BAA6B;EAC7B,4BAA4B;EAC5B,eAAe;EACf,oBAAoB;EACpB,sBAAsB;EACtB,uBAAuB;EACvB,wBAAwB;EACxB,kBAAkB;EAClB,2BAA2B;EAC3B,4BAA4B;EAC5B,wCAAwC;EACxC,0CAA0C;EAC1C,mCAAmC;EACnC,8BAA8B;EAC9B,sCAAsC;EACtC,YAAY;EACZ,kBAAkB;EAClB,gBAAgB;EAChB,iBAAiB;EACjB,kBAAkB;EAClB,cAAc;EACd,gBAAgB;EAChB,aAAa;EACb,mBAAmB;EACnB,qBAAqB;EACrB,2BAA2B;EAC3B,yBAAyB;EACzB,0BAA0B;EAC1B,2BAA2B;EAC3B,uBAAuB;EACvB,wBAAwB;EACxB,yBAAyB;EACzB,sBAAsB;AACxB,CAAC;EACC,wBAAwB;EACxB,wBAAwB;EACxB,mBAAmB;EACnB,mBAAmB;EACnB,cAAc;EACd,cAAc;EACd,cAAc;EACd,eAAe;EACf,eAAe;EACf,aAAa;EACb,aAAa;EACb,kBAAkB;EAClB,sCAAsC;EACtC,8BAA8B;EAC9B,6BAA6B;EAC7B,4BAA4B;EAC5B,eAAe;EACf,oBAAoB;EACpB,sBAAsB;EACtB,uBAAuB;EACvB,wBAAwB;EACxB,kBAAkB;EAClB,2BAA2B;EAC3B,4BAA4B;EAC5B,wCAAwC;EACxC,0CAA0C;EAC1C,mCAAmC;EACnC,8BAA8B;EAC9B,sCAAsC;EACtC,YAAY;EACZ,kBAAkB;EAClB,gBAAgB;EAChB,iBAAiB;EACjB,kBAAkB;EAClB,cAAc;EACd,gBAAgB;EAChB,aAAa;EACb,mBAAmB;EACnB,qBAAqB;EACrB,2BAA2B;EAC3B,yBAAyB;EACzB,0BAA0B;EAC1B,2BAA2B;EAC3B,uBAAuB;EACvB,wBAAwB;EACxB,yBAAyB;EACzB,sBAAsB;AACxB,CAAC;EACC,WAAW;AACb,CAAC,0BAA0B;IACvB,gBAAgB;EAClB;AACF,CAAC,0BAA0B;IACvB,gBAAgB;EAClB;AACF,CAAC,2BAA2B;IACxB,iBAAiB;EACnB;AACF,CAAC,2BAA2B;IACxB,iBAAiB;EACnB;AACF,CAAC;EACC,kBAAkB;EAClB,UAAU;EACV,WAAW;EACX,UAAU;EACV,YAAY;EACZ,gBAAgB;EAChB,sBAAsB;EACtB,mBAAmB;EACnB,eAAe;AACjB,CAAC;EACC,2BAA2B;AAC7B,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,kBAAkB;AACpB,CAAC;EACC,kBAAkB;AACpB,CAAC;EACC,QAAQ;EACR,UAAU;EACV,WAAW;EACX,SAAS;AACX,CAAC;EACC,WAAW;AACb,CAAC;EACC,SAAS;AACX,CAAC;EACC,YAAY;AACd,CAAC;EACC,UAAU;AACZ,CAAC;EACC,UAAU;AACZ,CAAC;EACC,WAAW;AACb,CAAC;EACC,4BAA4B;AAC9B,CAAC;EACC,4BAA4B;AAC9B,CAAC;EACC,4BAA4B;AAC9B,CAAC;EACC,gBAAgB;EAChB,mBAAmB;AACrB,CAAC;EACC,kBAAkB;EAClB,qBAAqB;AACvB,CAAC;EACC,8BAA8B;AAChC,CAAC;EACC,+BAA+B;AACjC,CAAC;EACC,0BAA0B;AAC5B,CAAC;EACC,kBAAkB;AACpB,CAAC;EACC,uBAAuB;AACzB,CAAC;EACC,mBAAmB;AACrB,CAAC;EACC,qBAAqB;AACvB,CAAC;EACC,mBAAmB;AACrB,CAAC;EACC,oBAAoB;AACtB,CAAC;EACC,iBAAiB;AACnB,CAAC;EACC,iBAAiB;AACnB,CAAC;EACC,eAAe;AACjB,CAAC;EACC,oBAAoB;AACtB,CAAC;EACC,mBAAmB;AACrB,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,kBAAkB;AACpB,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,cAAc;AAChB,CAAC;EACC,qBAAqB;AACvB,CAAC;EACC,eAAe;AACjB,CAAC;EACC,aAAa;AACf,CAAC;EACC,aAAa;AACf,CAAC;EACC,aAAa;AACf,CAAC;EACC,WAAW;AACb,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,cAAc;AAChB,CAAC;EACC,YAAY;AACd,CAAC;EACC,cAAc;AAChB,CAAC;EACC,YAAY;AACd,CAAC;EACC,WAAW;AACb,CAAC;EACC,aAAa;AACf,CAAC;EACC,aAAa;AACf,CAAC;EACC,aAAa;AACf,CAAC;EACC,aAAa;AACf,CAAC;EACC,YAAY;AACd,CAAC;EACC,YAAY;AACd,CAAC;EACC,YAAY;AACd,CAAC;EACC,WAAW;AACb,CAAC;EACC,kBAAkB;AACpB,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,kBAAkB;AACpB,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,WAAW;AACb,CAAC;EACC,cAAc;AAChB,CAAC;EACC,eAAe;AACjB,CAAC;EACC,UAAU;AACZ,CAAC;EACC,WAAW;AACb,CAAC;EACC,UAAU;AACZ,CAAC;EACC,aAAa;AACf,CAAC;EACC,WAAW;AACb,CAAC;EACC,iBAAiB;AACnB,CAAC;EACC,YAAY;AACd,CAAC;EACC,WAAW;AACb,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,YAAY;AACd,CAAC;EACC,8BAA8B;EAC9B,gMAAgM;EAChM,0MAA0M;AAC5M,CAAC;EACC,+LAA+L;AACjM,CAAC;EACC,YAAY;AACd,CAAC;EACC,eAAe;AACjB,CAAC;EACC,YAAY;AACd,CAAC;EACC,gDAAgD;AAClD,CAAC;EACC,6CAA6C;AAC/C,CAAC;EACC,sBAAsB;AACxB,CAAC;EACC,8BAA8B;AAChC,CAAC;EACC,eAAe;AACjB,CAAC;EACC,uBAAuB;AACzB,CAAC;EACC,mBAAmB;AACrB,CAAC;EACC,yBAAyB;AAC3B,CAAC;EACC,uBAAuB;AACzB,CAAC;EACC,8BAA8B;AAChC,CAAC;EACC,6BAA6B;AAC/B,CAAC;EACC,WAAW;AACb,CAAC;EACC,WAAW;AACb,CAAC;EACC,SAAS;AACX,CAAC;EACC,YAAY;AACd,CAAC;EACC,SAAS;AACX,CAAC;EACC,SAAS;AACX,CAAC;EACC,SAAS;AACX,CAAC;EACC,eAAe;AACjB,CAAC;EACC,uBAAuB;EACvB,mCAAmC;EACnC,2DAA2D;EAC3D,uCAAuC;EACvC,+DAA+D;EAC/D,gCAAgC;EAChC,wDAAwD;AAC1D,CAAC;EACC,kBAAkB;AACpB,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,qBAAqB;AACvB,CAAC;EACC,qBAAqB;AACvB,CAAC;EACC,8BAA8B;EAC9B,iCAAiC;AACnC,CAAC;EACC,+BAA+B;EAC/B,kCAAkC;AACpC,CAAC;EACC,iBAAiB;AACnB,CAAC;EACC,wBAAwB;AAC1B,CAAC;EACC,qBAAqB;AACvB,CAAC;EACC,qBAAqB;AACvB,CAAC;EACC,sBAAsB;EACtB,8BAA8B;AAChC,CAAC;AACD;IACI,mDAAmD;EACrD;AACF,CAAC;EACC,sBAAsB;EACtB,oCAAoC;AACtC,CAAC;AACD;IACI,yDAAyD;EAC3D;AACF,CAAC;EACC,sBAAsB;EACtB,wCAAwC;AAC1C,CAAC;AACD;IACI,6DAA6D;EAC/D;AACF,CAAC;EACC,wBAAwB;AAC1B,CAAC;EACC,kBAAkB;EAClB,kCAAkC;AACpC,CAAC;AACD;IACI,mDAAmD;EACrD;AACF,CAAC;EACC,kBAAkB;EAClB,sCAAsC;AACxC,CAAC;AACD;IACI,uDAAuD;EACzD;AACF,CAAC;EACC,kBAAkB;EAClB,uCAAuC;AACzC,CAAC;AACD;IACI,wDAAwD;EAC1D;AACF,CAAC;EACC,kBAAkB;EAClB,wCAAwC;AAC1C,CAAC;AACD;IACI,yDAAyD;EAC3D;AACF,CAAC;EACC,kBAAkB;EAClB,wCAAwC;AAC1C,CAAC;AACD;IACI,yDAAyD;EAC3D;AACF,CAAC;EACC,kBAAkB;EAClB,wCAAwC;AAC1C,CAAC;AACD;IACI,yDAAyD;EAC3D;AACF,CAAC;EACC,kBAAkB;EAClB,wCAAwC;AAC1C,CAAC;AACD;IACI,yDAAyD;EAC3D;AACF,CAAC;EACC,kBAAkB;EAClB,uCAAuC;AACzC,CAAC;AACD;IACI,wDAAwD;EAC1D;AACF,CAAC;EACC,mEAAmE;AACrE,CAAC;EACC,oEAAoE;EACpE,iEAAiE;EACjE,mEAAmE;AACrE,CAAC;EACC,4DAA4D;AAC9D,CAAC;EACC,sBAAsB;AACxB,CAAC;EACC,2BAA2B;AAC7B,CAAC;EACC,mBAAmB;AACrB,CAAC;EACC,iBAAiB;AACnB,CAAC;EACC,YAAY;AACd,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,oBAAoB;EACpB,qBAAqB;AACvB,CAAC;EACC,kBAAkB;EAClB,mBAAmB;AACrB,CAAC;EACC,qBAAqB;EACrB,sBAAsB;AACxB,CAAC;EACC,oBAAoB;EACpB,qBAAqB;AACvB,CAAC;EACC,kBAAkB;EAClB,mBAAmB;AACrB,CAAC;EACC,oBAAoB;EACpB,uBAAuB;AACzB,CAAC;EACC,mBAAmB;EACnB,sBAAsB;AACxB,CAAC;EACC,oBAAoB;EACpB,uBAAuB;AACzB,CAAC;EACC,iBAAiB;EACjB,oBAAoB;AACtB,CAAC;EACC,oBAAoB;EACpB,uBAAuB;AACzB,CAAC;EACC,mBAAmB;EACnB,sBAAsB;AACxB,CAAC;EACC,iBAAiB;EACjB,oBAAoB;AACtB,CAAC;EACC,uBAAuB;AACzB,CAAC;EACC,sBAAsB;AACxB,CAAC;EACC,sBAAsB;AACxB,CAAC;EACC,sBAAsB;AACxB,CAAC;EACC,oBAAoB;AACtB,CAAC;EACC,uBAAuB;AACzB,CAAC;EACC,oBAAoB;AACtB,CAAC;EACC,sBAAsB;AACxB,CAAC;EACC,uBAAuB;AACzB,CAAC;EACC,oBAAoB;AACtB,CAAC;EACC,kBAAkB;AACpB,CAAC;EACC,qBAAqB;AACvB,CAAC;EACC,qBAAqB;AACvB,CAAC;EACC,qBAAqB;AACvB,CAAC;EACC,qBAAqB;AACvB,CAAC;EACC,oBAAoB;AACtB,CAAC;EACC,mBAAmB;AACrB,CAAC;EACC,oBAAoB;AACtB,CAAC;EACC,iBAAiB;AACnB,CAAC;EACC,oBAAoB;AACtB,CAAC;EACC,oBAAoB;AACtB,CAAC;EACC,iBAAiB;AACnB,CAAC;EACC,4BAA4B;AAC9B,CAAC;EACC,0BAA0B;AAC5B,CAAC;EACC,8BAA8B;AAChC,CAAC;EACC,6BAA6B;AAC/B,CAAC;EACC,4BAA4B;AAC9B,CAAC;EACC,kBAAkB;AACpB,CAAC;EACC,eAAe;AACjB,CAAC;EACC,kBAAkB;AACpB,CAAC;EACC,iBAAiB;AACnB,CAAC;EACC,kBAAkB;AACpB,CAAC;EACC,2BAA2B;AAC7B,CAAC;EACC,2BAA2B;AAC7B,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,yBAAyB;AAC3B,CAAC;EACC,iBAAiB;AACnB,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,+BAA+B;EAC/B,kCAAkC;AACpC,CAAC;AACD;IACI,qDAAqD;EACvD;AACF,CAAC;EACC,oCAAoC;AACtC,CAAC;EACC,oBAAoB;EACpB,uBAAuB;AACzB,CAAC;AACD;IACI,0CAA0C;EAC5C;AACF,CAAC;EACC,oBAAoB;EACpB,2BAA2B;AAC7B,CAAC;AACD;IACI,8CAA8C;EAChD;AACF,CAAC;EACC,oBAAoB;EACpB,6BAA6B;AAC/B,CAAC;AACD;IACI,gDAAgD;EAClD;AACF,CAAC;EACC,oBAAoB;EACpB,6BAA6B;AAC/B,CAAC;AACD;IACI,gDAAgD;EAClD;AACF,CAAC;EACC,oBAAoB;EACpB,6BAA6B;AAC/B,CAAC;AACD;IACI,gDAAgD;EAClD;AACF,CAAC;EACC,oBAAoB;EACpB,6BAA6B;AAC/B,CAAC;AACD;IACI,gDAAgD;EAClD;AACF,CAAC;EACC,oBAAoB;EACpB,6BAA6B;AAC/B,CAAC;AACD;IACI,gDAAgD;EAClD;AACF,CAAC;EACC,oBAAoB;EACpB,6BAA6B;AAC/B,CAAC;AACD;IACI,gDAAgD;EAClD;AACF,CAAC;EACC,+BAA+B;AACjC,CAAC;EACC,YAAY;AACd,CAAC;EACC,YAAY;AACd,CAAC;EACC,mFAAmF;EACnF,mGAAmG;EACnG,wHAAwH;EACxH,uGAAuG;AACzG,CAAC;EACC,oBAAoB;AACtB,CAAC;EACC,kBAAkB;AACpB,CAAC;EACC,wBAAwB;EACxB,wDAAwD;EACxD,0BAA0B;AAC5B,CAAC;EACC,8BAA8B;EAC9B,wDAAwD;EACxD,0BAA0B;AAC5B,CAAC;EACC,0BAA0B;AAC5B,CAAC,kBAAkB,CAAC;IAChB,eAAe;AACnB,CAAC,UAAU,CAAC;IACR,oHAAmL;IACnL,kCAAkC;IAClC,gBAAgB;AACpB,CAAC;IACG,oHAAmL;IACnL,kCAAkC;IAClC,gBAAgB;AACpB,CAAC;IACG,oHAAmL;IACnL,kCAAkC;IAClC,gBAAgB;AACpB,CAAC,yBAAyB,CAAC;EACzB,8CAA8C;AAChD,CAAC;IACG,wBAAwB;AAC5B,CAAC;EACC,6BAA6B;AAC/B,CAAC;EACC,0BAA0B;AAC5B,CAAC;EACC,2BAA2B;EAC3B,sBAAsB;EACtB,qCAAqC;AACvC,CAAC;EACC,yBAAyB;EACzB,iLAAiL;EACjL,+LAA+L;AACjM,CAAC;EACC,iBAAiB;AACnB,CAAC;EACC,sBAAsB;EACtB,8BAA8B;AAChC,CAAC;AACD;IACI,mDAAmD;EACrD;AACF,CAAC;EACC,kBAAkB;EAClB,wCAAwC;AAC1C,CAAC;AACD;IACI,yDAAyD;EAC3D;AACF,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,kBAAkB;AACpB,CAAC;EACC,gBAAgB;EAChB,WAAW;EACX,YAAY;EACZ,UAAU;EACV,SAAS;EACT,iBAAiB;EACjB,UAAU;EACV,mBAAmB;AACrB,CAAC;EACC,yBAAyB;EACzB,iLAAiL;EACjL,+LAA+L;AACjM,CAAC;EACC,gBAAgB;AAClB,CAAC;EACC,kBAAkB;AACpB,CAAC,0BAA0B;IACvB,kBAAkB;EACpB,CAAC;IACC,YAAY;EACd,CAAC;IACC,UAAU;EACZ,CAAC;IACC,YAAY;EACd,CAAC;IACC,WAAW;EACb,CAAC;IACC,SAAS;EACX,CAAC;IACC,UAAU;EACZ,CAAC;IACC,UAAU;EACZ,CAAC;IACC,gBAAgB;IAChB,mBAAmB;EACrB,CAAC;IACC,yBAAyB;EAC3B,CAAC;IACC,aAAa;EACf,CAAC;IACC,aAAa;EACf,CAAC;IACC,kBAAkB;EACpB,CAAC;IACC,gBAAgB;EAClB,CAAC;IACC,UAAU;EACZ,CAAC;IACC,iBAAiB;EACnB,CAAC;IACC,iBAAiB;EACnB,CAAC;IACC,WAAW;EACb,CAAC;IACC,UAAU;EACZ,CAAC;IACC,YAAY;EACd,CAAC;IACC,WAAW;EACb,CAAC;IACC,UAAU;EACZ,CAAC;IACC,gBAAgB;EAClB,CAAC;IACC,eAAe;EACjB,CAAC;IACC,gDAAgD;EAClD,CAAC;IACC,gDAAgD;EAClD,CAAC;IACC,gDAAgD;EAClD,CAAC;IACC,kCAAkC;EACpC,CAAC;IACC,mBAAmB;EACrB,CAAC;IACC,2BAA2B;EAC7B,CAAC;IACC,iBAAiB;EACnB,CAAC;IACC,mBAAmB;EACrB,CAAC;IACC,yBAAyB;EAC3B,CAAC;IACC,8BAA8B;EAChC,CAAC;IACC,WAAW;EACb,CAAC;IACC,SAAS;EACX,CAAC;IACC,wBAAwB;SACnB,mBAAmB;EAC1B,CAAC;IACC,kBAAkB;EACpB,CAAC;IACC,wBAAwB;EAC1B,CAAC;IACC,wBAAwB;EAC1B,CAAC;IACC,uBAAuB;EACzB,CAAC;IACC,kBAAkB;IAClB,wCAAwC;EAC1C;;AAEF;AACA;MACM,yDAAyD;IAC3D;AACJ,CAAC;IACG,8BAA8B;IAC9B,iCAAiC;EACnC,CAAC;IACC,iBAAiB;IACjB,kBAAkB;EACpB,CAAC;IACC,oBAAoB;IACpB,qBAAqB;EACvB,CAAC;IACC,qBAAqB;IACrB,sBAAsB;EACxB,CAAC;IACC,kBAAkB;IAClB,mBAAmB;EACrB,CAAC;IACC,kBAAkB;IAClB,mBAAmB;EACrB,CAAC;IACC,iBAAiB;IACjB,oBAAoB;EACtB,CAAC;IACC,oBAAoB;IACpB,uBAAuB;EACzB,CAAC;IACC,iBAAiB;IACjB,oBAAoB;EACtB,CAAC;IACC,mBAAmB;EACrB,CAAC;IACC,oBAAoB;EACtB,CAAC;IACC,uBAAuB;EACzB,CAAC;IACC,oBAAoB;EACtB,CAAC;IACC,iBAAiB;EACnB,CAAC;IACC,oBAAoB;EACtB,CAAC;IACC,qBAAqB;EACvB,CAAC;IACC,kBAAkB;EACpB,CAAC;IACC,gBAAgB;EAClB,CAAC;IACC,mBAAmB;EACrB,CAAC;IACC,oBAAoB;EACtB,CAAC;IACC,0BAA0B;EAC5B,CAAC;IACC,8BAA8B;EAChC,CAAC;IACC,6BAA6B;EAC/B,CAAC;IACC,eAAe;EACjB,CAAC;IACC,eAAe;EACjB,CAAC;IACC,mBAAmB;EACrB,CAAC;IACC,kBAAkB;EACpB,CAAC;IACC,2BAA2B;EAC7B,CAAC;IACC,gBAAgB;EAClB,CAAC;IACC,gBAAgB;EAClB,CAAC;IACC,gBAAgB;EAClB,CAAC;IACC,YAAY;EACd;AACF,CAAC,2BAA2B;IACxB,UAAU;EACZ,CAAC;IACC,iBAAiB;EACnB,CAAC;IACC,oBAAoB;SACf,eAAe;EACtB,CAAC;IACC,kBAAkB;IAClB,mBAAmB;EACrB,CAAC;IACC,mBAAmB;IACnB,oBAAoB;EACtB,CAAC;IACC,kBAAkB;IAClB,mBAAmB;EACrB,CAAC;IACC,kBAAkB;EACpB,CAAC;IACC,iBAAiB;EACnB,CAAC;IACC,eAAe;EACjB;AACF,CAAC,2BAA2B;IACxB,kBAAkB;IAClB,mBAAmB;EACrB,CAAC;IACC,mBAAmB;IACnB,oBAAoB;EACtB;AACF","sourcesContent":["@import url('https://fonts.googleapis.com/css2?family=Signika&display=swap');@tailwind base;@tailwind components;@tailwind utilities;/* ACF OVERRIDES *//* Footer Menu */#menu-footer-menu {\r\n  display: flex;\r\n  justify-content: space-between;\r\n}@media (min-width: 768px) {\r\n  #menu-footer-menu {\r\n    gap: 3rem;\r\n  }\r\n}#menu-footer-menu li a {\r\n  font-size: 1rem;\r\n}.menu-footer-menu-container #menu-footer-menu .menu-item a{\r\n  --tw-text-opacity: 1 !important;\r\n  color: rgba(0, 0, 0, 1) !important;\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.menu-footer-menu-container #menu-footer-menu .menu-item a{\r\n    color: rgb(0 0 0 / var(--tw-text-opacity)) !important;\r\n  }\n}.footer-nested-item div ul li a {\r\n  font-size: 0.89rem !important;\r\n}@media (min-width: 768px) {\r\n  .footer-nested-item div ul li a {\r\n    font-size: 1rem !important;\r\n  }\r\n  #menu-footer-menu {\r\n    gap: 2.5rem;\r\n  }\r\n}.expand-icon-footer::before {\r\n  content: '+'; \r\n}.retract-icon-footer::before {\r\n  font-size: 2.25rem !important;\r\n}.retract-icon-footer::before {\r\n  content: '-';\r\n}@media (min-width: 768px){\r\n  .expand-icon-footer::before {\r\n      display: none; \r\n  }\r\n  .retract-icon-footer::before {\r\n      display: none; \r\n  }\r\n}.footer-nested-item .acf-nav-menu ul li:hover {\r\n  font-weight: 600;\r\n}/* HEADER STYLES */header {\r\n    position: relative;\r\n}/* Hamburger Button*/#hamburger-button.active .topline { \r\n  transform: rotate(45deg) translate(0px, 5px); \r\n  width: 18px;\r\n}#hamburger-button.active .bottomline { \r\n  transform: rotate(-45deg) translate(0px, -5px);\r\n  width: 18px;\r\n}@media (min-width: 768px) {\r\n    #hamburger-button.active .topline , #hamburger-button.active .bottomline{\r\n      width: 24px !important;\r\n    }\r\n}#hamburger-button.active {\r\n  transition: transform 0.4s ease, width 0.4s ease; \r\n}#hamburger-button .topline, #hamburger-button .bottomline { \r\n  transition: transform 0.4s ease, width 0.4s ease; \r\n}/* Hamburger Menu*//* right side menu */#hamburger-dropdown-menu .sub_menu.right .menu .acf-nav-menu ul li a {\r\n    display: flex;\r\n    justify-content: space-between;\r\n    align-items: center;\r\n    width: 100%;\r\n    padding: 0.25rem 0;\r\n    cursor: pointer;\r\n    font-size: 1rem;\r\n}@media (min-width: 768px) {\r\n    #hamburger-dropdown-menu .sub_menu.right .menu .acf-nav-menu ul li a{\r\n    font-size: 1.334rem;\r\n  }\r\n}#hamburger-dropdown-menu .sub_menu.right .menu .acf-nav-menu ul li ul {\r\n    padding-top: 0;\r\n    --tw-text-opacity: 1;\r\n    color: rgba(118, 118, 118, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n#hamburger-dropdown-menu .sub_menu.right .menu .acf-nav-menu ul li ul {\r\n    color: rgb(118 118 118 / var(--tw-text-opacity));\r\n}\n}@media (min-width: 768px) {\r\n    #hamburger-dropdown-menu .sub_menu.right .menu .acf-nav-menu ul li ul {\r\n        padding: 0.25rem 0;\r\n    }\r\n}#hamburger-dropdown-menu .sub_menu.right .menu .acf-nav-menu ul li ul li a {\r\n    font-size: 0.89rem !important;\r\n}#hamburger-dropdown-menu .sub_menu.right .menu .acf-nav-menu ul li ul li a {\r\n    padding: 0.4rem 0;\r\n}#hamburger-dropdown-menu .sub_menu.right .menu .acf-nav-menu ul li ul li:hover {\r\n    font-weight: 600;\r\n}.expand-icon-header::before {\r\n    content: '+'; \r\n    font-size: 1.5rem;\r\n    padding-bottom: 10px;\r\n    opacity: 0.6; \r\n    cursor: pointer;\r\n    padding-right: 2px;\r\n    --tw-text-opacity: 1;\r\n    color: rgba(0, 114, 188, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.expand-icon-header::before {\r\n    color: rgb(0 114 188 / var(--tw-text-opacity));\r\n}\n}.retract-icon-header::before {\r\n    font-size: 2.25rem !important; \r\n}.retract-icon-header::before {\r\n    content: '-';\r\n    line-height: 0.75;\r\n    opacity: 0.6;\r\n    padding-right: 0.15rem;\r\n    cursor: pointer;\r\n    --tw-text-opacity: 1;\r\n    color: rgba(0, 114, 188, 1); \r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.retract-icon-header::before {\r\n    color: rgb(0 114 188 / var(--tw-text-opacity)); \r\n}\n}.arrow-svg {\r\n    width: 1rem;\r\n    margin-right: 3px;\r\n}/* left side */.left-menu-container .acf-nav-menu ul {\r\n    display: flex;\r\n    flex-direction: column;\r\n    gap: 0.75rem;\r\n    padding-top: 1rem;\r\n    opacity: 0.8;\r\n    font-size: 0.89rem;\r\n    --tw-text-opacity: 1;\r\n    color: rgba(0, 114, 188, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.left-menu-container .acf-nav-menu ul {\r\n    color: rgb(0 114 188 / var(--tw-text-opacity));\r\n}\n}@media (min-width: 768px) {\r\n    .left-menu-container .acf-nav-menu ul {\r\n        display: flex;\r\n        flex-direction: row;\r\n        gap: 1.5rem;\r\n        padding-top: 0.8rem;\r\n    }\r\n}.left-menu-container {\r\n    display: flex;\r\n    align-items: flex-end;\r\n}/* Main Nav */#primary-nav-container nav div ul {\r\n  display: flex;\r\n}#primary-nav-container {\r\n    cursor: pointer;\r\n}#primary-nav-container nav div ul .sub-menu {\r\n    position: absolute;\r\n    left: 0;\r\n    top: 100%;\r\n    padding: 0 0 1rem 10rem;\r\n    display: flex;\r\n    flex-direction: column;\r\n    z-index: 1000;\r\n    width: 100%;\r\n    --tw-bg-opacity: 1;\r\n    background-color: rgba(255, 255, 255, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n#primary-nav-container nav div ul .sub-menu {\r\n    background-color: rgb(255 255 255 / var(--tw-bg-opacity));\r\n}\n}#primary-nav-container nav div ul .sub-menu li {\r\n    padding: 0.5rem 0;\r\n}#primary-nav-container nav div ul li a:hover {\r\n    font-weight: 600;\r\n    position: relative;\r\n}#primary-nav-container nav div ul li a:hover::after {\r\n    content: \"\";\r\n    position: absolute;\r\n    left: 0;\r\n    right: 0;\r\n    bottom: -4px;\r\n    height: 1px;\r\n    background-color: rgba(0, 114, 188, 0.8);\r\n}@media (min-width: 768px) {\r\n    #primary-nav-container nav div > ul > li {\r\n        margin: 0 0.75rem;\r\n    }\r\n}/* Forms */.gform-body label {\r\n    font-weight: 500 !important;\r\n    font-size: 1rem !important;\r\n}.gform-body input, .gform-body textarea {\r\n    border-bottom: 1px solid grey;\r\n}.gfield input:focus, .gfield textarea:focus {\r\n    outline: none !important;\r\n}.gfield textarea {\r\n    resize: none;\r\n    max-height: 100px;\r\n}.gform_footer .button {\r\n    background-color: black;\r\n    color: white;\r\n    width: 100%;\r\n    border-radius: 30px;\r\n    padding: 15px 20px;\r\n    cursor: pointer;\r\n    display: flex;\r\n    justify-content: space-between;\r\n    font-size: 1rem;\r\n}@media (min-width: 768px){\r\n    .gform_footer {\r\n        max-width: 300px; \r\n    }\r\n}.gform_button {\r\n    padding: 10px 0 10px 30px !important; \r\n}.gform_button {\r\n    text-align: left; \r\n}@media (min-width: 768px){\r\n    .gform_button {\r\n        padding: 20px 0 20px 30px !important; \r\n    }\r\n    .gform_button {\r\n        text-align: left; \r\n    }\r\n}.gform_footer .button:hover, .gform_footer .button:focus{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(118, 118, 118, 1);\r\n    border: 2px solid black;\r\n    transition: background-color 0.3s ease;\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.gform_footer .button:hover, .gform_footer .button:focus{\r\n    background-color: rgb(118 118 118 / var(--tw-bg-opacity));\r\n  }\n}/* NEW MAP */.block-map {\r\n    background: #0E1E37;\r\n}.map-region {\r\n    position: relative;\r\n    z-index: 10;\r\n    /* border-color: #beb7ac; */\r\n}.world-map,\r\n.marker-location {\r\n    display: none;\r\n}@media (min-width: 768px) {\r\n\r\n    .world-map,\r\n    .marker-location {\r\n        display: block;\r\n    }\r\n}/* Dont use tailwind hidden as is add important to display, then you would need to add more specificity to your other classes... */.hide-item {\r\n    display: none;\r\n}.show-item {\r\n    display: block;\r\n}.marker-location.active {\r\n    z-index: 30 !important;\r\n}.marker-pin,\r\n.marker-pin-cluster-icon {\r\n    position: relative;\r\n    display: block;\r\n    width: 18px;\r\n    height: 18px;\r\n    border-radius: 100%;\r\n    cursor: pointer;\r\n    border-style: solid;\r\n    border-width: 1px;\r\n    border-color: #B2ABA0;\r\n    box-sizing: border-box;\r\n    overflow: hidden;\r\n    animation-name: colorChange;\r\n    animation-iteration-count: infinite;\r\n    animation-direction: alternate;\r\n}.marker-pin::before,\r\n.marker-pin-cluster-icon::before {\r\n    content: '';\r\n    position: absolute;\r\n    top: 50%;\r\n    left: 50%;\r\n    width: 100%;\r\n    height: 100%;\r\n    background-color: #B2ABA0;\r\n    border-radius: 100%;\r\n    transform: translate(-50%, -50%);\r\n    animation-name: shrinkColorChange;\r\n    animation-iteration-count: infinite;\r\n    animation-direction: alternate;\r\n}.marker-location.active .marker-pin {\r\n    animation-name: none;\r\n    width: 22px;\r\n    height: 22px;\r\n    border-style: solid;\r\n    border-color: #A48942;\r\n    border-width: 1px;\r\n    box-sizing: border-box;\r\n}.marker-location.active .marker-pin::before {\r\n    animation-name: none;\r\n    width: 12px;\r\n    height: 12px;\r\n    background: #A48942;\r\n}.marker-pin-cluster {\r\n    position: relative;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    gap: 10px;\r\n    border: solid 1px white;\r\n    border-radius: 20px;\r\n    padding: 10px 10px 10px 8px;\r\n    cursor: pointer;\r\n    background-color: #ffffff;\r\n    box-sizing: border-box;\r\n    overflow: hidden;\r\n}.marker-pin-cluster-text {\r\n    font-size: 14px;\r\n    color: #000;\r\n    line-height: 1;\r\n}@keyframes shrinkColorChange {\r\n\r\n    0% {\r\n        background-color: #B2ABA0;\r\n        transform: translate(-50%, -50%) scale(1.1);\r\n    }\r\n\r\n    100% {\r\n        background-color: #A48942;\r\n        transform: translate(-50%, -50%) scale(0.25);\r\n    }\r\n}@keyframes colorChange {\r\n\r\n    0% {\r\n        border-color: #B2ABA0;\r\n    }\r\n\r\n    100% {\r\n        border-color: #A48942;\r\n    }\r\n}[data-location=\"america-lst\"] .marker-pin,\r\n[data-location=\"america-lst\"] .marker-pin::before {\r\n    animation-duration: 0.9s;\r\n}[data-location=\"america-ameribolt-2\"] .marker-pin,\r\n[data-location=\"america-ameribolt-2\"] .marker-pin::before {\r\n    animation-duration: 1.1s;\r\n}[data-location=\"america-lfh\"] .marker-pin,\r\n[data-location=\"america-lfh\"] .marker-pin::before {\r\n    animation-duration: 1.3s;\r\n}[data-location=\"america-tlf\"] .marker-pin,\r\n[data-location=\"america-tlf\"] .marker-pin::before {\r\n    animation-duration: 1s;\r\n}[data-location=\"america-ameribolt-3\"] .marker-pin,\r\n[data-location=\"america-ameribolt-3\"] .marker-pin::before {\r\n    animation-duration: 1.2s;\r\n}[data-location=\"america-ameribolt-1\"] .marker-pin,\r\n[data-location=\"america-ameribolt-1\"] .marker-pin::before {\r\n    animation-duration: 1.125s;\r\n}[data-location=\"america-eh\"] .marker-pin,\r\n[data-location=\"america-eh\"] .marker-pin::before {\r\n    animation-duration: 1.1s;\r\n}[data-location=\"birmingham-4\"] .marker-pin,\r\n[data-location=\"birmingham-4\"] .marker-pin::before {\r\n    animation-duration: 0.9s;\r\n}[data-location=\"wolverhampton\"] .marker-pin,\r\n[data-location=\"wolverhampton\"] .marker-pin::before {\r\n    animation-duration: 1.1s;\r\n}[data-location=\"birmingham-1\"] .marker-pin,\r\n[data-location=\"birmingham-1\"] .marker-pin::before {\r\n    animation-duration: 1.3s;\r\n}[data-location=\"birmingham-2\"] .marker-pin,\r\n[data-location=\"birmingham-2\"] .marker-pin::before {\r\n    animation-duration: 1s;\r\n}[data-location=\"birmingham-3\"] .marker-pin,\r\n[data-location=\"birmingham-3\"] .marker-pin::before {\r\n    animation-duration: 1.2s;\r\n}[data-location=\"leeds\"] .marker-pin,\r\n[data-location=\"leeds\"] .marker-pin::before {\r\n    animation-duration: 1s;\r\n}[data-location=\"white-lea\"] .marker-pin,\r\n[data-location=\"white-lea\"] .marker-pin::before {\r\n    animation-duration: 1.2s;\r\n}[data-location=\"romania\"] .marker-pin,\r\n[data-location=\"romania\"] .marker-pin::before {\r\n    animation-duration: 1s;\r\n}[data-location=\"dubai-1\"] .marker-pin,\r\n[data-location=\"dubai-1\"] .marker-pin::before {\r\n    animation-duration: 1.2s;\r\n}[data-location=\"india\"] .marker-pin,\r\n[data-location=\"india\"] .marker-pin::before {\r\n    animation-duration: 1.3s;\r\n}[data-location=\"china\"] .marker-pin,\r\n[data-location=\"china\"] .marker-pin::before {\r\n    animation-duration: 1.1s;\r\n}[data-location=\"singapore\"] .marker-pin,\r\n[data-location=\"singapore\"] .marker-pin::before {\r\n    animation-duration: 1.3s;\r\n}[data-location=\"australia\"] .marker-pin,\r\n[data-location=\"australia\"] .marker-pin::before {\r\n    animation-duration: 0.9s;\r\n}[data-location] .marker-pin-cluster-icon,\r\n[data-location] .marker-pin-cluster-icon::before {\r\n    animation-duration: 1s;\r\n}/* Mobile styles */.continent-marker-container {\r\n    background-color: #15253F;\r\n}.marker-info {\r\n    display: none;\r\n}.marker-logo.open .marker-info {\r\n    display: block;\r\n}@media (min-width: 768px) {\r\n    .marker-info {\r\n        display: block;\r\n    }\r\n\r\n    .expand-icon-map {\r\n        display: none;\r\n    }\r\n}.expand-icon-map-mobile::before {\r\n    content: '+';\r\n    font-size: 1.5rem;\r\n}.open.expand-icon-map-mobile::before {\r\n    content: '-';\r\n}.marker-logo.open .expand-icon-map-mobile::before {\r\n    content: '-';\r\n}.embed-container > iframe {\r\n    width: 100%;\r\n    height: 80vh;\r\n}.pagination .navigation {\r\n    display: flex;\r\n    justify-content: center;\r\n}.pagination .navigation .nav-links .current {\r\n    color: black !important;\r\n    padding: 15px !important;\r\n    font-weight: 500 !important;\r\n}.pagination .navigation .nav-links .current {\r\n    display: inline-flex;\r\n    border: 2px solid #0072BC;\r\n    border-radius: 50%;\r\n    width: 1.5rem;\r\n    height: 1.5rem;\r\n    align-items: center;\r\n    justify-content: center;\r\n}.pagination .navigation .nav-links .page-numbers {\r\n    color: grey;\r\n    padding: 0 5px;\r\n}.pagination .navigation .nav-links .page-numbers:hover {\r\n    font-weight: 600;\r\n}.pagination .navigation .nav-links .prev, .pagination .navigation .nav-links .next { \r\n    color: black;\r\n}.pagination .navigation .nav-links .prev::after {\r\n    content: \"➔\";\r\n    display: inline-block;\r\n    transform: scaleX(-1);\r\n}.pagination .navigation .nav-links .next::after {\r\n    content: \"➔\"; \r\n}.news_archive .grid article a div button {\r\n    color: #0072BC;\r\n}/* Pagination for Carousel Block */.swiper-pagination-bullet{\r\n  --tw-bg-opacity: 1 !important;\r\n  background-color: rgba(255, 255, 255, 1) !important;\r\n    opacity: 1 !important;\r\n    height: 10px !important;\r\n    width: 10px !important;\r\n}.swiper-pagination-bullet{\r\n    padding: 5px;\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.swiper-pagination-bullet{\r\n    background-color: rgb(255 255 255 / var(--tw-bg-opacity)) !important;\r\n  }\n}.swiper-pagination-bullet-active {\r\n    background-color: transparent !important;\r\n}.swiper-pagination-bullet-active {\r\n    display: inline-block;\r\n    border: 1px solid #FFFFFF;\r\n    padding: 10px;\r\n    position: relative;\r\n    top: 5px;\r\n}.swiper-pagination-bullet-active::after {\r\n    display: block;\r\n    content: \"\";\r\n    --tw-bg-opacity: 1;\r\n    background-color: rgba(255, 255, 255, 1);\r\n    width: 4px;\r\n    height: 4px;\r\n    border-radius: 50%;\r\n    position: absolute;\r\n    top: 50%;\r\n    left: 50%;\r\n    transform: translate(-50%, -50%);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.swiper-pagination-bullet-active::after {\r\n    background-color: rgb(255 255 255 / var(--tw-bg-opacity));\r\n}\n}/*  This stylsheet was provided by Lonestar for inner iframe styling, empty classes/attributes have been removed */#gnewtonIframe {\r\n    padding: 0 1.5rem;\r\n}@media (min-width: 768px) {\r\n    #gnewtonIframe {\r\n        padding: 0 4rem;\r\n    }\r\n}@media (min-width: 1025px) {\r\n    #gnewtonIframe {\r\n        padding: 0 10rem;\r\n    }\r\n}/* Remove jobid location etc from the job description page. */#gnewtonJobDescription #gnewtonJobPosition,\r\n#gnewtonJobDescription #gnewtonJobLocation,\r\n#gnewtonJobDescription #gnewtonJobID,\r\n#gnewtonJobDescription #gnewtonJobOpening,\r\n#gnewtonJobDescription hr,\r\ntd#gnewtonJobLocationInfo {\r\n  display: none;\r\n}/* Remove application code box for returning applicants to online form. */#gnewtonApplicationBox * {\r\n  display: none;\r\n}/* Remove incorrect veteran status boxes on bottom of online application form. */#veteran31,\r\n#veteran32,\r\n#veteran33,\r\n#veteran34 {\r\n  margin-left: 40px;\r\n}/* Make sure that images and labels display properly. */label {\r\n  display: inline;\r\n}img {\r\n  display: inline;\r\n}/* Increased spacing for generic resume submission. */#gnewtonGeneric td {\r\n  padding-top: 20px !important;\r\n}/* Match fonts for the main page and submission page. */#gnewtonCareerBody * {\r\n  color: #000;\r\n  font-family: 'Signika';\r\n  font-size: 14px;\r\n  line-height: 23px;\r\n}#gnewtonLandingArea * {\r\n  color: #000;\r\n  font-family: 'Signika';\r\n  font-size: 14px;\r\n  line-height: 23px;\r\n}.gnewtonCareerGroupHeaderClass {\r\n  color: #000 !important;\r\n  font-family: 'Signika' !important;\r\n  font-size: 17px !important;\r\n  line-height: 25px !important;\r\n}.gnewtonCareerGroupHeaderClass {\r\n  font-weight: bold;\r\n}/* Match fonts for the links. */#gnewtonCareerBody a,\r\n#gnewtonLandingArea a,\r\ndiv#backToCareerHome a,\r\n#gnewtonLogo a.newton_policy {\r\n  color: #0072bc;\r\n\r\n  -webkit-text-decoration: underline;\r\n\r\n  text-decoration: underline;\r\n}#gnewtonCareerBody a:hover,\r\n#gnewtonLandingArea a:hover,\r\ndiv#backToCareerHome a:hover {\r\n  color: #0072bc;\r\n  -webkit-text-decoration: none;\r\n  text-decoration: none;\r\n}/* Fix the Clear All Fields link. Set width to 100 or 115px if wrapping occurs. */.button.newtonStoreReset.block {\r\n  color: rgb(52, 152, 219) !important;\r\n}.button.newtonStoreReset.block {\r\n  background-color: rgba(0, 0, 0, 0);\r\n}.button.newtonStoreReset.block:hover {\r\n  color: rgb(136, 189, 229) !important;\r\n}/* Fix Job Search Buttons */select#gnewtonLocation,\r\nselect#gnewtonDepartment {\r\n  width: 100%;\r\n}/* Fix Choose a File link. */label#resumeDropLocalFile {\r\n  color: #3498db;\r\n}/* Fix filename in uploaded resume blue box. */#resumeDropped span.filename {\r\n  color: white;\r\n}/* Hide department and location sort labels */.gnewtonSortByJob {\r\n  display: none !important;\r\n}.gnewtonSortByLocationOrDepartment {\r\n  display: none !important;\r\n}/* Fix remove link in uploaded resume blue box. */#resumeDropped .bar .closeBtn {\r\n  color: #aed6f1 !important;\r\n}#resumeDropped .bar .closeBtn {\r\n  -webkit-text-decoration: none;\r\n  text-decoration: none;\r\n}/* Bold section titles. */dt.gnewtonSectionTitleClass {\r\n  font-weight: bold;\r\n}/* Bold all p inside the application. */#gnewtonResumeFormTable p {\r\n  font-weight: bold;\r\n}/* Un-bold the Applicant's Statement section. */#gnewtonAppState p {\r\n  font-weight: normal;\r\n}/* Reposition the \"Yes\" and \"No\" inside the Min Qual buttons. */td.gnewtonQuestions div {\r\n  line-height: 25px !important;\r\n}/* Fix colors on attachment upload links. */label.emptyFileInput {\r\n  color: #3498db !important;\r\n}label.emptyFileInput:hover {\r\n  color: #88bde5 !important;\r\n}/* Bold uploaded attachment names. */div.filledFileInput span {\r\n  font-weight: bold;\r\n}/* Change Newton button colors to match. */#gnewtonCareerBody div.gnewtonBlueBtn,\r\n#gnewtonCareerBody button.gnewtonBlueBtn,\r\ndiv.gnewtonContinueBtn {\r\n  background-color: #0072bc !important;\r\n  border-radius: 0px !important;\r\n  font-family: 'Signika' !important;\r\n  text-align: center !important;\r\n}#gnewtonCareerBody div.gnewtonBlueBtn:hover,\r\n#gnewtonCareerBody button.gnewtonBlueBtn:hover,\r\ndiv.gnewtonContinueBtn:hover {\r\n  -webkit-text-decoration: underline !important;\r\n  text-decoration: underline !important;\r\n}#gnewtonCareerBody div.gnewtonBlueBtn.disabled,\r\ndiv#saveBtn.disabled,\r\n#gnewtonCareerBody button.gnewtonBlueBtn.disabled,\r\n#gnewtonCareerBody div.gnewtonBlueBtn[disabled],\r\n#gnewtonCareerBody button.gnewtonBlueBtn[disabled] {\r\n  background: #ccd3d8 !important;\r\n}/* Adjust Indeed button colors to match. */#gnewtonCareerBody #gnewtonJobDescriptionBtn > div > .indeed-apply-widget > a {\r\n  background: #3498db !important;\r\n}#gnewtonCareerBody\r\n  #gnewtonJobDescriptionBtn\r\n  > div\r\n  > .indeed-apply-widget\r\n  > a\r\n  > span\r\n  > span {\r\n  color: white !important;\r\n}#gnewtonCareerBody\r\n  #gnewtonJobDescriptionBtn\r\n  > div\r\n  > .indeed-apply-widget.indeed-apply-status-applied#indeed-apply-widget\r\n  > a:hover {\r\n  background: #88bde5 !important;\r\n}/* Adjust vertical alignment on EEO VEVRAA options. */form#gnewton-vevraa-form span.radio-label {\r\n  top: 0px !important;\r\n}form#gnewton-vevraa-form span.radio-label {\r\n  position: relative;\r\n}/* Fix search button text alignment. */div#gnewtonSearchBtn {\r\n  line-height: 18px;\r\n}div#gnewtonCareerBody {\r\n  margin: auto !important;\r\n}input[type='checkbox'] {\r\n  padding: 5px;\r\n}/*STYLING FOR MOBILE EXPERIENCE */@media only screen and (max-width: 500px) {\r\n  table.gnewtonJobFilter tr,\r\n  tbody,\r\n  td {\r\n    display: block;\r\n  }\r\n\r\n  input#gnewtonKeyword {\r\n    margin-bottom: 5px !important;\r\n  }\r\n  .gnewtonCareerGroupRowClass {\r\n    word-wrap: break-word !important;\r\n    white-space: normal !important;\r\n  }\r\n\r\n  .gnewtonJobLink a,\r\n  .gnewtonJobLink a:visited,\r\n  .gnewtonJobNode a,\r\n  .gnewtonJobNode a:visited,\r\n  .gnewtonNode a,\r\n  .gnewtonNode a:visited,\r\n  .gnewtonCareerGroupJobTitleClass a,\r\n  .gnewtonCareerGroupJobTitleClass {\r\n    white-space: normal !important;\r\n  }\r\n\r\n  #gnewtonCareerBody * {\r\n    font-size: 15px !important;\r\n  }\r\n}/* ! tailwindcss v3.3.2 | MIT License | https://tailwindcss.com *//*\n1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)\n2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)\n*/*,\n::before,\n::after {\n  box-sizing: border-box; /* 1 */\n  border-width: 0; /* 2 */\n  border-style: solid; /* 2 */\n  border-color: #e5e7eb; /* 2 */\n}::before,\n::after {\n  --tw-content: '';\n}/*\n1. Use a consistent sensible line-height in all browsers.\n2. Prevent adjustments of font size after orientation changes in iOS.\n3. Use a more readable tab size.\n4. Use the user's configured `sans` font-family by default.\n5. Use the user's configured `sans` font-feature-settings by default.\n6. Use the user's configured `sans` font-variation-settings by default.\n*/html {\n  line-height: 1.5; /* 1 */\n  -webkit-text-size-adjust: 100%; /* 2 */\n  -moz-tab-size: 4; /* 3 */\n  tab-size: 4; /* 3 */\n  font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, \"Noto Sans\", sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\"; /* 4 */\n  font-feature-settings: normal; /* 5 */\n  font-variation-settings: normal; /* 6 */\n}/*\n1. Remove the margin in all browsers.\n2. Inherit line-height from `html` so users can set them as a class directly on the `html` element.\n*/body {\n  margin: 0; /* 1 */\n  line-height: inherit; /* 2 */\n}/*\n1. Add the correct height in Firefox.\n2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)\n3. Ensure horizontal rules are visible by default.\n*/hr {\n  height: 0; /* 1 */\n  color: inherit; /* 2 */\n  border-top-width: 1px; /* 3 */\n}/*\nAdd the correct text decoration in Chrome, Edge, and Safari.\n*/abbr:where([title]) {\n  text-decoration: underline;\n  -webkit-text-decoration: underline dotted;\n          text-decoration: underline dotted;\n}/*\nRemove the default font size and weight for headings.\n*/h1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  font-size: inherit;\n  font-weight: inherit;\n}/*\nReset links to optimize for opt-in styling instead of opt-out.\n*/a {\n  color: inherit;\n  text-decoration: inherit;\n}/*\nAdd the correct font weight in Edge and Safari.\n*/b,\nstrong {\n  font-weight: bolder;\n}/*\n1. Use the user's configured `mono` font family by default.\n2. Correct the odd `em` font sizing in all browsers.\n*/code,\nkbd,\nsamp,\npre {\n  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace; /* 1 */\n  font-size: 1em; /* 2 */\n}/*\nAdd the correct font size in all browsers.\n*/small {\n  font-size: 80%;\n}/*\nPrevent `sub` and `sup` elements from affecting the line height in all browsers.\n*/sub,\nsup {\n  font-size: 75%;\n  line-height: 0;\n  position: relative;\n  vertical-align: baseline;\n}sub {\n  bottom: -0.25em;\n}sup {\n  top: -0.5em;\n}/*\n1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)\n2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)\n3. Remove gaps between table borders by default.\n*/table {\n  text-indent: 0; /* 1 */\n  border-color: inherit; /* 2 */\n  border-collapse: collapse; /* 3 */\n}/*\n1. Change the font styles in all browsers.\n2. Remove the margin in Firefox and Safari.\n3. Remove default padding in all browsers.\n*/button,\ninput,\noptgroup,\nselect,\ntextarea {\n  font-family: inherit; /* 1 */\n  font-size: 100%; /* 1 */\n  font-weight: inherit; /* 1 */\n  line-height: inherit; /* 1 */\n  color: inherit; /* 1 */\n  margin: 0; /* 2 */\n  padding: 0; /* 3 */\n}/*\nRemove the inheritance of text transform in Edge and Firefox.\n*/button,\nselect {\n  text-transform: none;\n}/*\n1. Correct the inability to style clickable types in iOS and Safari.\n2. Remove default button styles.\n*/button,\n[type='button'],\n[type='reset'],\n[type='submit'] {\n  -webkit-appearance: button; /* 1 */\n  background-color: transparent; /* 2 */\n  background-image: none; /* 2 */\n}/*\nUse the modern Firefox focus style for all focusable elements.\n*/:-moz-focusring {\n  outline: auto;\n}/*\nRemove the additional `:invalid` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)\n*/:-moz-ui-invalid {\n  box-shadow: none;\n}/*\nAdd the correct vertical alignment in Chrome and Firefox.\n*/progress {\n  vertical-align: baseline;\n}/*\nCorrect the cursor style of increment and decrement buttons in Safari.\n*/::-webkit-inner-spin-button,\n::-webkit-outer-spin-button {\n  height: auto;\n}/*\n1. Correct the odd appearance in Chrome and Safari.\n2. Correct the outline style in Safari.\n*/[type='search'] {\n  -webkit-appearance: textfield; /* 1 */\n  outline-offset: -2px; /* 2 */\n}/*\nRemove the inner padding in Chrome and Safari on macOS.\n*/::-webkit-search-decoration {\n  -webkit-appearance: none;\n}/*\n1. Correct the inability to style clickable types in iOS and Safari.\n2. Change font properties to `inherit` in Safari.\n*/::-webkit-file-upload-button {\n  -webkit-appearance: button; /* 1 */\n  font: inherit; /* 2 */\n}/*\nAdd the correct display in Chrome and Safari.\n*/summary {\n  display: list-item;\n}/*\nRemoves the default spacing and border for appropriate elements.\n*/blockquote,\ndl,\ndd,\nh1,\nh2,\nh3,\nh4,\nh5,\nh6,\nhr,\nfigure,\np,\npre {\n  margin: 0;\n}fieldset {\n  margin: 0;\n  padding: 0;\n}legend {\n  padding: 0;\n}ol,\nul,\nmenu {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}/*\nPrevent resizing textareas horizontally by default.\n*/textarea {\n  resize: vertical;\n}/*\n1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)\n2. Set the default placeholder color to the user's configured gray 400 color.\n*/input::placeholder,\ntextarea::placeholder {\n  opacity: 1; /* 1 */\n  color: #9ca3af; /* 2 */\n}/*\nSet the default cursor for buttons.\n*/button,\n[role=\"button\"] {\n  cursor: pointer;\n}/*\nMake sure disabled buttons don't get the pointer cursor.\n*/:disabled {\n  cursor: default;\n}/*\n1. Make replaced elements `display: block` by default. (https://github.com/mozdevs/cssremedy/issues/14)\n2. Add `vertical-align: middle` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)\n   This can trigger a poorly considered lint error in some tools but is included by design.\n*/img,\nsvg,\nvideo,\ncanvas,\naudio,\niframe,\nembed,\nobject {\n  display: block; /* 1 */\n  vertical-align: middle; /* 2 */\n}/*\nConstrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)\n*/img,\nvideo {\n  max-width: 100%;\n  height: auto;\n}/* Make elements with the HTML hidden attribute stay hidden by default */[hidden] {\n  display: none;\n}*, ::before, ::after{\r\n  --tw-border-spacing-x: 0;\r\n  --tw-border-spacing-y: 0;\r\n  --tw-translate-x: 0;\r\n  --tw-translate-y: 0;\r\n  --tw-rotate: 0;\r\n  --tw-skew-x: 0;\r\n  --tw-skew-y: 0;\r\n  --tw-scale-x: 1;\r\n  --tw-scale-y: 1;\r\n  --tw-pan-x:  ;\r\n  --tw-pan-y:  ;\r\n  --tw-pinch-zoom:  ;\r\n  --tw-scroll-snap-strictness: proximity;\r\n  --tw-gradient-from-position:  ;\r\n  --tw-gradient-via-position:  ;\r\n  --tw-gradient-to-position:  ;\r\n  --tw-ordinal:  ;\r\n  --tw-slashed-zero:  ;\r\n  --tw-numeric-figure:  ;\r\n  --tw-numeric-spacing:  ;\r\n  --tw-numeric-fraction:  ;\r\n  --tw-ring-inset:  ;\r\n  --tw-ring-offset-width: 0px;\r\n  --tw-ring-offset-color: #fff;\r\n  --tw-ring-color: rgba(59, 130, 246, 0.5);\r\n  --tw-ring-offset-shadow: 0 0 rgba(0,0,0,0);\r\n  --tw-ring-shadow: 0 0 rgba(0,0,0,0);\r\n  --tw-shadow: 0 0 rgba(0,0,0,0);\r\n  --tw-shadow-colored: 0 0 rgba(0,0,0,0);\r\n  --tw-blur:  ;\r\n  --tw-brightness:  ;\r\n  --tw-contrast:  ;\r\n  --tw-grayscale:  ;\r\n  --tw-hue-rotate:  ;\r\n  --tw-invert:  ;\r\n  --tw-saturate:  ;\r\n  --tw-sepia:  ;\r\n  --tw-drop-shadow:  ;\r\n  --tw-backdrop-blur:  ;\r\n  --tw-backdrop-brightness:  ;\r\n  --tw-backdrop-contrast:  ;\r\n  --tw-backdrop-grayscale:  ;\r\n  --tw-backdrop-hue-rotate:  ;\r\n  --tw-backdrop-invert:  ;\r\n  --tw-backdrop-opacity:  ;\r\n  --tw-backdrop-saturate:  ;\r\n  --tw-backdrop-sepia:  ;\r\n}::backdrop{\r\n  --tw-border-spacing-x: 0;\r\n  --tw-border-spacing-y: 0;\r\n  --tw-translate-x: 0;\r\n  --tw-translate-y: 0;\r\n  --tw-rotate: 0;\r\n  --tw-skew-x: 0;\r\n  --tw-skew-y: 0;\r\n  --tw-scale-x: 1;\r\n  --tw-scale-y: 1;\r\n  --tw-pan-x:  ;\r\n  --tw-pan-y:  ;\r\n  --tw-pinch-zoom:  ;\r\n  --tw-scroll-snap-strictness: proximity;\r\n  --tw-gradient-from-position:  ;\r\n  --tw-gradient-via-position:  ;\r\n  --tw-gradient-to-position:  ;\r\n  --tw-ordinal:  ;\r\n  --tw-slashed-zero:  ;\r\n  --tw-numeric-figure:  ;\r\n  --tw-numeric-spacing:  ;\r\n  --tw-numeric-fraction:  ;\r\n  --tw-ring-inset:  ;\r\n  --tw-ring-offset-width: 0px;\r\n  --tw-ring-offset-color: #fff;\r\n  --tw-ring-color: rgba(59, 130, 246, 0.5);\r\n  --tw-ring-offset-shadow: 0 0 rgba(0,0,0,0);\r\n  --tw-ring-shadow: 0 0 rgba(0,0,0,0);\r\n  --tw-shadow: 0 0 rgba(0,0,0,0);\r\n  --tw-shadow-colored: 0 0 rgba(0,0,0,0);\r\n  --tw-blur:  ;\r\n  --tw-brightness:  ;\r\n  --tw-contrast:  ;\r\n  --tw-grayscale:  ;\r\n  --tw-hue-rotate:  ;\r\n  --tw-invert:  ;\r\n  --tw-saturate:  ;\r\n  --tw-sepia:  ;\r\n  --tw-drop-shadow:  ;\r\n  --tw-backdrop-blur:  ;\r\n  --tw-backdrop-brightness:  ;\r\n  --tw-backdrop-contrast:  ;\r\n  --tw-backdrop-grayscale:  ;\r\n  --tw-backdrop-hue-rotate:  ;\r\n  --tw-backdrop-invert:  ;\r\n  --tw-backdrop-opacity:  ;\r\n  --tw-backdrop-saturate:  ;\r\n  --tw-backdrop-sepia:  ;\r\n}.container{\r\n  width: 100%;\r\n}@media (min-width: 640px){.container{\r\n    max-width: 640px;\r\n  }\r\n}@media (min-width: 768px){.container{\r\n    max-width: 768px;\r\n  }\r\n}@media (min-width: 1025px){.container{\r\n    max-width: 1025px;\r\n  }\r\n}@media (min-width: 1400px){.container{\r\n    max-width: 1400px;\r\n  }\r\n}.sr-only{\r\n  position: absolute;\r\n  width: 1px;\r\n  height: 1px;\r\n  padding: 0;\r\n  margin: -1px;\r\n  overflow: hidden;\r\n  clip: rect(0, 0, 0, 0);\r\n  white-space: nowrap;\r\n  border-width: 0;\r\n}.\\!static{\r\n  position: static !important;\r\n}.static{\r\n  position: static;\r\n}.absolute{\r\n  position: absolute;\r\n}.relative{\r\n  position: relative;\r\n}.inset-0{\r\n  top: 0px;\r\n  right: 0px;\r\n  bottom: 0px;\r\n  left: 0px;\r\n}.bottom-0{\r\n  bottom: 0px;\r\n}.left-0{\r\n  left: 0px;\r\n}.left-2{\r\n  left: 0.5rem;\r\n}.top-\\[355px\\]{\r\n  top: 355px;\r\n}.top-\\[380px\\]{\r\n  top: 380px;\r\n}.z-10{\r\n  z-index: 10;\r\n}.col-span-1{\r\n  grid-column: span 1 / span 1;\r\n}.col-span-2{\r\n  grid-column: span 2 / span 2;\r\n}.col-span-3{\r\n  grid-column: span 3 / span 3;\r\n}.my-4{\r\n  margin-top: 1rem;\r\n  margin-bottom: 1rem;\r\n}.my-6{\r\n  margin-top: 1.5rem;\r\n  margin-bottom: 1.5rem;\r\n}.\\!ml-2{\r\n  margin-left: 0.5rem !important;\r\n}.\\!mr-2{\r\n  margin-right: 0.5rem !important;\r\n}.\\!mt-0{\r\n  margin-top: 0px !important;\r\n}.mb-0{\r\n  margin-bottom: 0px;\r\n}.mb-0\\.5{\r\n  margin-bottom: 0.125rem;\r\n}.mb-4{\r\n  margin-bottom: 1rem;\r\n}.mb-6{\r\n  margin-bottom: 1.5rem;\r\n}.ml-2{\r\n  margin-left: 0.5rem;\r\n}.ml-3{\r\n  margin-left: 0.75rem;\r\n}.ml-auto{\r\n  margin-left: auto;\r\n}.mr-0{\r\n  margin-right: 0px;\r\n}.mt-0{\r\n  margin-top: 0px;\r\n}.mt-0\\.5{\r\n  margin-top: 0.125rem;\r\n}.mt-3{\r\n  margin-top: 0.75rem;\r\n}.mt-4{\r\n  margin-top: 1rem;\r\n}.mt-6{\r\n  margin-top: 1.5rem;\r\n}.mt-8{\r\n  margin-top: 2rem;\r\n}.block{\r\n  display: block;\r\n}.inline-block{\r\n  display: inline-block;\r\n}.inline{\r\n  display: inline;\r\n}.flex{\r\n  display: flex;\r\n}.grid{\r\n  display: grid;\r\n}.hidden{\r\n  display: none;\r\n}.h-0{\r\n  height: 0px;\r\n}.h-0\\.5{\r\n  height: 0.125rem;\r\n}.h-14{\r\n  height: 3.5rem;\r\n}.h-4{\r\n  height: 1rem;\r\n}.h-6{\r\n  height: 1.5rem;\r\n}.h-8{\r\n  height: 2rem;\r\n}.h-\\[1px\\]{\r\n  height: 1px;\r\n}.h-\\[216px\\]{\r\n  height: 216px;\r\n}.h-\\[229px\\]{\r\n  height: 229px;\r\n}.h-\\[471px\\]{\r\n  height: 471px;\r\n}.h-\\[685px\\]{\r\n  height: 685px;\r\n}.h-\\[75vh\\]{\r\n  height: 75vh;\r\n}.h-auto{\r\n  height: auto;\r\n}.h-full{\r\n  height: 100%;\r\n}.h-px{\r\n  height: 1px;\r\n}.max-h-10{\r\n  max-height: 2.5rem;\r\n}.max-h-20{\r\n  max-height: 5rem;\r\n}.max-h-6{\r\n  max-height: 1.5rem;\r\n}.max-h-\\[80vh\\]{\r\n  max-height: 80vh;\r\n}.max-h-full{\r\n  max-height: 100%;\r\n}.min-h-\\[50vh\\]{\r\n  min-height: 50vh;\r\n}.w-16{\r\n  width: 4rem;\r\n}.w-3{\r\n  width: 0.75rem;\r\n}.w-3\\.5{\r\n  width: 0.875rem;\r\n}.w-3\\/5{\r\n  width: 60%;\r\n}.w-4{\r\n  width: 1rem;\r\n}.w-4\\/5{\r\n  width: 80%;\r\n}.w-6{\r\n  width: 1.5rem;\r\n}.w-8{\r\n  width: 2rem;\r\n}.w-8\\/12{\r\n  width: 66.666667%;\r\n}.w-\\[435px\\]{\r\n  width: 435px;\r\n}.w-full{\r\n  width: 100%;\r\n}.max-w-\\[300px\\]{\r\n  max-width: 300px;\r\n}.flex-grow{\r\n  flex-grow: 1;\r\n}.\\!rotate-180{\r\n  --tw-rotate: 180deg !important;\r\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(180deg) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y)) !important;\r\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y)) !important;\r\n}.transform{\r\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\r\n}.cursor-grab{\r\n  cursor: grab;\r\n}.cursor-pointer{\r\n  cursor: pointer;\r\n}.resize{\r\n  resize: both;\r\n}.grid-cols-1{\r\n  grid-template-columns: repeat(1, minmax(0, 1fr));\r\n}.grid-cols-\\[minmax\\(100px\\2c _2fr\\)_3fr\\]{\r\n  grid-template-columns: minmax(100px, 2fr) 3fr;\r\n}.flex-col{\r\n  flex-direction: column;\r\n}.flex-col-reverse{\r\n  flex-direction: column-reverse;\r\n}.flex-wrap{\r\n  flex-wrap: wrap;\r\n}.items-start{\r\n  align-items: flex-start;\r\n}.items-center{\r\n  align-items: center;\r\n}.justify-end{\r\n  justify-content: flex-end;\r\n}.justify-center{\r\n  justify-content: center;\r\n}.justify-between{\r\n  justify-content: space-between;\r\n}.justify-around{\r\n  justify-content: space-around;\r\n}.gap-10{\r\n  gap: 2.5rem;\r\n}.gap-14{\r\n  gap: 3.5rem;\r\n}.gap-4{\r\n  gap: 1rem;\r\n}.gap-5{\r\n  gap: 1.25rem;\r\n}.gap-8{\r\n  gap: 2rem;\r\n}.gap-\\[10px\\]{\r\n  gap: 10px;\r\n}.gap-\\[30px\\]{\r\n  gap: 30px;\r\n}.gap-y-10{\r\n  row-gap: 2.5rem;\r\n}.space-y-3 > :not([hidden]) ~ :not([hidden]){\r\n  --tw-space-y-reverse: 0;\r\n  margin-top: calc(0.75rem * (1 - 0));\r\n  margin-top: calc(0.75rem * (1 - var(--tw-space-y-reverse)));\r\n  margin-top: calc(0.75rem * calc(1 - 0));\r\n  margin-top: calc(0.75rem * calc(1 - var(--tw-space-y-reverse)));\r\n  margin-bottom: calc(0.75rem * 0);\r\n  margin-bottom: calc(0.75rem * var(--tw-space-y-reverse));\r\n}.self-center{\r\n  align-self: center;\r\n}.overflow-hidden{\r\n  overflow: hidden;\r\n}.break-words{\r\n  word-wrap: break-word;\r\n}.rounded-full{\r\n  border-radius: 9999px;\r\n}.rounded-l-full{\r\n  border-top-left-radius: 9999px;\r\n  border-bottom-left-radius: 9999px;\r\n}.rounded-r-full{\r\n  border-top-right-radius: 9999px;\r\n  border-bottom-right-radius: 9999px;\r\n}.border-2{\r\n  border-width: 2px;\r\n}.border-b-2{\r\n  border-bottom-width: 2px;\r\n}.border-t{\r\n  border-top-width: 1px;\r\n}.border-t-2{\r\n  border-top-width: 2px;\r\n}.border-black{\r\n  --tw-border-opacity: 1;\r\n  border-color: rgba(0, 0, 0, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.border-black{\r\n    border-color: rgb(0 0 0 / var(--tw-border-opacity));\r\n  }\n}.border-grey{\r\n  --tw-border-opacity: 1;\r\n  border-color: rgba(118, 118, 118, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.border-grey{\r\n    border-color: rgb(118 118 118 / var(--tw-border-opacity));\r\n  }\n}.border-t-grey{\r\n  --tw-border-opacity: 1;\r\n  border-top-color: rgba(118, 118, 118, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.border-t-grey{\r\n    border-top-color: rgb(118 118 118 / var(--tw-border-opacity));\r\n  }\n}.border-opacity-50{\r\n  --tw-border-opacity: 0.5;\r\n}.bg-black{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(0, 0, 0, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.bg-black{\r\n    background-color: rgb(0 0 0 / var(--tw-bg-opacity));\r\n  }\n}.bg-blue{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(0, 114, 188, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.bg-blue{\r\n    background-color: rgb(0 114 188 / var(--tw-bg-opacity));\r\n  }\n}.bg-green-400{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(74, 222, 128, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.bg-green-400{\r\n    background-color: rgb(74 222 128 / var(--tw-bg-opacity));\r\n  }\n}.bg-grey{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(118, 118, 118, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.bg-grey{\r\n    background-color: rgb(118 118 118 / var(--tw-bg-opacity));\r\n  }\n}.bg-indigo-400{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(129, 140, 248, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.bg-indigo-400{\r\n    background-color: rgb(129 140 248 / var(--tw-bg-opacity));\r\n  }\n}.bg-red-400{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(248, 113, 113, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.bg-red-400{\r\n    background-color: rgb(248 113 113 / var(--tw-bg-opacity));\r\n  }\n}.bg-white{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(255, 255, 255, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.bg-white{\r\n    background-color: rgb(255 255 255 / var(--tw-bg-opacity));\r\n  }\n}.bg-yellow-400{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(250, 204, 21, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.bg-yellow-400{\r\n    background-color: rgb(250 204 21 / var(--tw-bg-opacity));\r\n  }\n}.bg-gradient-to-t{\r\n  background-image: linear-gradient(to top, var(--tw-gradient-stops));\r\n}.from-\\[rgba\\(0\\2c 0\\2c 0\\2c 0\\.3\\)\\]{\r\n  --tw-gradient-from: rgba(0,0,0,0.3) var(--tw-gradient-from-position);\r\n  --tw-gradient-to: rgba(0, 0, 0, 0) var(--tw-gradient-to-position);\r\n  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);\r\n}.to-transparent{\r\n  --tw-gradient-to: transparent var(--tw-gradient-to-position);\r\n}.bg-cover{\r\n  background-size: cover;\r\n}.bg-center{\r\n  background-position: center;\r\n}.object-contain{\r\n  object-fit: contain;\r\n}.object-cover{\r\n  object-fit: cover;\r\n}.p-0{\r\n  padding: 0px;\r\n}.p-5{\r\n  padding: 1.25rem;\r\n}.p-\\[0\\.25rem\\]{\r\n  padding: 0.25rem;\r\n}.px-2{\r\n  padding-left: 0.5rem;\r\n  padding-right: 0.5rem;\r\n}.px-4{\r\n  padding-left: 1rem;\r\n  padding-right: 1rem;\r\n}.px-5{\r\n  padding-left: 1.25rem;\r\n  padding-right: 1.25rem;\r\n}.px-6{\r\n  padding-left: 1.5rem;\r\n  padding-right: 1.5rem;\r\n}.px-8{\r\n  padding-left: 2rem;\r\n  padding-right: 2rem;\r\n}.py-1{\r\n  padding-top: 0.25rem;\r\n  padding-bottom: 0.25rem;\r\n}.py-2{\r\n  padding-top: 0.5rem;\r\n  padding-bottom: 0.5rem;\r\n}.py-3{\r\n  padding-top: 0.75rem;\r\n  padding-bottom: 0.75rem;\r\n}.py-4{\r\n  padding-top: 1rem;\r\n  padding-bottom: 1rem;\r\n}.py-5{\r\n  padding-top: 1.25rem;\r\n  padding-bottom: 1.25rem;\r\n}.py-6{\r\n  padding-top: 1.5rem;\r\n  padding-bottom: 1.5rem;\r\n}.py-8{\r\n  padding-top: 2rem;\r\n  padding-bottom: 2rem;\r\n}.pb-1{\r\n  padding-bottom: 0.25rem;\r\n}.pb-10{\r\n  padding-bottom: 2.5rem;\r\n}.pb-14{\r\n  padding-bottom: 3.5rem;\r\n}.pb-2{\r\n  padding-bottom: 0.5rem;\r\n}.pb-20{\r\n  padding-bottom: 5rem;\r\n}.pb-3{\r\n  padding-bottom: 0.75rem;\r\n}.pb-4{\r\n  padding-bottom: 1rem;\r\n}.pb-6{\r\n  padding-bottom: 1.5rem;\r\n}.pb-7{\r\n  padding-bottom: 1.75rem;\r\n}.pb-8{\r\n  padding-bottom: 2rem;\r\n}.pl-4{\r\n  padding-left: 1rem;\r\n}.pl-5{\r\n  padding-left: 1.25rem;\r\n}.pr-10{\r\n  padding-right: 2.5rem;\r\n}.pr-2{\r\n  padding-right: 0.5rem;\r\n}.pr-6{\r\n  padding-right: 1.5rem;\r\n}.pt-1{\r\n  padding-top: 0.25rem;\r\n}.pt-2{\r\n  padding-top: 0.5rem;\r\n}.pt-3{\r\n  padding-top: 0.75rem;\r\n}.pt-4{\r\n  padding-top: 1rem;\r\n}.pt-5{\r\n  padding-top: 1.25rem;\r\n}.pt-7{\r\n  padding-top: 1.75rem;\r\n}.pt-8{\r\n  padding-top: 2rem;\r\n}.\\!text-right{\r\n  text-align: right !important;\r\n}.\\!text-base{\r\n  font-size: 1rem !important;\r\n}.\\!text-lg{\r\n  font-size: 1.334rem !important;\r\n}.\\!text-sm{\r\n  font-size: 0.89rem !important;\r\n}.\\!text-xl{\r\n  font-size: 1.6rem !important;\r\n}.text-2xl{\r\n  font-size: 1.75rem;\r\n}.text-base{\r\n  font-size: 1rem;\r\n}.text-sm{\r\n  font-size: 0.89rem;\r\n}.text-xl{\r\n  font-size: 1.6rem;\r\n}.text-xxl{\r\n  font-size: 2.24rem;\r\n}.\\!font-bold{\r\n  font-weight: 700 !important;\r\n}.\\!font-medium{\r\n  font-weight: 500 !important;\r\n}.font-bold{\r\n  font-weight: 700;\r\n}.font-medium{\r\n  font-weight: 500;\r\n}.font-semibold{\r\n  font-weight: 600;\r\n}.uppercase{\r\n  text-transform: uppercase;\r\n}.leading-4{\r\n  line-height: 1rem;\r\n}.leading-normal{\r\n  line-height: 1.3;\r\n}.leading-relaxed{\r\n  line-height: 1.4;\r\n}.leading-snug{\r\n  line-height: 1.2;\r\n}.\\!text-black{\r\n  --tw-text-opacity: 1 !important;\r\n  color: rgba(0, 0, 0, 1) !important;\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.\\!text-black{\r\n    color: rgb(0 0 0 / var(--tw-text-opacity)) !important;\r\n  }\n}.\\!text-black\\/80{\r\n  color: rgba(0, 0, 0, 0.8) !important;\r\n}.text-black{\r\n  --tw-text-opacity: 1;\r\n  color: rgba(0, 0, 0, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.text-black{\r\n    color: rgb(0 0 0 / var(--tw-text-opacity));\r\n  }\n}.text-blue{\r\n  --tw-text-opacity: 1;\r\n  color: rgba(0, 114, 188, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.text-blue{\r\n    color: rgb(0 114 188 / var(--tw-text-opacity));\r\n  }\n}.text-green-50{\r\n  --tw-text-opacity: 1;\r\n  color: rgba(240, 253, 244, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.text-green-50{\r\n    color: rgb(240 253 244 / var(--tw-text-opacity));\r\n  }\n}.text-grey{\r\n  --tw-text-opacity: 1;\r\n  color: rgba(118, 118, 118, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.text-grey{\r\n    color: rgb(118 118 118 / var(--tw-text-opacity));\r\n  }\n}.text-indigo-50{\r\n  --tw-text-opacity: 1;\r\n  color: rgba(238, 242, 255, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.text-indigo-50{\r\n    color: rgb(238 242 255 / var(--tw-text-opacity));\r\n  }\n}.text-red-50{\r\n  --tw-text-opacity: 1;\r\n  color: rgba(254, 242, 242, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.text-red-50{\r\n    color: rgb(254 242 242 / var(--tw-text-opacity));\r\n  }\n}.text-white{\r\n  --tw-text-opacity: 1;\r\n  color: rgba(255, 255, 255, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.text-white{\r\n    color: rgb(255 255 255 / var(--tw-text-opacity));\r\n  }\n}.text-yellow-50{\r\n  --tw-text-opacity: 1;\r\n  color: rgba(254, 252, 232, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.text-yellow-50{\r\n    color: rgb(254 252 232 / var(--tw-text-opacity));\r\n  }\n}.underline{\r\n  text-decoration-line: underline;\r\n}.opacity-30{\r\n  opacity: 0.3;\r\n}.opacity-60{\r\n  opacity: 0.6;\r\n}.shadow-lg{\r\n  --tw-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);\r\n  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);\r\n  box-shadow: 0 0 rgba(0,0,0,0), 0 0 rgba(0,0,0,0), 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);\r\n  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);\r\n}.outline{\r\n  outline-style: solid;\r\n}.outline-1{\r\n  outline-width: 1px;\r\n}.transition-all{\r\n  transition-property: all;\r\n  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);\r\n  transition-duration: 150ms;\r\n}.transition-transform{\r\n  transition-property: transform;\r\n  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);\r\n  transition-duration: 150ms;\r\n}.duration-300{\r\n  transition-duration: 300ms;\r\n}/* GLOBAL STYLES */html {\r\n    font-size: 18px;\r\n}/* Fonts */@font-face {\r\n    src: url(\"../fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-700.woff2\") format(\"woff2\"), url(\"../fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-700.woff\") format(\"woff\");\r\n    font-family: \"ITCAvantGardeGothic\";\r\n    font-weight: 700;\r\n}@font-face {\r\n    src: url(\"../fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-600.woff2\") format(\"woff2\"), url(\"../fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-600.woff\") format(\"woff\");\r\n    font-family: \"ITCAvantGardeGothic\";\r\n    font-weight: 600;\r\n}@font-face {\r\n    src: url(\"../fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-500.woff2\") format(\"woff2\"), url(\"../fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-500.woff\") format(\"woff\");\r\n    font-family: \"ITCAvantGardeGothic\";\r\n    font-weight: 500;\r\n}/* Custom Global Styles */body {\r\n  font-family: 'ITCAvantGardeGothic', sans-serif;\r\n}.hidden {\r\n    display: none !important;\r\n}.after\\:\\!text-sm::after{\r\n  font-size: 0.89rem !important;\r\n}.after\\:\\!text-sm::after{\r\n  content: var(--tw-content);\r\n}.after\\:\\!content-\\[\\'\\'\\]::after{\r\n  --tw-content: '' !important;\r\n  content: '' !important;\r\n  content: var(--tw-content) !important;\r\n}.hover\\:-translate-y-2:hover{\r\n  --tw-translate-y: -0.5rem;\r\n  transform: translate(var(--tw-translate-x), -0.5rem) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\r\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\r\n}.hover\\:border-2:hover{\r\n  border-width: 2px;\r\n}.hover\\:border-black:hover{\r\n  --tw-border-opacity: 1;\r\n  border-color: rgba(0, 0, 0, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.hover\\:border-black:hover{\r\n    border-color: rgb(0 0 0 / var(--tw-border-opacity));\r\n  }\n}.hover\\:bg-grey:hover{\r\n  --tw-bg-opacity: 1;\r\n  background-color: rgba(118, 118, 118, 1);\r\n}@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.hover\\:bg-grey:hover{\r\n    background-color: rgb(118 118 118 / var(--tw-bg-opacity));\r\n  }\n}.hover\\:font-semibold:hover{\r\n  font-weight: 600;\r\n}.hover\\:outline-\\[3px\\]:hover{\r\n  outline-width: 3px;\r\n}.focus\\:not-sr-only:focus{\r\n  position: static;\r\n  width: auto;\r\n  height: auto;\r\n  padding: 0;\r\n  margin: 0;\r\n  overflow: visible;\r\n  clip: auto;\r\n  white-space: normal;\r\n}.focus\\:-translate-y-2:focus{\r\n  --tw-translate-y: -0.5rem;\r\n  transform: translate(var(--tw-translate-x), -0.5rem) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\r\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\r\n}.focus\\:font-semibold:focus{\r\n  font-weight: 600;\r\n}.focus\\:outline-\\[3px\\]:focus{\r\n  outline-width: 3px;\r\n}@media (min-width: 768px){.md\\:absolute{\r\n    position: absolute;\r\n  }.md\\:bottom-\\[30px\\]{\r\n    bottom: 30px;\r\n  }.md\\:left-8{\r\n    left: 2rem;\r\n  }.md\\:left-\\[2\\.5rem\\]{\r\n    left: 2.5rem;\r\n  }.md\\:right-\\[30px\\]{\r\n    right: 30px;\r\n  }.md\\:top-\\[2rem\\]{\r\n    top: 2rem;\r\n  }.md\\:top-\\[375px\\]{\r\n    top: 375px;\r\n  }.md\\:top-\\[400px\\]{\r\n    top: 400px;\r\n  }.md\\:my-8{\r\n    margin-top: 2rem;\r\n    margin-bottom: 2rem;\r\n  }.md\\:\\!block{\r\n    display: block !important;\r\n  }.md\\:flex{\r\n    display: flex;\r\n  }.md\\:hidden{\r\n    display: none;\r\n  }.md\\:h-1\\/3{\r\n    height: 33.333333%;\r\n  }.md\\:max-h-16{\r\n    max-height: 4rem;\r\n  }.md\\:w-1\\/2{\r\n    width: 50%;\r\n  }.md\\:w-1\\/3{\r\n    width: 33.333333%;\r\n  }.md\\:w-2\\/3{\r\n    width: 66.666667%;\r\n  }.md\\:w-20{\r\n    width: 5rem;\r\n  }.md\\:w-4\\/5{\r\n    width: 80%;\r\n  }.md\\:w-72{\r\n    width: 18rem;\r\n  }.md\\:w-full{\r\n    width: 100%;\r\n  }.md\\:w-px{\r\n    width: 1px;\r\n  }.md\\:max-w-\\[26rem\\]{\r\n    max-width: 26rem;\r\n  }.md\\:cursor-default{\r\n    cursor: default;\r\n  }.md\\:grid-cols-2{\r\n    grid-template-columns: repeat(2, minmax(0, 1fr));\r\n  }.md\\:grid-cols-3{\r\n    grid-template-columns: repeat(3, minmax(0, 1fr));\r\n  }.md\\:grid-cols-5{\r\n    grid-template-columns: repeat(5, minmax(0, 1fr));\r\n  }.md\\:grid-cols-\\[45\\%_45\\%_10\\%\\]{\r\n    grid-template-columns: 45% 45% 10%;\r\n  }.md\\:flex-row{\r\n    flex-direction: row;\r\n  }.md\\:flex-row-reverse{\r\n    flex-direction: row-reverse;\r\n  }.md\\:flex-nowrap{\r\n    flex-wrap: nowrap;\r\n  }.md\\:items-center{\r\n    align-items: center;\r\n  }.md\\:justify-end{\r\n    justify-content: flex-end;\r\n  }.md\\:justify-between{\r\n    justify-content: space-between;\r\n  }.md\\:gap-6{\r\n    gap: 1.5rem;\r\n  }.md\\:gap-8{\r\n    gap: 2rem;\r\n  }.md\\:gap-x-5{\r\n    -moz-column-gap: 1.25rem;\r\n         column-gap: 1.25rem;\r\n  }.md\\:self-center{\r\n    align-self: center;\r\n  }.md\\:border-b-0{\r\n    border-bottom-width: 0px;\r\n  }.md\\:border-b-2{\r\n    border-bottom-width: 2px;\r\n  }.md\\:border-r-2{\r\n    border-right-width: 2px;\r\n  }.md\\:bg-grey{\r\n    --tw-bg-opacity: 1;\r\n    background-color: rgba(118, 118, 118, 1);\r\n  }\n\n@supports (color: rgb(0 0 0 / 0)) and (top: var(--f)){\n.md\\:bg-grey{\r\n      background-color: rgb(118 118 118 / var(--tw-bg-opacity));\r\n    }\n}.md\\:\\!py-2{\r\n    padding-top: 0.5rem !important;\r\n    padding-bottom: 0.5rem !important;\r\n  }.md\\:px-0{\r\n    padding-left: 0px;\r\n    padding-right: 0px;\r\n  }.md\\:px-10{\r\n    padding-left: 2.5rem;\r\n    padding-right: 2.5rem;\r\n  }.md\\:px-11{\r\n    padding-left: 2.75rem;\r\n    padding-right: 2.75rem;\r\n  }.md\\:px-16{\r\n    padding-left: 4rem;\r\n    padding-right: 4rem;\r\n  }.md\\:px-4{\r\n    padding-left: 1rem;\r\n    padding-right: 1rem;\r\n  }.md\\:py-20{\r\n    padding-top: 5rem;\r\n    padding-bottom: 5rem;\r\n  }.md\\:py-5{\r\n    padding-top: 1.25rem;\r\n    padding-bottom: 1.25rem;\r\n  }.md\\:py-8{\r\n    padding-top: 2rem;\r\n    padding-bottom: 2rem;\r\n  }.md\\:pb-0{\r\n    padding-bottom: 0px;\r\n  }.md\\:pb-16{\r\n    padding-bottom: 4rem;\r\n  }.md\\:pb-3{\r\n    padding-bottom: 0.75rem;\r\n  }.md\\:pb-8{\r\n    padding-bottom: 2rem;\r\n  }.md\\:pl-0{\r\n    padding-left: 0px;\r\n  }.md\\:pl-10{\r\n    padding-left: 2.5rem;\r\n  }.md\\:pl-11{\r\n    padding-left: 2.75rem;\r\n  }.md\\:pr-0{\r\n    padding-right: 0px;\r\n  }.md\\:pt-0{\r\n    padding-top: 0px;\r\n  }.md\\:pt-2{\r\n    padding-top: 0.5rem;\r\n  }.md\\:pt-3{\r\n    padding-top: 0.75rem;\r\n  }.md\\:\\!text-base{\r\n    font-size: 1rem !important;\r\n  }.md\\:\\!text-lg{\r\n    font-size: 1.334rem !important;\r\n  }.md\\:\\!text-xxl{\r\n    font-size: 2.24rem !important;\r\n  }.md\\:text-2xxl{\r\n    font-size: 3rem;\r\n  }.md\\:text-base{\r\n    font-size: 1rem;\r\n  }.md\\:text-lg{\r\n    font-size: 1.334rem;\r\n  }.md\\:text-xxl{\r\n    font-size: 2.24rem;\r\n  }.md\\:\\!leading-normal{\r\n    line-height: 1.3 !important;\r\n  }.md\\:leading-loose{\r\n    line-height: 1.5;\r\n  }.md\\:leading-normal{\r\n    line-height: 1.3;\r\n  }.md\\:leading-relaxed{\r\n    line-height: 1.4;\r\n  }.md\\:opacity-40{\r\n    opacity: 0.4;\r\n  }\r\n}@media (min-width: 1025px){.lg\\:w-1\\/2{\r\n    width: 50%;\r\n  }.lg\\:w-2\\/3{\r\n    width: 66.666667%;\r\n  }.lg\\:gap-x-0{\r\n    -moz-column-gap: 0px;\r\n         column-gap: 0px;\r\n  }.lg\\:px-12{\r\n    padding-left: 3rem;\r\n    padding-right: 3rem;\r\n  }.lg\\:px-40{\r\n    padding-left: 10rem;\r\n    padding-right: 10rem;\r\n  }.lg\\:px-8{\r\n    padding-left: 2rem;\r\n    padding-right: 2rem;\r\n  }.lg\\:pl-32{\r\n    padding-left: 8rem;\r\n  }.lg\\:pt-12{\r\n    padding-top: 3rem;\r\n  }.lg\\:text-base{\r\n    font-size: 1rem;\r\n  }\r\n}@media (min-width: 1400px){.xl\\:px-24{\r\n    padding-left: 6rem;\r\n    padding-right: 6rem;\r\n  }.xl\\:px-56{\r\n    padding-left: 14rem;\r\n    padding-right: 14rem;\r\n  }\r\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./styles/app.css":
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("../node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("../node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("../node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("../node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("../node_modules/@roots/bud-support/lib/css-loader/index.cjs??css!../node_modules/postcss-loader/dist/cjs.js??postcss!./styles/app.css");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);


if (true) {
  if (!_node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
  if (!a && b || a && !b) {
    return false;
  }
  var p;
  for (p in a) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (a[p] !== b[p]) {
      return false;
    }
  }
  for (p in b) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (!a[p]) {
      return false;
    }
  }
  return true;
};
    var isNamedExport = !_node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals;
    var oldLocals = isNamedExport ? _node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

    module.hot.accept(
      "../node_modules/@roots/bud-support/lib/css-loader/index.cjs??css!../node_modules/postcss-loader/dist/cjs.js??postcss!./styles/app.css",
      __WEBPACK_OUTDATED_DEPENDENCIES__ => { /* harmony import */ _node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("../node_modules/@roots/bud-support/lib/css-loader/index.cjs??css!../node_modules/postcss-loader/dist/cjs.js??postcss!./styles/app.css");
(function () {
        if (!isEqualLocals(oldLocals, isNamedExport ? _node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals, isNamedExport)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = isNamedExport ? _node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

              update(_node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__["default"]);
      })(__WEBPACK_OUTDATED_DEPENDENCIES__); }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}



       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_roots_bud_support_lib_css_loader_index_cjs_css_node_modules_postcss_loader_dist_cjs_js_postcss_app_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "../node_modules/css-loader/dist/runtime/api.js":
/***/ ((module) => {



/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
module.exports = function (cssWithMappingToString) {
  var list = [];

  // return the list of modules as css string
  list.toString = function toString() {
    return this.map(function (item) {
      var content = "";
      var needLayer = typeof item[5] !== "undefined";
      if (item[4]) {
        content += "@supports (".concat(item[4], ") {");
      }
      if (item[2]) {
        content += "@media ".concat(item[2], " {");
      }
      if (needLayer) {
        content += "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {");
      }
      content += cssWithMappingToString(item);
      if (needLayer) {
        content += "}";
      }
      if (item[2]) {
        content += "}";
      }
      if (item[4]) {
        content += "}";
      }
      return content;
    }).join("");
  };

  // import a list of modules into the list
  list.i = function i(modules, media, dedupe, supports, layer) {
    if (typeof modules === "string") {
      modules = [[null, modules, undefined]];
    }
    var alreadyImportedModules = {};
    if (dedupe) {
      for (var k = 0; k < this.length; k++) {
        var id = this[k][0];
        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }
    for (var _k = 0; _k < modules.length; _k++) {
      var item = [].concat(modules[_k]);
      if (dedupe && alreadyImportedModules[item[0]]) {
        continue;
      }
      if (typeof layer !== "undefined") {
        if (typeof item[5] === "undefined") {
          item[5] = layer;
        } else {
          item[1] = "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {").concat(item[1], "}");
          item[5] = layer;
        }
      }
      if (media) {
        if (!item[2]) {
          item[2] = media;
        } else {
          item[1] = "@media ".concat(item[2], " {").concat(item[1], "}");
          item[2] = media;
        }
      }
      if (supports) {
        if (!item[4]) {
          item[4] = "".concat(supports);
        } else {
          item[1] = "@supports (".concat(item[4], ") {").concat(item[1], "}");
          item[4] = supports;
        }
      }
      list.push(item);
    }
  };
  return list;
};

/***/ }),

/***/ "../node_modules/css-loader/dist/runtime/getUrl.js":
/***/ ((module) => {



module.exports = function (url, options) {
  if (!options) {
    options = {};
  }
  if (!url) {
    return url;
  }
  url = String(url.__esModule ? url.default : url);

  // If url is already wrapped in quotes, remove them
  if (/^['"].*['"]$/.test(url)) {
    url = url.slice(1, -1);
  }
  if (options.hash) {
    url += options.hash;
  }

  // Should url be wrapped?
  // See https://drafts.csswg.org/css-values-3/#urls
  if (/["'() \t\n]|(%20)/.test(url) || options.needQuotes) {
    return "\"".concat(url.replace(/"/g, '\\"').replace(/\n/g, "\\n"), "\"");
  }
  return url;
};

/***/ }),

/***/ "../node_modules/css-loader/dist/runtime/sourceMaps.js":
/***/ ((module) => {



module.exports = function (item) {
  var content = item[1];
  var cssMapping = item[3];
  if (!cssMapping) {
    return content;
  }
  if (typeof btoa === "function") {
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(cssMapping))));
    var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
    var sourceMapping = "/*# ".concat(data, " */");
    return [content].concat([sourceMapping]).join("\n");
  }
  return [content].join("\n");
};

/***/ }),

/***/ "../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js":
/***/ ((module) => {



var stylesInDOM = [];
function getIndexByIdentifier(identifier) {
  var result = -1;
  for (var i = 0; i < stylesInDOM.length; i++) {
    if (stylesInDOM[i].identifier === identifier) {
      result = i;
      break;
    }
  }
  return result;
}
function modulesToDom(list, options) {
  var idCountMap = {};
  var identifiers = [];
  for (var i = 0; i < list.length; i++) {
    var item = list[i];
    var id = options.base ? item[0] + options.base : item[0];
    var count = idCountMap[id] || 0;
    var identifier = "".concat(id, " ").concat(count);
    idCountMap[id] = count + 1;
    var indexByIdentifier = getIndexByIdentifier(identifier);
    var obj = {
      css: item[1],
      media: item[2],
      sourceMap: item[3],
      supports: item[4],
      layer: item[5]
    };
    if (indexByIdentifier !== -1) {
      stylesInDOM[indexByIdentifier].references++;
      stylesInDOM[indexByIdentifier].updater(obj);
    } else {
      var updater = addElementStyle(obj, options);
      options.byIndex = i;
      stylesInDOM.splice(i, 0, {
        identifier: identifier,
        updater: updater,
        references: 1
      });
    }
    identifiers.push(identifier);
  }
  return identifiers;
}
function addElementStyle(obj, options) {
  var api = options.domAPI(options);
  api.update(obj);
  var updater = function updater(newObj) {
    if (newObj) {
      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap && newObj.supports === obj.supports && newObj.layer === obj.layer) {
        return;
      }
      api.update(obj = newObj);
    } else {
      api.remove();
    }
  };
  return updater;
}
module.exports = function (list, options) {
  options = options || {};
  list = list || [];
  var lastIdentifiers = modulesToDom(list, options);
  return function update(newList) {
    newList = newList || [];
    for (var i = 0; i < lastIdentifiers.length; i++) {
      var identifier = lastIdentifiers[i];
      var index = getIndexByIdentifier(identifier);
      stylesInDOM[index].references--;
    }
    var newLastIdentifiers = modulesToDom(newList, options);
    for (var _i = 0; _i < lastIdentifiers.length; _i++) {
      var _identifier = lastIdentifiers[_i];
      var _index = getIndexByIdentifier(_identifier);
      if (stylesInDOM[_index].references === 0) {
        stylesInDOM[_index].updater();
        stylesInDOM.splice(_index, 1);
      }
    }
    lastIdentifiers = newLastIdentifiers;
  };
};

/***/ }),

/***/ "../node_modules/style-loader/dist/runtime/insertBySelector.js":
/***/ ((module) => {



var memo = {};

/* istanbul ignore next  */
function getTarget(target) {
  if (typeof memo[target] === "undefined") {
    var styleTarget = document.querySelector(target);

    // Special case to return head of iframe instead of iframe itself
    if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
      try {
        // This will throw an exception if access to iframe is blocked
        // due to cross-origin restrictions
        styleTarget = styleTarget.contentDocument.head;
      } catch (e) {
        // istanbul ignore next
        styleTarget = null;
      }
    }
    memo[target] = styleTarget;
  }
  return memo[target];
}

/* istanbul ignore next  */
function insertBySelector(insert, style) {
  var target = getTarget(insert);
  if (!target) {
    throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
  }
  target.appendChild(style);
}
module.exports = insertBySelector;

/***/ }),

/***/ "../node_modules/style-loader/dist/runtime/insertStyleElement.js":
/***/ ((module) => {



/* istanbul ignore next  */
function insertStyleElement(options) {
  var element = document.createElement("style");
  options.setAttributes(element, options.attributes);
  options.insert(element, options.options);
  return element;
}
module.exports = insertStyleElement;

/***/ }),

/***/ "../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js":
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



/* istanbul ignore next  */
function setAttributesWithoutAttributes(styleElement) {
  var nonce =  true ? __webpack_require__.nc : 0;
  if (nonce) {
    styleElement.setAttribute("nonce", nonce);
  }
}
module.exports = setAttributesWithoutAttributes;

/***/ }),

/***/ "../node_modules/style-loader/dist/runtime/styleDomAPI.js":
/***/ ((module) => {



/* istanbul ignore next  */
function apply(styleElement, options, obj) {
  var css = "";
  if (obj.supports) {
    css += "@supports (".concat(obj.supports, ") {");
  }
  if (obj.media) {
    css += "@media ".concat(obj.media, " {");
  }
  var needLayer = typeof obj.layer !== "undefined";
  if (needLayer) {
    css += "@layer".concat(obj.layer.length > 0 ? " ".concat(obj.layer) : "", " {");
  }
  css += obj.css;
  if (needLayer) {
    css += "}";
  }
  if (obj.media) {
    css += "}";
  }
  if (obj.supports) {
    css += "}";
  }
  var sourceMap = obj.sourceMap;
  if (sourceMap && typeof btoa !== "undefined") {
    css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
  }

  // For old IE
  /* istanbul ignore if  */
  options.styleTagTransform(css, styleElement, options.options);
}
function removeStyleElement(styleElement) {
  // istanbul ignore if
  if (styleElement.parentNode === null) {
    return false;
  }
  styleElement.parentNode.removeChild(styleElement);
}

/* istanbul ignore next  */
function domAPI(options) {
  if (typeof document === "undefined") {
    return {
      update: function update() {},
      remove: function remove() {}
    };
  }
  var styleElement = options.insertStyleElement(options);
  return {
    update: function update(obj) {
      apply(styleElement, options, obj);
    },
    remove: function remove() {
      removeStyleElement(styleElement);
    }
  };
}
module.exports = domAPI;

/***/ }),

/***/ "../node_modules/style-loader/dist/runtime/styleTagTransform.js":
/***/ ((module) => {



/* istanbul ignore next  */
function styleTagTransform(css, styleElement) {
  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css;
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild);
    }
    styleElement.appendChild(document.createTextNode(css));
  }
}
module.exports = styleTagTransform;

/***/ }),

/***/ "./fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-500.woff":
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-500.woff";

/***/ }),

/***/ "./fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-500.woff2":
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-500.woff2";

/***/ }),

/***/ "./fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-600.woff":
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-600.woff";

/***/ }),

/***/ "./fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-600.woff2":
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-600.woff2";

/***/ }),

/***/ "./fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-700.woff":
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-700.woff";

/***/ }),

/***/ "./fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-700.woff2":
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "fonts/itc-avant-garde-gothic/itc-avant-garde-gothic-700.woff2";

/***/ }),

/***/ "../node_modules/@roots/bud-client/lib/hot/client.js":
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   client: () => (/* binding */ client)
/* harmony export */ });
/* harmony import */ var _components_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/@roots/bud-client/lib/hot/components/index.js");
/* harmony import */ var _events_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("../node_modules/@roots/bud-client/lib/hot/events.js");
/* harmony import */ var _log_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("../node_modules/@roots/bud-client/lib/hot/log.js");
/* harmony import */ var _options_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("../node_modules/@roots/bud-client/lib/hot/options.js");
/* eslint-disable no-console */
/* global __resourceQuery */
/* global __webpack_hash__ */




/**
 * Initializes bud.js HMR handling
 */
const client = async (queryString, webpackHot) => {
    /* Guard: EventSource browser support */
    if (typeof window?.EventSource === `undefined`) {
        console.error(`[bud] hot module reload requires EventSource to work. https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events#Tools`);
        return false;
    }
    /* Guard: webpackHot api availability */
    if (!webpackHot) {
        console.error(`[bud] hot module reload requires the webpack hot api to be available`);
        return false;
    }
    /* Set client options from URL params */
    const options = _options_js__WEBPACK_IMPORTED_MODULE_3__.setFromParameters(queryString);
    /* Setup logger */
    const logger = (0,_log_js__WEBPACK_IMPORTED_MODULE_2__.makeLogger)(options);
    if (typeof window.bud === `undefined`) {
        window.bud = {
            current: {},
            hmr: {},
            controllers: [],
            listeners: {},
        };
    }
    if (!window.bud.current[options.name]) {
        window.bud.current[options.name] = null;
    }
    const isStale = (hash) => {
        if (hash)
            window.bud.current[options.name] = hash;
        return __webpack_require__.h() === window.bud.current[options.name];
    };
    /**
     * Webpack HMR check handler
     */
    const check = async () => {
        if (webpackHot.status() === `idle`) {
            await webpackHot.check(false);
            requestAnimationFrame(async function whenReady() {
                if (webpackHot.status() === `ready`) {
                    await update();
                }
                else {
                    requestAnimationFrame(whenReady);
                }
            });
        }
    };
    /**
     * Webpack HMR unaccepted module handler
     */
    const onUnacceptedOrDeclined = (info) => {
        console.warn(`[${options.name}] ${info.type}`, info);
        options.reload && window.location.reload();
    };
    /**
     * Webpack HMR error handler
     */
    const onErrored = (error) => {
        window.bud.controllers.map(controller => controller?.update({
            errors: [error],
        }));
    };
    /**
     * Webpack HMR update handler
     */
    const update = async () => {
        try {
            await webpackHot.apply({
                ignoreUnaccepted: true,
                ignoreDeclined: true,
                ignoreErrored: true,
                onErrored,
                onUnaccepted: onUnacceptedOrDeclined,
                onDeclined: onUnacceptedOrDeclined,
            });
            if (!isStale())
                await check();
        }
        catch (error) {
            logger.error(error);
        }
    };
    /* Instantiate indicator, overlay */
    try {
        await _components_index_js__WEBPACK_IMPORTED_MODULE_0__.make(options);
    }
    catch (error) { }
    /* Instantiate eventSource */
    const events = (0,_events_js__WEBPACK_IMPORTED_MODULE_1__.injectEvents)(EventSource).make(options);
    if (!window.bud.listeners?.[options.name]) {
        window.bud.listeners[options.name] = async (payload) => {
            if (!payload)
                return;
            if (options.reload && payload.action === `reload`)
                return window.location.reload();
            if (payload.name !== options.name)
                return;
            window.bud.controllers.map(controller => controller?.update(payload));
            if (payload.errors?.length > 0)
                return;
            if (payload.action === `built` || payload.action === `sync`) {
                if (isStale(payload.hash))
                    return;
                if (payload.action === `built`) {
                    logger.log(`built in ${payload.time}ms`);
                }
                await check();
            }
        };
        /*
         * Instantiate HMR event source
         * and register client listeners
         */
        events.addListener(window.bud.listeners[options.name]);
    }
};


/***/ }),

/***/ "../node_modules/@roots/bud-client/lib/hot/components/index.js":
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
const make = async (options) => {
    if (options.indicator && !customElements.get(`bud-activity-indicator`)) {
        await __webpack_require__.e(/* import() */ "node_modules_roots_bud-client_lib_hot_components_indicator_index_js").then(__webpack_require__.bind(__webpack_require__, "../node_modules/@roots/bud-client/lib/hot/components/indicator/index.js"))
            .then(makeController)
            .then(maybePushController);
    }
    if (options.overlay && !customElements.get(`bud-error`)) {
        await __webpack_require__.e(/* import() */ "node_modules_roots_bud-client_lib_hot_components_overlay_index_js").then(__webpack_require__.bind(__webpack_require__, "../node_modules/@roots/bud-client/lib/hot/components/overlay/index.js"))
            .then(makeController)
            .then(maybePushController);
    }
    return window.bud.controllers;
};
const makeController = async (module) => {
    if (!module)
        return;
    return await module.make();
};
const maybePushController = (controller) => {
    if (!controller)
        return;
    window.bud.controllers.push(controller);
};


/***/ }),

/***/ "../node_modules/@roots/bud-client/lib/hot/events.js":
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   injectEvents: () => (/* binding */ injectEvents)
/* harmony export */ });
/* eslint-disable no-console */
const injectEvents = (eventSource) => {
    /**
     * EventSource wrapper
     *
     * @remarks
     * wraps EventSource in a function to allow for
     * mocking in tests
     */
    return class Events extends eventSource {
        /**
         * Class constructor
         *
         * @remarks
         * Singleton interface, so this is private.
         *
         * @public
         */
        constructor(options) {
            super(options.path);
            this.options = options;
            /**
             * Registered listeners
             *
             * @public
             */
            this.listeners = new Set();
            /**
             * EventSource `onopen` handler
             * @public
             */
            this.onopen = function () { };
            /**
             * EventSource `onmessage` handler
             * @public
             */
            this.onmessage = async function (payload) {
                if (!payload?.data || payload.data == `\uD83D\uDC93`) {
                    return;
                }
                try {
                    const data = JSON.parse(payload.data);
                    if (!data)
                        return;
                    await Promise.all([...this.listeners].map(async (listener) => {
                        return await listener(data);
                    }));
                }
                catch (ex) { }
            };
            this.onopen = this.onopen.bind(this);
            this.onmessage = this.onmessage.bind(this);
            this.addListener = this.addListener.bind(this);
        }
        /**
         * Singleton constructor
         *
         * @public
         */
        static make(options) {
            if (typeof window.bud.hmr[options.name] === `undefined`)
                Object.assign(window.bud.hmr, {
                    [options.name]: new Events(options),
                });
            return window.bud.hmr[options.name];
        }
        /**
         * EventSource `addMessageListener` handler
         * @public
         */
        addListener(listener) {
            this.listeners.add(listener);
            return this;
        }
    };
};


/***/ }),

/***/ "../node_modules/@roots/bud-client/lib/hot/index.js?name=sage&indicator=true&overlay=true&reload=true":
/***/ ((__webpack_module__, __webpack_exports__, __webpack_require__) => {

var __resourceQuery = "?name=sage&indicator=true&overlay=true&reload=true";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _client_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/@roots/bud-client/lib/hot/client.js");
/* eslint-disable no-console */
/* global __resourceQuery */
/* global module */

try {
    (0,_client_js__WEBPACK_IMPORTED_MODULE_0__.client)(__resourceQuery, __webpack_module__.hot);
}
catch (err) {
    console.error(err);
    try {
        (0,_client_js__WEBPACK_IMPORTED_MODULE_0__.client)(__resourceQuery, module.hot);
    }
    catch (error) {
        console.error(error);
    }
}


/***/ }),

/***/ "../node_modules/@roots/bud-client/lib/hot/log.js":
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   makeError: () => (/* binding */ makeError),
/* harmony export */   makeInfo: () => (/* binding */ makeInfo),
/* harmony export */   makeLog: () => (/* binding */ makeLog),
/* harmony export */   makeLogger: () => (/* binding */ makeLogger),
/* harmony export */   makeWarn: () => (/* binding */ makeWarn)
/* harmony export */ });
/* eslint-disable no-console */
const makeLogger = (options) => {
    return {
        log: makeLog(options),
        error: makeError(options),
        warn: makeWarn(options),
        info: makeInfo(options),
    };
};
let lastLog = null;
const makeLog = options => {
    return (...args) => {
        if (options.log) {
            if (lastLog === args.join(``))
                return;
            lastLog = args.join(``);
            console.log(`[${options.name}]`, ...args);
        }
    };
};
const makeInfo = options => {
    return (...args) => {
        if (options.log) {
            console.info(`[${options.name}]`, ...args);
        }
    };
};
const makeError = options => {
    return (...args) => {
        console.error(`[${options.name}]`, ...args);
    };
};
const makeWarn = options => {
    return (...args) => {
        console.warn(`[${options.name}]`, ...args);
    };
};


/***/ }),

/***/ "../node_modules/@roots/bud-client/lib/hot/options.js":
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   data: () => (/* binding */ data),
/* harmony export */   get: () => (/* binding */ get),
/* harmony export */   setFromParameters: () => (/* binding */ setFromParameters)
/* harmony export */ });
/**
 * Client options
 */
let data = {
    timeout: 2000,
    reload: true,
    name: `@roots/bud-client`,
    debug: true,
    log: true,
    indicator: true,
    overlay: true,
    path: `/bud/hot`,
};
/**
 * Get client option
 */
const get = (name, key) => key ? data[name][key] : data[name];
/**
 * Set client data based on URL parameters
 */
const setFromParameters = (query) => {
    let parsedParams = {};
    new window.URLSearchParams(query).forEach((value, key) => {
        parsedParams[key] =
            value === `true` ? true : value === `false` ? false : value;
    });
    data[parsedParams.name] = { ...data, ...parsedParams };
    return data[parsedParams.name];
};



/***/ }),

/***/ "../node_modules/@roots/sage/lib/client/dom-ready.js":
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const domReady = onReady => {
    window.requestAnimationFrame(async function check() {
        document.body ? await onReady() : window.requestAnimationFrame(check);
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (domReady);


/***/ }),

/***/ "./scripts/app.js":
/***/ ((__webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _roots_sage_client_dom_ready__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/@roots/sage/lib/client/dom-ready.js");
/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./scripts/footer.js");
/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./scripts/header.js");
/* harmony import */ var _map__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./scripts/map.js");
/* harmony import */ var _carousel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./scripts/carousel.js");





;
/**
 * Application entrypoint
 */
(0,_roots_sage_client_dom_ready__WEBPACK_IMPORTED_MODULE_0__["default"])(async () => {
  // ...
});

/**
 * @see {@link https://webpack.js.org/api/hot-module-replacement/}
 */
if (true) __webpack_module__.hot.accept(console.error);

/***/ }),

/***/ "./scripts/carousel.js":
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
document.addEventListener('DOMContentLoaded', () => {
  const swiperConfigs = [{
    container: '.swiper-container-content-cards',
    autoplay: true
  }, {
    container: '.swiper-container-news',
    navigation: true
  }, {
    container: '.swiper-container-featured-image',
    autoplay: true,
    pagination: true,
    numSlidesMobile: 1,
    numSlidesDesktop: 1
  }];
  swiperConfigs.forEach(config => {
    const defaultSwiperOptions = {
      loop: true,
      slidesPerView: 3,
      spaceBetween: 14,
      breakpoints: {
        0: {
          slidesPerView: config.numSlidesMobile || 1
        },
        640: {
          slidesPerView: config.numSlidesMobile || 2
        },
        1024: {
          slidesPerView: config.numSlidesDesktop || 3
        }
      }
    };
    config.autoplay ? defaultSwiperOptions.autoplay = {
      delay: 8000
    } : null;
    config.navigation ? defaultSwiperOptions.navigation = {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev"
    } : null;
    config.pagination ? defaultSwiperOptions.pagination = {
      el: ".swiper-pagination",
      clickable: true
    } : null;
    new Swiper(config.container, defaultSwiperOptions);
  });
});

/***/ }),

/***/ "./scripts/footer.js":
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
document.addEventListener('DOMContentLoaded', () => {
  const menuTitles = document.querySelectorAll('.footer-sub-menu-title');
  menuTitles.forEach(title => {
    const nestedItem = title.nextElementSibling;
    const icon = title.querySelector('.expand-icon-footer');
    if (nestedItem) {
      nestedItem.classList.add('hidden');
      title.addEventListener('click', () => {
        const isHidden = nestedItem.classList.toggle('hidden');
        icon.classList.toggle('expand-icon-footer', isHidden);
        icon.classList.toggle('retract-icon-footer', !isHidden);
      });
    }
  });
});

/***/ }),

/***/ "./scripts/header.js":
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
document.addEventListener('DOMContentLoaded', () => {
  const hamburgerButton = document.getElementById('hamburger-button');

  // open and close hamburger menu
  hamburgerButton.addEventListener('click', toggleHamburgerMenu);

  // add listeners for main navigation items
  const primaryNavItems = document.querySelectorAll('#primary-nav-container > nav > div > ul > li');
  let openSubMenu = null;
  primaryNavItems.forEach(menuItem => {
    const submenu = menuItem.querySelector('.sub-menu');
    if (submenu) {
      submenu.classList.add('hidden');
      menuItem.addEventListener('click', event => {
        event.stopPropagation();
        if (openSubMenu && openSubMenu !== submenu) {
          openSubMenu.classList.add('hidden');
        }
        submenu.classList.toggle('hidden');
        openSubMenu = submenu.classList.contains('hidden') ? null : submenu;
      });
    }
  });
  document.addEventListener('click', () => {
    if (openSubMenu) {
      openSubMenu.classList.add('hidden');
      openSubMenu = null; // reset the tracker
    }
  });

  // add listeners for hamburger right side menu items
  const hamburgerMenuItems = document.querySelectorAll('.sub_menu.right > .menu > div > ul > li');
  let openHamburgerSubMenu = null;
  let openIconSpan = null;
  hamburgerMenuItems.forEach(li => {
    const nestedUl = li.querySelector('ul');
    const link = li.querySelector('a');
    const iconSpan = document.createElement('span');
    if (nestedUl) {
      iconSpan.className = 'expand-icon-header';
      nestedUl.classList.add('hidden');

      // add an event listener to toggle visibility of nested sub-menu
      li.addEventListener('click', e => {
        // only prevent re-direction for parent list items
        if (e.target.closest('li') === li && nestedUl) {
          e.preventDefault();
        }

        // close the previously open submenu if it's not the current one
        if (openHamburgerSubMenu && openHamburgerSubMenu !== nestedUl) {
          openHamburgerSubMenu.classList.add('hidden');

          // reset the icon class of the previously open submenu
          if (openIconSpan) {
            openIconSpan.classList.remove('retract-icon-header');
            openIconSpan.classList.add('expand-icon-header');
          }
        }

        // toggle the current submenu
        const isHidden = nestedUl.classList.toggle('hidden');
        iconSpan.classList.toggle('retract-icon-header', !isHidden);
        iconSpan.classList.toggle('expand-icon-header', isHidden);

        // update the currently open submenu tracker
        openHamburgerSubMenu = isHidden ? null : nestedUl;
        openIconSpan = isHidden ? null : iconSpan;
      });
    } else {
      const iconImg = Object.assign(document.createElement('img'), {
        className: 'arrow-svg',
        src: arrowIconUrl,
        // created in header.blade.php to get dynamic path
        alt: "right facing black arrow"
      });
      iconSpan.appendChild(iconImg);
    }
    if (link) {
      link.appendChild(iconSpan);
    }
  });

  // dynamically align sub menu to parent nav item  
  window.addEventListener('load', () => paddNestedItemToParent(primaryNavItems));
  window.addEventListener('resize', () => paddNestedItemToParent(primaryNavItems));
});
const toggleHamburgerMenu = () => {
  const hamburgerButton = document.getElementById('hamburger-button');
  const dropdownMenu = document.querySelector('#hamburger-dropdown-menu');
  const primaryNav = document.getElementById('primary-nav-container');
  hamburgerButton.classList.toggle('active');
  dropdownMenu.classList.toggle('hidden');
  primaryNav.classList.toggle('hidden');
  if (dropdownMenu.classList.contains('hidden')) {
    revertIcons();
  }
};
const revertIcons = () => {
  const retractIcons = document.querySelectorAll('.retract-icon-header');
  retractIcons.forEach(icon => {
    icon.classList.remove('retract-icon-header');
    icon.classList.add('expand-icon-header');
    const parentLi = icon.closest('li');
    const nestedUl = parentLi.querySelector('ul');
    if (nestedUl) {
      nestedUl.classList.toggle('hidden');
    }
  });
};
const paddNestedItemToParent = primaryNavItems => {
  primaryNavItems.forEach(menuItem => {
    const subMenu = menuItem.querySelector('ul.sub-menu');
    if (subMenu) {
      const offsetLeft = menuItem.getBoundingClientRect().left;
      subMenu.style.paddingLeft = `${offsetLeft}px`;
    }
  });
};

/***/ }),

/***/ "./scripts/map.js":
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
document.addEventListener('DOMContentLoaded', function () {
  const map = document.getElementById('map');
  const locationMarkers = document.querySelectorAll('.marker-location');
  const updateMarkers = () => {
    positionMarkers(map, locationMarkers);
  };
  window.addEventListener('load', updateMarkers);
  window.addEventListener('resize', updateMarkers);
  const closeLocationCards = () => {
    const locationCards = document.querySelectorAll('[data-location-target]');
    locationCards.forEach(card => {
      card.classList.add('hide-item');
    });
  };
  const resetActivePins = () => {
    const pins = document.querySelectorAll(`[data-location]`);
    pins.forEach(pin => {
      pin.classList.remove('active');
    });
  };
  const closeZoomedMap = () => {
    const regionMaps = document.querySelectorAll('[data-map]');
    regionMaps.forEach(map => {
      map.classList.add('hide-item');
    });
  };
  const hideBackBtn = () => {
    const backBtn = document.querySelector('[data-back-to-overview]');
    backBtn.style.zIndex = '-1';
  };
  const showBackBtn = () => {
    const backBtn = document.querySelector('[data-back-to-overview]');
    backBtn.style.zIndex = '20';
  };
  const hideWorldMap = () => {
    const worldMap = document.querySelector('#map');
    worldMap.classList.add('hide-item');
  };
  const showWorldMap = () => {
    const worldMap = document.querySelector('#map');
    worldMap.classList.remove('hide-item');
  };
  const resetToWorldMap = () => {
    closeLocationCards();
    closeZoomedMap();
    showWorldMap();
    updateMarkers();
    hideBackBtn();
    resetActivePins();
  };
  const locationPin = document.querySelectorAll('[data-location]');
  locationPin.forEach(pin => {
    pin.addEventListener('click', () => {
      // Reset
      resetToWorldMap();

      // Hide world map
      hideWorldMap();

      // Show map region
      const mapRegion = pin.getAttribute('data-map-region');
      const currentMap = document.querySelector(`[data-map="${mapRegion}"]`);
      currentMap.classList.remove('hide-item');

      // Position markers on region map
      const regionMarkers = document.querySelectorAll(`[data-map-region="${mapRegion}"]`);
      positionZoomMarkers(currentMap, regionMarkers);
      showBackBtn();
      resetActivePins();

      // Show card that matches this pin
      const locationValue = pin?.getAttribute('data-location');
      if (locationValue) {
        const locationCard = document.querySelector(`[data-location-target="${locationValue}"]`);
        pin.classList.add('active');
        locationCard.classList.remove('hide-item');
      }

      // Restore if you want to show first card from cluster when cluster is clicked
      // // If it's a cluster pin
      // const clusterCheck = pin.querySelector('.marker-pin-cluster')
      // if (clusterCheck) {
      //     // Get first location from the region
      //     const pinsInRegion = document.querySelectorAll(`[data-map-region="${mapRegion}"]`)

      //     // Start with 1 as 0 is cluster pin
      //     const firstLocation = pinsInRegion[1].getAttribute('data-location')
      //     const firstPin = document.querySelector(`[data-location="${firstLocation}"]`)
      //     const firstCard = document.querySelector(`[data-location-target="${firstLocation}"]`)

      //     firstPin.classList.add('active')
      //     firstCard.classList.remove('hide-item')
      // }
    });
  });

  // Location card - close button. Exit location.
  const locationCardCloseBtn = document.querySelectorAll('.expand-icon-map');
  if (locationCardCloseBtn) {
    locationCardCloseBtn.forEach(btn => {
      btn.addEventListener('click', () => {
        resetToWorldMap();
      });
    });
  }

  // Back to world map button
  const backBtn = document.querySelector('[data-back-to-overview]');
  if (backBtn) {
    backBtn.addEventListener('click', () => {
      resetToWorldMap();
    });
  }
  if (map) {
    updateMarkers();
    hideBackBtn();
  }

  /*
  Mobile accordion logic uses those two data attributes:
  - data-continent
  - data-belongs-to
  */
  const resetAccordion = () => {
    const places = document.querySelectorAll(`[data-belongs-to]`);
    places.forEach(place => place.classList.remove('show-item', 'open'));
  };
  const accordion = () => {
    const continents = document.querySelectorAll(`[data-continent]`);
    continents.forEach(continent => {
      continent.addEventListener('click', () => {
        const continentName = continent.getAttribute('data-continent');

        // Toggle 'open' class on the clicked continent
        continent.classList.toggle('open');

        // Find places assigned to this continent
        const places = document.querySelectorAll(`[data-belongs-to="${continentName}"]`);
        places.forEach(place => {
          place.classList.toggle('show-item');
        });
      });
    });

    // expand/hide inner tab
    const allInnerTabs = document.querySelectorAll('[data-mobile-tab]');
    allInnerTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tab.closest('.marker-logo').classList.toggle('open');
      });
    });
  };
  accordion();
  window.addEventListener('resize', resetAccordion);
});
const positionMarkers = (map, locationMarkers) => {
  if (!map) return;
  const mapRect = map.getBoundingClientRect();
  locationMarkers.forEach(marker => {
    const xPercent = marker.getAttribute('data-x');
    const yPercent = marker.getAttribute('data-y');
    const xPos = mapRect.width * xPercent / 100;
    const yPos = mapRect.height * yPercent / 100;
    marker.style.left = `${xPos}px`;
    marker.style.top = `${yPos}px`;
    marker.style.zIndex = '1';
  });
};
const positionZoomMarkers = (currentMap, currentRegionMarkers) => {
  if (!currentMap) return;
  const mapRect = currentMap.getBoundingClientRect();
  currentRegionMarkers.forEach(marker => {
    const xPercent = marker.getAttribute('data-x-zoom');
    const yPercent = marker.getAttribute('data-y-zoom');
    const xPos = mapRect.width * xPercent / 100;
    const yPos = mapRect.height * yPercent / 100;
    marker.style.left = `${xPos}px`;
    marker.style.top = `${yPos}px`;
    marker.style.zIndex = '20';
  });
};

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ var __webpack_exports__ = (__webpack_exec__("./scripts/app.js"), __webpack_exec__("./styles/app.css"), __webpack_exec__("../node_modules/@roots/bud-client/lib/hot/index.js?name=sage&indicator=true&overlay=true&reload=true"));
/******/ }
]);
//# sourceMappingURL=app.js.map