"use strict";
self["webpackHotUpdate_roots_bud_sage_sage"]("app",{

/***/ "./scripts/map.js":
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
document.addEventListener('DOMContentLoaded', function () {
  const map = document.getElementById('map');
  const locationMarkers = document.querySelectorAll('.marker-location');
  // const logoMarkers = document.querySelectorAll('.marker-logo');
  // const continentMarkerContainers = document.querySelectorAll('.continent-marker-container');
  // const continents = ['europe', 'america', 'middle-east', 'australia', 'asia'];

  const updateMarkers = () => {
    positionMarkers(map, locationMarkers);
  };
  window.addEventListener('load', updateMarkers);
  window.addEventListener('resize', updateMarkers);
  const hideCards = () => {
    const locationCards = document.querySelectorAll('[data-location-target]');
    locationCards.forEach(card => {
      card.classList.add('hide-item');
    });
  };
  const hideRegionMap = () => {
    const regionMaps = document.querySelectorAll('[data-map]');
    regionMaps.forEach(map => {
      map.classList.add('hide-item');
    });
    // Show original map
    const worldMap = document.querySelector('#map');
    worldMap.classList.remove('hide-item');
    updateMarkers();
  };
  const locationPin = document.querySelectorAll('[data-location]');
  const worldMap = document.querySelector('#map');
  locationPin.forEach(pin => {
    pin.addEventListener('click', () => {
      // Reset markers
      updateMarkers();

      // Reset all cards 
      hideCards();

      // Restet all region maps
      hideRegionMap();

      // Show map region
      const mapRegion = pin.getAttribute('data-map-region');
      const currentMap = document.querySelector(`[data-map="${mapRegion}"]`);

      // Show regian markers and update coordinates
      const regionMarkers = document.querySelectorAll(`[data-map-region="${mapRegion}"]`);
      regionMarkers.forEach(region => {
        // region.classList.add('marker-zoomed')
      });
      positionZoomMarkers(map, regionMarkers);

      // Hide world map
      worldMap.classList.add('hide-item');

      // Show region map
      currentMap.classList.remove('hide-item');

      // Show card that matches this pin
      const locationValue = pin?.getAttribute('data-location');
      if (locationValue) {
        const locationCard = document.querySelector(`[data-location-target="${locationValue}"]`);
        locationCard.classList.remove('hide-item');
        console.log(locationValue);
      }
    });
  });

  // card close btn 
  const closeBtns = document.querySelectorAll('.expand-icon-map');
  closeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      hideCards();
      hideRegionMap();
      updateMarkers();
    });
  });

  // cluster pin number update
  const clusterPinCount = () => {
    const allCluster = document.querySelectorAll('.marker-pin-cluster');
    if (!allCluster) return;
    allCluster.forEach(clusterPin => {
      const currentClusterWrapper = clusterPin.closest('[data-map-region]');
      const attributeValue = currentClusterWrapper.getAttribute('data-map-region');
      const getAllelementsFromRegion = document.querySelectorAll(`[data-map-region="${attributeValue}"]`);
      const clusterQuantity = getAllelementsFromRegion.length;
      clusterPin.textContent = clusterQuantity ? clusterQuantity - 1 : "";
    });
  };
  clusterPinCount();
  if (map) {
    updateMarkers();
  }

  /*
  Mobile accordion logic uses those two data attributes:
  - data-continent
  - data-belongs-to
  */
  const resetAccordion = () => {
    const places = document.querySelectorAll(`[data-belongs-to]`);
    places.forEach(place => place.classList.remove('show-item', 'open'));
  };
  const accordion = () => {
    const continents = document.querySelectorAll(`[data-continent]`);
    continents.forEach(continent => {
      continent.addEventListener('click', () => {
        const continentName = continent.getAttribute('data-continent');

        // Toggle 'open' class on the clicked continent
        continent.classList.toggle('open');

        // Find places assigned to this continent
        const places = document.querySelectorAll(`[data-belongs-to="${continentName}"]`);
        places.forEach(place => {
          place.classList.toggle('show-item');
        });
      });
    });

    // expand/hide inner tab
    const allInnerTabs = document.querySelectorAll('[data-mobile-tab]');
    allInnerTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tab.closest('.marker-logo').classList.toggle('open');
      });
    });
  };
  accordion();
  window.addEventListener('resize', resetAccordion);
});
const positionMarkers = (map, locationMarkers) => {
  if (!map) return;
  const mapRect = map.getBoundingClientRect();
  locationMarkers.forEach(marker => {
    const xPercent = marker.getAttribute('data-x');
    const yPercent = marker.getAttribute('data-y');
    const xPos = mapRect.width * xPercent / 100;
    const yPos = mapRect.height * yPercent / 100;
    marker.style.left = `${xPos}px`;
    marker.style.top = `${yPos}px`;
    marker.style.zIndex = '1';
  });
};
const positionZoomMarkers = (currentMap, currentRegionMarkers) => {
  if (!currentMap) return;
  const mapRect = currentMap.getBoundingClientRect();
  currentRegionMarkers.forEach(marker => {
    const xPercent = marker.getAttribute('data-x-zoom');
    const yPercent = marker.getAttribute('data-y-zoom');
    const xPos = mapRect.width * xPercent / 100;
    const yPos = mapRect.height * yPercent / 100;
    marker.style.left = `${xPos}px`;
    marker.style.top = `${yPos}px`;
    marker.style.zIndex = '20';
  });
};

/***/ })

});
//# sourceMappingURL=app.9e1bd3751478d1fd9e15.hot-update.js.map